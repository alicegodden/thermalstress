var networks = {"thermal_stress_testes_mirna_gene": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "male_FINAL_edges.csv",
    "name" : "thermal_stress_testes_mirna_gene",
    "SUID" : 155,
    "__Annotations" : [ "" ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "188",
        "padj" : 0.008889133,
        "significant" : true,
        "shared_name" : "dre-miR-222b",
        "feature_type" : "miRNA",
        "name" : "dre-miR-222b",
        "SUID" : 188,
        "log2FC" : -1.291310463,
        "selected" : false,
        "direction" : "down"
      },
      "position" : {
        "x" : 52.321590423583984,
        "y" : -53.86967468261719
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "186",
        "stat" : 3.617060537,
        "padj" : 0.029490047,
        "pvalue" : 2.97968E-4,
        "significant" : true,
        "shared_name" : "hspa8b",
        "feature_type" : "gene",
        "baseMean" : 960.1738059,
        "name" : "hspa8b",
        "SUID" : 186,
        "lfcSE" : 0.304685138,
        "log2FC" : 1.102064589,
        "selected" : false,
        "direction" : "up"
      },
      "position" : {
        "x" : 50.0,
        "y" : 53.86967468261719
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "184",
        "padj" : 0.008889133,
        "significant" : true,
        "shared_name" : "dre-miR-146b",
        "feature_type" : "miRNA",
        "name" : "dre-miR-146b",
        "SUID" : 184,
        "log2FC" : -2.591173897,
        "selected" : false,
        "direction" : "down"
      },
      "position" : {
        "x" : -50.0,
        "y" : -53.86967468261719
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "182",
        "stat" : 4.486513754,
        "padj" : 0.003303203,
        "pvalue" : 7.24E-6,
        "significant" : true,
        "shared_name" : "hsp70.3",
        "feature_type" : "gene",
        "baseMean" : 171.5078774,
        "name" : "hsp70.3",
        "SUID" : 182,
        "lfcSE" : 0.413792893,
        "log2FC" : 1.856487505,
        "selected" : false,
        "direction" : "up"
      },
      "position" : {
        "x" : -52.321590423583984,
        "y" : 53.86967468261719
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "192",
        "source" : "188",
        "target" : "186",
        "shared_name" : "dre-miR-222b (miRNA_gene) hspa8b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-222b (miRNA_gene) hspa8b",
        "interaction" : "miRNA_gene",
        "SUID" : 192,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "source" : "184",
        "target" : "182",
        "shared_name" : "dre-miR-146b (miRNA_gene) hsp70.3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-146b (miRNA_gene) hsp70.3",
        "interaction" : "miRNA_gene",
        "SUID" : 190,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}