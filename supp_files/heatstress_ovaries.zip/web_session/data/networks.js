var networks = {"female_FINAL_edges.csv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "female_FINAL_edges.csv",
    "EnrichmentTable_Gene_ID_Column" : "",
    "EnrichmentTable_organism" : "",
    "__Annotations" : [ "" ],
    "name" : "female_FINAL_edges.csv",
    "SUID" : 330,
    "EnrichmentTable_Significance_Threshold_Method" : "",
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "647",
        "degree_layout" : 9,
        "padj" : 0.045627287,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-100-3p",
        "TopologicalCoefficient" : 0.3055555555555556,
        "SUID" : 647,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8482758620689657,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.25985663082437277,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9017835909631391,
        "Stress" : 17366,
        "target_original" : "tspan18b",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.010079549166507808,
        "NumberOfUndirectedEdges" : 9,
        "name" : "dre-miR-100-3p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.588444045,
        "NeighborhoodConnectivity" : 7.111111111111111
      },
      "position" : {
        "x" : -233.23652434011456,
        "y" : -201.0451341477961
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "645",
        "degree_layout" : 9,
        "padj" : 9.04821E-4,
        "Eccentricity" : 8,
        "pvalue" : 2.28E-6,
        "shared_name" : "myh14",
        "TopologicalCoefficient" : 0.32222222222222224,
        "baseMean" : 149.0939701,
        "SUID" : 645,
        "lfcSE" : 0.376531105,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.43448275862069,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2911646586345381,
        "stat" : 4.726550696,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9160523186682521,
        "Stress" : 28044,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.013203974617821131,
        "NumberOfUndirectedEdges" : 9,
        "name" : "myh14",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.779693355,
        "NeighborhoodConnectivity" : 17.11111111111111
      },
      "position" : {
        "x" : -440.32537933668937,
        "y" : -626.051789681238
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "643",
        "degree_layout" : 27,
        "padj" : 4.10955E-4,
        "Eccentricity" : 7,
        "shared_name" : "dre-miR-19a-3p",
        "TopologicalCoefficient" : 0.24417009602194786,
        "SUID" : 643,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.882758620689655,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.34688995215311,
        "Degree" : 27,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9350772889417359,
        "Stress" : 184776,
        "target_original" : "depdc7a",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.145050275357856,
        "NumberOfUndirectedEdges" : 27,
        "name" : "dre-miR-19a-3p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.735500312,
        "NeighborhoodConnectivity" : 7.592592592592593
      },
      "position" : {
        "x" : -245.58006993543708,
        "y" : -324.57158436733175
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "641",
        "degree_layout" : 24,
        "padj" : 0.006204924,
        "Eccentricity" : 7,
        "shared_name" : "dre-miR-19b-3p",
        "TopologicalCoefficient" : 0.27314814814814814,
        "SUID" : 641,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.924137931034483,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.3419811320754717,
        "Degree" : 24,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9336504161712247,
        "Stress" : 169122,
        "target_original" : "aldob",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.09581143423185973,
        "NumberOfUndirectedEdges" : 24,
        "name" : "dre-miR-19b-3p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.583412067,
        "NeighborhoodConnectivity" : 8.375
      },
      "position" : {
        "x" : -213.69774364627378,
        "y" : -230.74896963995522
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "639",
        "degree_layout" : 24,
        "padj" : 0.014175966,
        "Eccentricity" : 7,
        "shared_name" : "dre-miR-19c-3p",
        "TopologicalCoefficient" : 0.27314814814814814,
        "SUID" : 639,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.924137931034483,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.3419811320754717,
        "Degree" : 24,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9336504161712247,
        "Stress" : 169122,
        "target_original" : "aldob",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.09581143423185973,
        "NumberOfUndirectedEdges" : 24,
        "name" : "dre-miR-19c-3p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.550416629,
        "NeighborhoodConnectivity" : 8.375
      },
      "position" : {
        "x" : -148.87525781774633,
        "y" : -193.2151621933775
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "637",
        "degree_layout" : 13,
        "padj" : 0.007820691,
        "Eccentricity" : 7,
        "shared_name" : "dre-miR-101a",
        "TopologicalCoefficient" : 0.28,
        "SUID" : 637,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.117241379310345,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.32079646017699115,
        "Degree" : 13,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9269916765755054,
        "Stress" : 75142,
        "target_original" : "unm_hu7912",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.04911453277170311,
        "NumberOfUndirectedEdges" : 13,
        "name" : "dre-miR-101a",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.484765331,
        "NeighborhoodConnectivity" : 8.0
      },
      "position" : {
        "x" : -69.27536107843662,
        "y" : -259.6499289509957
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "635",
        "degree_layout" : 14,
        "padj" : 4.51764E-4,
        "Eccentricity" : 7,
        "shared_name" : "dre-miR-101b",
        "TopologicalCoefficient" : 0.2554945054945055,
        "SUID" : 635,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.089655172413793,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.3236607142857143,
        "Degree" : 14,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9279429250891795,
        "Stress" : 79500,
        "target_original" : "cyp7a1",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.06450284840152647,
        "NumberOfUndirectedEdges" : 14,
        "name" : "dre-miR-101b",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.956675636,
        "NeighborhoodConnectivity" : 7.642857142857143
      },
      "position" : {
        "x" : -260.150344067943,
        "y" : -258.7281674308334
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "633",
        "degree_layout" : 20,
        "padj" : 0.026651409,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-142b-5p",
        "TopologicalCoefficient" : 0.212,
        "SUID" : 633,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.627586206896552,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2756653992395437,
        "Degree" : 20,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9093935790725327,
        "Stress" : 96144,
        "target_original" : "pcdh15a",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.0630197066421851,
        "NumberOfUndirectedEdges" : 20,
        "name" : "dre-miR-142b-5p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.334672016,
        "NeighborhoodConnectivity" : 6.3
      },
      "position" : {
        "x" : -211.56324908810896,
        "y" : -289.5338584224799
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "631",
        "degree_layout" : 17,
        "padj" : 0.012615231,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-301a",
        "TopologicalCoefficient" : 0.2867647058823529,
        "SUID" : 631,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.668965517241379,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2725563909774436,
        "Degree" : 17,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9079667063020215,
        "Stress" : 55778,
        "target_original" : "hsph1",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.024002718094794644,
        "NumberOfUndirectedEdges" : 17,
        "name" : "dre-miR-301a",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.543715118,
        "NeighborhoodConnectivity" : 7.882352941176471
      },
      "position" : {
        "x" : -156.5116114065789,
        "y" : -261.9279702764568
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "629",
        "degree_layout" : 6,
        "padj" : 0.049694142,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-196b",
        "TopologicalCoefficient" : 0.4126984126984127,
        "SUID" : 629,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.889655172413793,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2570921985815603,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9003567181926279,
        "Stress" : 8058,
        "target_original" : "nr4a2a",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.004874508097627775,
        "NumberOfUndirectedEdges" : 6,
        "name" : "dre-miR-196b",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : 1.149970941,
        "NeighborhoodConnectivity" : 9.666666666666666
      },
      "position" : {
        "x" : -98.35271640152543,
        "y" : -132.57073658409942
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "627",
        "degree_layout" : 10,
        "padj" : 0.036745205,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-142a-3p",
        "TopologicalCoefficient" : 0.32083333333333336,
        "SUID" : 627,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.779310344827586,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2645985401459854,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9041617122473247,
        "Stress" : 13866,
        "target_original" : "LOC795051",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.008178622408016815,
        "NumberOfUndirectedEdges" : 10,
        "name" : "dre-miR-142a-3p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.146609674,
        "NeighborhoodConnectivity" : 8.7
      },
      "position" : {
        "x" : -314.23418421252956,
        "y" : -283.2345769424603
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "625",
        "degree_layout" : 10,
        "padj" : 0.012620996,
        "Eccentricity" : 8,
        "pvalue" : 9.3E-5,
        "shared_name" : "dnajc11",
        "TopologicalCoefficient" : 0.3235294117647059,
        "baseMean" : 101.8779671,
        "SUID" : 625,
        "lfcSE" : 0.305094406,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.406896551724138,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2935222672064777,
        "stat" : 3.908288176,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9170035671819263,
        "Stress" : 28520,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.012374178534603783,
        "NumberOfUndirectedEdges" : 10,
        "name" : "dnajc11",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.19239686,
        "NeighborhoodConnectivity" : 17.5
      },
      "position" : {
        "x" : 40.34963333157066,
        "y" : -761.8373474390537
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "623",
        "degree_layout" : 19,
        "padj" : 0.022477701,
        "Eccentricity" : 7,
        "shared_name" : "dre-miR-190a",
        "TopologicalCoefficient" : 0.22064777327935223,
        "SUID" : 623,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.0068965517241377,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.33256880733944955,
        "Degree" : 19,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9307966706302021,
        "Stress" : 105550,
        "target_original" : "LOC795051",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.10184281328461434,
        "NumberOfUndirectedEdges" : 19,
        "name" : "dre-miR-190a",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.64980038,
        "NeighborhoodConnectivity" : 6.7368421052631575
      },
      "position" : {
        "x" : -79.97844693123233,
        "y" : -219.51078454581628
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "621",
        "degree_layout" : 18,
        "padj" : 0.038152929,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-301c-3p",
        "TopologicalCoefficient" : 0.2638888888888889,
        "SUID" : 621,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6551724137931036,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.27358490566037735,
        "Degree" : 18,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9084423305588585,
        "Stress" : 57396,
        "target_original" : "hsph1",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.030190812801586416,
        "NumberOfUndirectedEdges" : 18,
        "name" : "dre-miR-301c-3p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.945455732,
        "NeighborhoodConnectivity" : 7.333333333333333
      },
      "position" : {
        "x" : -138.65255613652698,
        "y" : -316.5556678979192
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "619",
        "degree_layout" : 9,
        "padj" : 0.042086758,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-196c",
        "TopologicalCoefficient" : 0.3140096618357488,
        "SUID" : 619,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.806896551724138,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.26268115942028986,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9032104637336504,
        "Stress" : 19280,
        "target_original" : "creg2",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.010873916028101066,
        "NumberOfUndirectedEdges" : 9,
        "name" : "dre-miR-196c",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : 2.238531673,
        "NeighborhoodConnectivity" : 8.222222222222221
      },
      "position" : {
        "x" : -381.69659681476054,
        "y" : -361.4511782236503
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "617",
        "degree_layout" : 9,
        "padj" : 0.010775382,
        "Eccentricity" : 7,
        "shared_name" : "dre-miR-107a-5p",
        "TopologicalCoefficient" : 0.26666666666666666,
        "SUID" : 617,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.1862068965517243,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.31385281385281383,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9246135552913198,
        "Stress" : 55660,
        "target_original" : "slc6a1b",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.037730027801711793,
        "NumberOfUndirectedEdges" : 9,
        "name" : "dre-miR-107a-5p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.331765583,
        "NeighborhoodConnectivity" : 7.666666666666667
      },
      "position" : {
        "x" : -318.33398779149866,
        "y" : -185.85619290151226
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "615",
        "degree_layout" : 5,
        "padj" : 0.015742105,
        "Eccentricity" : 8,
        "pvalue" : 1.28367E-4,
        "shared_name" : "rgma",
        "TopologicalCoefficient" : 0.31063829787234043,
        "baseMean" : 121.1309216,
        "SUID" : 615,
        "lfcSE" : 0.41617343,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5310344827586206,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.283203125,
        "stat" : 3.829570157,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9127229488703924,
        "Stress" : 11082,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.005537096358357035,
        "NumberOfUndirectedEdges" : 5,
        "name" : "rgma",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.593765347,
        "NeighborhoodConnectivity" : 15.6
      },
      "position" : {
        "x" : -638.6746169784747,
        "y" : -447.1579043835227
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "613",
        "degree_layout" : 21,
        "padj" : 0.045627287,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-430a-3p",
        "TopologicalCoefficient" : 0.2318840579710145,
        "SUID" : 613,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6413793103448278,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2746212121212121,
        "Degree" : 21,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9089179548156956,
        "Stress" : 86416,
        "target_original" : "pcdh15a",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.054600854649287954,
        "NumberOfUndirectedEdges" : 21,
        "name" : "dre-miR-430a-3p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : 1.212651212,
        "NeighborhoodConnectivity" : 6.333333333333333
      },
      "position" : {
        "x" : -22.398142891937074,
        "y" : -168.59736913068417
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "611",
        "degree_layout" : 12,
        "padj" : 0.049663899,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-338-3p",
        "TopologicalCoefficient" : 0.2633333333333333,
        "SUID" : 611,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7379310344827585,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.26752767527675275,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9055885850178359,
        "Stress" : 37384,
        "target_original" : "tspan18b",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.03078430684971644,
        "NumberOfUndirectedEdges" : 12,
        "name" : "dre-miR-338-3p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.177380396,
        "NeighborhoodConnectivity" : 7.583333333333333
      },
      "position" : {
        "x" : -167.06881350239968,
        "y" : -159.6783283690283
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "609",
        "degree_layout" : 11,
        "padj" : 0.018471355,
        "Eccentricity" : 8,
        "pvalue" : 1.61797E-4,
        "shared_name" : "rin1b",
        "TopologicalCoefficient" : 0.2784992784992785,
        "baseMean" : 22.77810974,
        "SUID" : 609,
        "lfcSE" : 0.757542557,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2275862068965515,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.30982905982905984,
        "stat" : -3.772227093,
        "Degree" : 11,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9231866825208086,
        "Stress" : 45388,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.026405224177621665,
        "NumberOfUndirectedEdges" : 11,
        "name" : "rin1b",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -2.857622558,
        "NeighborhoodConnectivity" : 18.545454545454547
      },
      "position" : {
        "x" : -67.34116988368623,
        "y" : -705.5455570498598
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "607",
        "degree_layout" : 29,
        "padj" : 0.001565389,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-722",
        "TopologicalCoefficient" : 0.20689655172413793,
        "SUID" : 607,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.475862068965517,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.28769841269841273,
        "Degree" : 29,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9146254458977408,
        "Stress" : 199182,
        "target_original" : "odad1",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.11812107695261823,
        "NumberOfUndirectedEdges" : 29,
        "name" : "dre-miR-722",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.690857087,
        "NeighborhoodConnectivity" : 6.379310344827586
      },
      "position" : {
        "x" : -141.84358308398805,
        "y" : -369.395459460633
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "605",
        "degree_layout" : 13,
        "padj" : 0.014305983,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-499-5p",
        "TopologicalCoefficient" : 0.20146520146520147,
        "SUID" : 605,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.793103448275862,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2636363636363636,
        "Degree" : 13,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9036860879904876,
        "Stress" : 55734,
        "target_original" : "ptprja",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.057433939550652895,
        "NumberOfUndirectedEdges" : 13,
        "name" : "dre-miR-499-5p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : -1.9849915,
        "NeighborhoodConnectivity" : 5.230769230769231
      },
      "position" : {
        "x" : -327.557993680387,
        "y" : -236.76422440174403
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "603",
        "degree_layout" : 9,
        "padj" : 0.031382479,
        "Eccentricity" : 8,
        "pvalue" : 3.97592E-4,
        "shared_name" : "vsnl1a",
        "TopologicalCoefficient" : 0.2981029810298103,
        "baseMean" : 24.53390176,
        "SUID" : 603,
        "lfcSE" : 0.857654747,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5586206896551724,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2810077519379845,
        "stat" : -3.541676959,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9117717003567182,
        "Stress" : 15524,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.014983371903198732,
        "NumberOfUndirectedEdges" : 9,
        "name" : "vsnl1a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -3.037536058,
        "NeighborhoodConnectivity" : 13.222222222222221
      },
      "position" : {
        "x" : -543.3327680706468,
        "y" : 83.64650090052645
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "601",
        "degree_layout" : 2,
        "padj" : 0.01762061,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-125c-3p",
        "TopologicalCoefficient" : 0.6176470588235294,
        "SUID" : 601,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.124137931034483,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.24247491638795987,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8922711058263971,
        "Stress" : 108,
        "target_original" : "sv2a",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 9.809940692797085E-5,
        "NumberOfUndirectedEdges" : 2,
        "name" : "dre-miR-125c-3p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : 2.446373515,
        "NeighborhoodConnectivity" : 11.5
      },
      "position" : {
        "x" : -530.6116544669203,
        "y" : -405.2927186091256
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "599",
        "degree_layout" : 6,
        "padj" : 4.51764E-4,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-196a-5p",
        "TopologicalCoefficient" : 0.3888888888888889,
        "SUID" : 599,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8482758620689657,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.25985663082437277,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9017835909631391,
        "Stress" : 7830,
        "target_original" : "creg2",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.004027594898074757,
        "NumberOfUndirectedEdges" : 6,
        "name" : "dre-miR-196a-5p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : 2.349251031,
        "NeighborhoodConnectivity" : 10.333333333333334
      },
      "position" : {
        "x" : -485.5069479710011,
        "y" : -336.6836258148953
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "597",
        "degree_layout" : 7,
        "padj" : 0.007482137,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-196d",
        "TopologicalCoefficient" : 0.36,
        "SUID" : 597,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.806896551724138,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.26268115942028986,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9032104637336504,
        "Stress" : 10080,
        "target_original" : "cyp2p8",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.01556375457938104,
        "NumberOfUndirectedEdges" : 7,
        "name" : "dre-miR-196d",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : 2.314580565,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : -406.3269312042411,
        "y" : -405.9796791026454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "595",
        "degree_layout" : 14,
        "padj" : 0.017944376,
        "Eccentricity" : 8,
        "pvalue" : 1.54517E-4,
        "shared_name" : "sv2a",
        "TopologicalCoefficient" : 0.1834975369458128,
        "baseMean" : 29.93632015,
        "SUID" : 595,
        "lfcSE" : 0.896986126,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2551724137931033,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.3072033898305085,
        "stat" : -3.78369554,
        "Degree" : 14,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9222354340071344,
        "Stress" : 52640,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.042088222551419446,
        "NumberOfUndirectedEdges" : 14,
        "name" : "sv2a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -3.393922403,
        "NeighborhoodConnectivity" : 11.642857142857142
      },
      "position" : {
        "x" : -592.3381735544244,
        "y" : 47.14680420074728
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "593",
        "degree_layout" : 6,
        "padj" : 0.001565389,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-10b-5p",
        "TopologicalCoefficient" : 0.38333333333333336,
        "SUID" : 593,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.972413793103448,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2517361111111111,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8975029726516052,
        "Stress" : 6224,
        "target_original" : "dusp7",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.002234965720219339,
        "NumberOfUndirectedEdges" : 6,
        "name" : "dre-miR-10b-5p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : 1.137180747,
        "NeighborhoodConnectivity" : 8.666666666666666
      },
      "position" : {
        "x" : -251.54140103018335,
        "y" : -382.7362789587523
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "591",
        "degree_layout" : 7,
        "padj" : 0.001106258,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-10a-5p",
        "TopologicalCoefficient" : 0.3357142857142857,
        "SUID" : 591,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.9586206896551723,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.25261324041811845,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8979785969084423,
        "Stress" : 11838,
        "target_original" : "odad1",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.004621236280737397,
        "NumberOfUndirectedEdges" : 7,
        "name" : "dre-miR-10a-5p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : 1.805698621,
        "NeighborhoodConnectivity" : 7.714285714285714
      },
      "position" : {
        "x" : -194.0247804503909,
        "y" : -103.38530135797374
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "589",
        "degree_layout" : 8,
        "padj" : 1.03E-6,
        "Eccentricity" : 8,
        "pvalue" : 3.06E-10,
        "shared_name" : "gspt1",
        "TopologicalCoefficient" : 0.35049019607843135,
        "baseMean" : 90.26209275,
        "SUID" : 589,
        "lfcSE" : 0.247208176,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.43448275862069,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2911646586345381,
        "stat" : -6.295850688,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9160523186682521,
        "Stress" : 28898,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.012178758139364488,
        "NumberOfUndirectedEdges" : 8,
        "name" : "gspt1",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.556385762,
        "NeighborhoodConnectivity" : 18.875
      },
      "position" : {
        "x" : -594.5735461140575,
        "y" : -476.89626663054514
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "587",
        "degree_layout" : 5,
        "padj" : 0.04807089,
        "Eccentricity" : 8,
        "pvalue" : 8.83906E-4,
        "shared_name" : "aldob",
        "TopologicalCoefficient" : 0.43478260869565216,
        "baseMean" : 62.87592494,
        "SUID" : 587,
        "lfcSE" : 0.486546496,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5448275862068965,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2821011673151751,
        "stat" : -3.325088154,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9122473246135553,
        "Stress" : 13120,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.004631901524211847,
        "NumberOfUndirectedEdges" : 5,
        "name" : "aldob",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.61780999,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -509.4655642233847,
        "y" : 123.31043422524817
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "585",
        "degree_layout" : 4,
        "padj" : 0.028113198,
        "Eccentricity" : 8,
        "pvalue" : 3.25555E-4,
        "shared_name" : "pcdh10a",
        "TopologicalCoefficient" : 0.3776595744680851,
        "baseMean" : 13.7252833,
        "SUID" : 585,
        "lfcSE" : 0.687386371,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5448275862068965,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2821011673151751,
        "stat" : -3.594067915,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9122473246135553,
        "Stress" : 9878,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0033835166319568354,
        "NumberOfUndirectedEdges" : 4,
        "name" : "pcdh10a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -2.4705133,
        "NeighborhoodConnectivity" : 18.75
      },
      "position" : {
        "x" : -386.75463437344297,
        "y" : 177.29812973029038
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "583",
        "degree_layout" : 2,
        "padj" : 0.038472006,
        "Eccentricity" : 10,
        "pvalue" : 5.63553E-4,
        "shared_name" : "en1a",
        "TopologicalCoefficient" : 0.9166666666666666,
        "baseMean" : 10.48275884,
        "SUID" : 583,
        "lfcSE" : 1.153142827,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.620689655172414,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2164179104477612,
        "stat" : -3.448575009,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8751486325802617,
        "Stress" : 10,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 1.647531249458227E-5,
        "NumberOfUndirectedEdges" : 2,
        "name" : "en1a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -3.976699535,
        "NeighborhoodConnectivity" : 17.5
      },
      "position" : {
        "x" : -126.25109278067248,
        "y" : 165.73479058961675
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "581",
        "degree_layout" : 1,
        "padj" : 0.026427573,
        "Eccentricity" : 10,
        "pvalue" : 2.89033E-4,
        "shared_name" : "zgc:174895",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 52.82559338,
        "SUID" : 581,
        "lfcSE" : 0.293838229,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.63448275862069,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2157738095238095,
        "stat" : 3.624935849,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8746730083234244,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "zgc:174895",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.065144729,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : 254.7079177608539,
        "y" : -487.44761463486066
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "579",
        "degree_layout" : 14,
        "padj" : 0.040609825,
        "Eccentricity" : 8,
        "pvalue" : 6.37875E-4,
        "shared_name" : "frmpd3",
        "TopologicalCoefficient" : 0.22174840085287847,
        "baseMean" : 14.03332772,
        "SUID" : 579,
        "lfcSE" : 0.997123618,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.1310344827586207,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.31938325991189426,
        "stat" : -3.414976608,
        "Degree" : 14,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9265160523186682,
        "Stress" : 82012,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.060604930047327435,
        "NumberOfUndirectedEdges" : 14,
        "name" : "frmpd3",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -3.405153832,
        "NeighborhoodConnectivity" : 15.857142857142858
      },
      "position" : {
        "x" : -662.7728249738866,
        "y" : -89.17651121917879
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "577",
        "degree_layout" : 6,
        "padj" : 0.038063316,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-202-3p",
        "TopologicalCoefficient" : 0.30701754385964913,
        "SUID" : 577,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.9172413793103447,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.25528169014084506,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8994054696789536,
        "Stress" : 12122,
        "target_original" : "mllt1b",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.028007925542184793,
        "NumberOfUndirectedEdges" : 6,
        "name" : "dre-miR-202-3p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : 2.217015149,
        "NeighborhoodConnectivity" : 6.833333333333333
      },
      "position" : {
        "x" : -266.562374444692,
        "y" : -438.201768139735
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "575",
        "degree_layout" : 1,
        "padj" : 0.025002679,
        "Eccentricity" : 10,
        "pvalue" : 2.58601E-4,
        "shared_name" : "dock9b",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 664.1405855,
        "SUID" : 575,
        "lfcSE" : 0.299933346,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.620689655172414,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2164179104477612,
        "stat" : 3.653587636,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8751486325802617,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "dock9b",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.095832765,
        "NeighborhoodConnectivity" : 20.0
      },
      "position" : {
        "x" : 187.0103491460759,
        "y" : -370.5350044726947
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "573",
        "degree_layout" : 5,
        "padj" : 0.043393884,
        "Eccentricity" : 8,
        "pvalue" : 7.04369E-4,
        "shared_name" : "xkr4",
        "TopologicalCoefficient" : 0.37777777777777777,
        "baseMean" : 14.09115515,
        "SUID" : 573,
        "lfcSE" : 0.780600544,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5586206896551724,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2810077519379845,
        "stat" : -3.387872701,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9117717003567182,
        "Stress" : 7950,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0039013155340429178,
        "NumberOfUndirectedEdges" : 5,
        "name" : "xkr4",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -2.644575275,
        "NeighborhoodConnectivity" : 18.0
      },
      "position" : {
        "x" : -347.0329429785925,
        "y" : -755.8158985465416
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "571",
        "degree_layout" : 12,
        "padj" : 3.11238E-4,
        "Eccentricity" : 8,
        "pvalue" : 4.62E-7,
        "shared_name" : "rbfox3a",
        "TopologicalCoefficient" : 0.2833333333333333,
        "baseMean" : 109.9321524,
        "SUID" : 571,
        "lfcSE" : 0.240176938,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.3241379310344827,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.3008298755186722,
        "stat" : -5.041426461,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9198573127229489,
        "Stress" : 46984,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.034587509121370576,
        "NumberOfUndirectedEdges" : 12,
        "name" : "rbfox3a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.210834368,
        "NeighborhoodConnectivity" : 16.583333333333332
      },
      "position" : {
        "x" : -311.66525012414786,
        "y" : 170.3721080659161
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "569",
        "degree_layout" : 5,
        "padj" : 0.026651409,
        "Eccentricity" : 9,
        "shared_name" : "dre-let-7b",
        "TopologicalCoefficient" : 0.2375,
        "SUID" : 569,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.041379310344827,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.24744027303754268,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8951248513674198,
        "Stress" : 8110,
        "target_original" : "fkbp11",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.015574107375861602,
        "NumberOfUndirectedEdges" : 5,
        "name" : "dre-let-7b",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : 1.114075735,
        "NeighborhoodConnectivity" : 4.8
      },
      "position" : {
        "x" : 70.05144041065068,
        "y" : -115.06570662281592
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "567",
        "degree_layout" : 1,
        "padj" : 0.040549909,
        "Eccentricity" : 10,
        "pvalue" : 6.14058E-4,
        "shared_name" : "rbp4",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 26.35828211,
        "SUID" : 567,
        "lfcSE" : 0.420428109,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.731034482758621,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.21137026239067055,
        "stat" : -3.425327774,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8713436385255648,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "rbp4",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.440104079,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : -202.8844354970497,
        "y" : 306.9491687100526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "565",
        "degree_layout" : 5,
        "padj" : 0.006249789,
        "Eccentricity" : 8,
        "pvalue" : 3.09E-5,
        "shared_name" : "pcdh2ab9",
        "TopologicalCoefficient" : 0.36666666666666664,
        "baseMean" : 36.64035407,
        "SUID" : 565,
        "lfcSE" : 0.857242895,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5172413793103448,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.28431372549019607,
        "stat" : -4.166517375,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9131985731272295,
        "Stress" : 11820,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.005438703870459274,
        "NumberOfUndirectedEdges" : 5,
        "name" : "pcdh2ab9",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -3.571717415,
        "NeighborhoodConnectivity" : 18.6
      },
      "position" : {
        "x" : 162.36199063313816,
        "y" : -493.14285305483514
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "563",
        "degree_layout" : 5,
        "padj" : 4.5527E-4,
        "Eccentricity" : 8,
        "pvalue" : 7.89E-7,
        "shared_name" : "spry4",
        "TopologicalCoefficient" : 0.34509803921568627,
        "baseMean" : 262.2483177,
        "SUID" : 563,
        "lfcSE" : 0.25617602,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.475862068965517,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.28769841269841273,
        "stat" : 4.938177621,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9146254458977408,
        "Stress" : 8290,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.007126945555786249,
        "NumberOfUndirectedEdges" : 5,
        "name" : "spry4",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.265042687,
        "NeighborhoodConnectivity" : 18.6
      },
      "position" : {
        "x" : -483.78301108282176,
        "y" : -690.1522211239062
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "561",
        "degree_layout" : 8,
        "padj" : 0.005113333,
        "Eccentricity" : 6,
        "pvalue" : 2.19E-5,
        "shared_name" : "acsl1a",
        "TopologicalCoefficient" : 0.2848360655737705,
        "baseMean" : 83.77573942,
        "SUID" : 561,
        "lfcSE" : 0.328627147,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.910344827586207,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.34360189573459715,
        "stat" : 4.244179937,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9341260404280618,
        "Stress" : 732348,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.4344131353386969,
        "NumberOfUndirectedEdges" : 8,
        "name" : "acsl1a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.394752745,
        "NeighborhoodConnectivity" : 18.375
      },
      "position" : {
        "x" : 28.46208137542999,
        "y" : 221.50483879030799
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "559",
        "degree_layout" : 8,
        "padj" : 0.045482821,
        "Eccentricity" : 8,
        "pvalue" : 7.97801E-4,
        "shared_name" : "ptchd1",
        "TopologicalCoefficient" : 0.3229166666666667,
        "baseMean" : 12.14089415,
        "SUID" : 559,
        "lfcSE" : 1.294354615,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.310344827586207,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.3020833333333333,
        "stat" : -3.353556443,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.920332936979786,
        "Stress" : 32346,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.01984890707724753,
        "NumberOfUndirectedEdges" : 8,
        "name" : "ptchd1",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -4.34069126,
        "NeighborhoodConnectivity" : 20.375
      },
      "position" : {
        "x" : -661.5580426705128,
        "y" : -145.96895776924794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "557",
        "degree_layout" : 10,
        "padj" : 0.013558824,
        "Eccentricity" : 8,
        "pvalue" : 1.03333E-4,
        "shared_name" : "cpe",
        "TopologicalCoefficient" : 0.29454545454545455,
        "baseMean" : 23.86867615,
        "SUID" : 557,
        "lfcSE" : 0.991498823,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.3517241379310345,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.29835390946502055,
        "stat" : -3.882628349,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9189060642092746,
        "Stress" : 39554,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.023328214494095573,
        "NumberOfUndirectedEdges" : 10,
        "name" : "cpe",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -3.84962144,
        "NeighborhoodConnectivity" : 17.2
      },
      "position" : {
        "x" : -232.1974972288881,
        "y" : -687.7959483542218
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "555",
        "degree_layout" : 2,
        "padj" : 0.025862763,
        "Eccentricity" : 8,
        "pvalue" : 2.75177E-4,
        "shared_name" : "acvr1c",
        "TopologicalCoefficient" : 0.5172413793103449,
        "baseMean" : 100.3749539,
        "SUID" : 555,
        "lfcSE" : 0.428341852,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.820689655172414,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.26173285198555957,
        "stat" : 3.637612861,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9027348394768132,
        "Stress" : 1270,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.002164219517393313,
        "NumberOfUndirectedEdges" : 2,
        "name" : "acvr1c",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.55814183,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : 206.4005674274813,
        "y" : -540.5037008436921
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "553",
        "degree_layout" : 3,
        "padj" : 0.040586356,
        "Eccentricity" : 8,
        "pvalue" : 6.26661E-4,
        "shared_name" : "npdc1b",
        "TopologicalCoefficient" : 0.6666666666666666,
        "baseMean" : 175.4067092,
        "SUID" : 553,
        "lfcSE" : 0.456403323,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7655172413793103,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.26556776556776557,
        "stat" : -3.419804642,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9046373365041617,
        "Stress" : 362,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 2.997680160142224E-4,
        "NumberOfUndirectedEdges" : 3,
        "name" : "npdc1b",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.560810201,
        "NeighborhoodConnectivity" : 22.333333333333332
      },
      "position" : {
        "x" : -497.9129739827331,
        "y" : -567.3092648847378
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "551",
        "degree_layout" : 2,
        "padj" : 0.038442563,
        "Eccentricity" : 10,
        "pvalue" : 5.61219E-4,
        "shared_name" : "per1a",
        "TopologicalCoefficient" : 0.5333333333333333,
        "baseMean" : 46.99748109,
        "SUID" : 551,
        "lfcSE" : 0.38998028,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.468965517241379,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.22376543209876543,
        "stat" : -3.449695507,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8803804994054697,
        "Stress" : 332,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 9.055176876741337E-4,
        "NumberOfUndirectedEdges" : 2,
        "name" : "per1a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.345313219,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : -58.515112865075935,
        "y" : 157.79615136314533
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "549",
        "degree_layout" : 2,
        "padj" : 2.55E-5,
        "Eccentricity" : 8,
        "pvalue" : 1.89E-8,
        "shared_name" : "nkx6.2",
        "TopologicalCoefficient" : 0.58,
        "baseMean" : 95.98463432,
        "SUID" : 549,
        "lfcSE" : 0.541282063,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8758620689655174,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2580071174377224,
        "stat" : 5.621572369,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9008323424494649,
        "Stress" : 1306,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 6.439281670021699E-4,
        "NumberOfUndirectedEdges" : 2,
        "name" : "nkx6.2",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 3.042856288,
        "NeighborhoodConnectivity" : 15.5
      },
      "position" : {
        "x" : -383.16099237359595,
        "y" : -601.1703499200521
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "547",
        "degree_layout" : 6,
        "padj" : 4.34E-6,
        "Eccentricity" : 10,
        "pvalue" : 1.5E-9,
        "shared_name" : "slc35d1a",
        "TopologicalCoefficient" : 0.3333333333333333,
        "baseMean" : 250.0556474,
        "SUID" : 547,
        "lfcSE" : 0.186138288,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.096551724137931,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.24410774410774413,
        "stat" : -6.044001995,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8932223543400714,
        "Stress" : 2716,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.004507414657461168,
        "NumberOfUndirectedEdges" : 6,
        "name" : "slc35d1a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.125020183,
        "NeighborhoodConnectivity" : 17.666666666666668
      },
      "position" : {
        "x" : 194.4554794307572,
        "y" : -189.82714865788105
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "degree_layout" : 10,
        "padj" : 0.029018129,
        "Eccentricity" : 8,
        "pvalue" : 3.43098E-4,
        "shared_name" : "pcnx2",
        "TopologicalCoefficient" : 0.21525423728813559,
        "baseMean" : 14.43050792,
        "SUID" : 545,
        "lfcSE" : 0.866872178,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.296551724137931,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.303347280334728,
        "stat" : -3.580377548,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.920808561236623,
        "Stress" : 34950,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.029246708075215174,
        "NumberOfUndirectedEdges" : 10,
        "name" : "pcnx2",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -3.103729684,
        "NeighborhoodConnectivity" : 13.7
      },
      "position" : {
        "x" : -671.653324103143,
        "y" : -33.34626917843707
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "543",
        "degree_layout" : 2,
        "padj" : 0.026651409,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-34c-3p",
        "TopologicalCoefficient" : 0.6666666666666666,
        "SUID" : 543,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.179310344827586,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.23927392739273928,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8903686087990488,
        "Stress" : 50,
        "target_original" : "si:ch211-247j9.1",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 7.116109660888836E-5,
        "NumberOfUndirectedEdges" : 2,
        "name" : "dre-miR-34c-3p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : 1.442559261,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : -172.53000467523816,
        "y" : 59.687965789067675
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "541",
        "degree_layout" : 3,
        "padj" : 0.002253827,
        "Eccentricity" : 8,
        "pvalue" : 7.14E-6,
        "shared_name" : "neurl1ab",
        "TopologicalCoefficient" : 0.44166666666666665,
        "baseMean" : 247.207428,
        "SUID" : 541,
        "lfcSE" : 0.315254908,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6551724137931036,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.27358490566037735,
        "stat" : 4.489520647,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9084423305588585,
        "Stress" : 6350,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.00191357076542444,
        "NumberOfUndirectedEdges" : 3,
        "name" : "neurl1ab",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.415343419,
        "NeighborhoodConnectivity" : 18.666666666666668
      },
      "position" : {
        "x" : -283.40487586025847,
        "y" : -727.9642031545372
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "539",
        "degree_layout" : 7,
        "padj" : 9.97292E-4,
        "Eccentricity" : 8,
        "pvalue" : 2.62E-6,
        "shared_name" : "plxnb1b",
        "TopologicalCoefficient" : 0.40476190476190477,
        "baseMean" : 904.0415096,
        "SUID" : 539,
        "lfcSE" : 0.241584258,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.406896551724138,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2935222672064777,
        "stat" : 4.698893338,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9170035671819263,
        "Stress" : 24816,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.007800571818806668,
        "NumberOfUndirectedEdges" : 7,
        "name" : "plxnb1b",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.135178659,
        "NeighborhoodConnectivity" : 22.857142857142858
      },
      "position" : {
        "x" : -644.0251204088418,
        "y" : -316.00409088429296
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "537",
        "degree_layout" : 9,
        "padj" : 0.002893751,
        "Eccentricity" : 8,
        "pvalue" : 1.02E-5,
        "shared_name" : "tgfb1a",
        "TopologicalCoefficient" : 0.3292929292929293,
        "baseMean" : 46.39842972,
        "SUID" : 537,
        "lfcSE" : 0.642271433,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.3655172413793104,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2971311475409836,
        "stat" : -4.41222845,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9184304399524376,
        "Stress" : 32432,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.014472916139477567,
        "NumberOfUndirectedEdges" : 9,
        "name" : "tgfb1a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -2.83384829,
        "NeighborhoodConnectivity" : 19.11111111111111
      },
      "position" : {
        "x" : -458.9790772971028,
        "y" : 120.73297614445619
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "535",
        "degree_layout" : 1,
        "padj" : 6.42E-6,
        "Eccentricity" : 10,
        "pvalue" : 2.86E-9,
        "shared_name" : "hsp70.3",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 214.3308194,
        "SUID" : 535,
        "lfcSE" : 0.385828201,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.786206896551724,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.20893371757925072,
        "stat" : 5.939464931,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8694411414982164,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "hsp70.3",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 2.291613066,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 141.14588920796814,
        "y" : -270.09845055802725
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "degree_layout" : 5,
        "padj" : 0.045323421,
        "Eccentricity" : 8,
        "pvalue" : 7.80521E-4,
        "shared_name" : "kctd1",
        "TopologicalCoefficient" : 0.35,
        "baseMean" : 75.62773627,
        "SUID" : 533,
        "lfcSE" : 0.693854075,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5724137931034483,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2799227799227799,
        "stat" : 3.359611616,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9112960760998812,
        "Stress" : 7570,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0035406385530830204,
        "NumberOfUndirectedEdges" : 5,
        "name" : "kctd1",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 2.331080211,
        "NeighborhoodConnectivity" : 16.4
      },
      "position" : {
        "x" : -181.94235368027876,
        "y" : 197.55731471187028
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "531",
        "degree_layout" : 5,
        "padj" : 7.39938E-4,
        "Eccentricity" : 8,
        "pvalue" : 1.72E-6,
        "shared_name" : "fam171a2a",
        "TopologicalCoefficient" : 0.31,
        "baseMean" : 202.3019618,
        "SUID" : 531,
        "lfcSE" : 0.267350325,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.627586206896552,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2756653992395437,
        "stat" : 4.7836922,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9093935790725327,
        "Stress" : 11134,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0066823306717864895,
        "NumberOfUndirectedEdges" : 5,
        "name" : "fam171a2a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.278921664,
        "NeighborhoodConnectivity" : 13.4
      },
      "position" : {
        "x" : -512.917911577315,
        "y" : -613.1155241564702
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "529",
        "degree_layout" : 2,
        "padj" : 0.005647219,
        "Eccentricity" : 9,
        "shared_name" : "dre-miR-10b-3p",
        "TopologicalCoefficient" : 0.5,
        "SUID" : 529,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.317241379310345,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.231629392971246,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8856123662306777,
        "Stress" : 5024,
        "target_original" : "cfap74",
        "feature_type" : "miRNA",
        "BetweennessCentrality" : 0.013793103448275862,
        "NumberOfUndirectedEdges" : 2,
        "name" : "dre-miR-10b-3p",
        "interaction" : "miRNA_gene",
        "IsSingleNode" : false,
        "log2FC" : 1.713231204,
        "NeighborhoodConnectivity" : 5.5
      },
      "position" : {
        "x" : -722.2117596427415,
        "y" : -710.8017929264897
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "527",
        "degree_layout" : 10,
        "padj" : 1.35337E-4,
        "Eccentricity" : 8,
        "pvalue" : 1.61E-7,
        "shared_name" : "camta1b",
        "TopologicalCoefficient" : 0.3053571428571429,
        "baseMean" : 195.1990868,
        "SUID" : 527,
        "lfcSE" : 0.22426121,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.3379310344827586,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.29958677685950413,
        "stat" : -5.239811624,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9193816884661118,
        "Stress" : 48088,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.041746558789940096,
        "NumberOfUndirectedEdges" : 10,
        "name" : "camta1b",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.175086495,
        "NeighborhoodConnectivity" : 18.1
      },
      "position" : {
        "x" : -584.4973421992181,
        "y" : -532.99906091101
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "525",
        "degree_layout" : 1,
        "padj" : 0.045323421,
        "Eccentricity" : 8,
        "pvalue" : 7.81864E-4,
        "shared_name" : "hoxd9a",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 35.04646328,
        "SUID" : 525,
        "lfcSE" : 0.629198334,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8758620689655174,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2580071174377224,
        "stat" : 3.359136704,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9008323424494649,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "hoxd9a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 2.113563219,
        "NeighborhoodConnectivity" : 27.0
      },
      "position" : {
        "x" : -480.1351903559698,
        "y" : 202.0622000458825
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "523",
        "degree_layout" : 5,
        "padj" : 2.13E-5,
        "Eccentricity" : 10,
        "pvalue" : 1.48E-8,
        "shared_name" : "micu3b",
        "TopologicalCoefficient" : 0.3038461538461538,
        "baseMean" : 113.7873818,
        "SUID" : 523,
        "lfcSE" : 0.262651368,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.082758620689655,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.24493243243243243,
        "stat" : -5.664114381,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8936979785969084,
        "Stress" : 2712,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.008460159897541626,
        "NumberOfUndirectedEdges" : 5,
        "name" : "micu3b",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.487687389,
        "NeighborhoodConnectivity" : 16.8
      },
      "position" : {
        "x" : 96.53901901479247,
        "y" : -541.8535856806496
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "521",
        "degree_layout" : 12,
        "padj" : 0.044315708,
        "Eccentricity" : 8,
        "pvalue" : 7.47843E-4,
        "shared_name" : "atp2b3b",
        "TopologicalCoefficient" : 0.2629310344827586,
        "baseMean" : 44.40178981,
        "SUID" : 521,
        "lfcSE" : 0.752902098,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.282758620689655,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.3046218487394958,
        "stat" : -3.371410754,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9212841854934601,
        "Stress" : 40606,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.024072516173319628,
        "NumberOfUndirectedEdges" : 12,
        "name" : "atp2b3b",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -2.53834223,
        "NeighborhoodConnectivity" : 16.25
      },
      "position" : {
        "x" : -541.7453840096858,
        "y" : -97.86240432307345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "519",
        "degree_layout" : 2,
        "padj" : 0.040609825,
        "Eccentricity" : 8,
        "pvalue" : 6.38586E-4,
        "shared_name" : "evx2",
        "TopologicalCoefficient" : 0.5757575757575758,
        "baseMean" : 22.13330929,
        "SUID" : 519,
        "lfcSE" : 0.467516232,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.779310344827586,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2645985401459854,
        "stat" : -3.414673285,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9041617122473247,
        "Stress" : 1996,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 6.960023179120353E-4,
        "NumberOfUndirectedEdges" : 2,
        "name" : "evx2",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.596415187,
        "NeighborhoodConnectivity" : 20.0
      },
      "position" : {
        "x" : 270.1337708888459,
        "y" : -25.43073652772
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "517",
        "degree_layout" : 2,
        "padj" : 4.31E-5,
        "Eccentricity" : 10,
        "pvalue" : 4.06E-8,
        "shared_name" : "matn4",
        "TopologicalCoefficient" : 0.5405405405405406,
        "baseMean" : 47.19108849,
        "SUID" : 517,
        "lfcSE" : 0.549894675,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.3310344827586205,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.23089171974522293,
        "stat" : 5.488361827,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8851367419738406,
        "Stress" : 520,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.001367191159810573,
        "NumberOfUndirectedEdges" : 2,
        "name" : "matn4",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 3.018020942,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -756.7894524510775,
        "y" : -454.4306101050606
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "515",
        "degree_layout" : 1,
        "padj" : 0.004960099,
        "Eccentricity" : 10,
        "pvalue" : 2.09E-5,
        "shared_name" : "tent5ba",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 223.6612455,
        "SUID" : 515,
        "lfcSE" : 0.357541103,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.910344827586207,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.20365168539325842,
        "stat" : 4.255433116,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8651605231866825,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "tent5ba",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.52149225,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : -594.5908867235557,
        "y" : -768.6313777568866
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "513",
        "degree_layout" : 2,
        "padj" : 1.86E-5,
        "Eccentricity" : 8,
        "pvalue" : 1.19E-8,
        "shared_name" : "glula",
        "TopologicalCoefficient" : 0.6176470588235294,
        "baseMean" : 1518.299647,
        "SUID" : 513,
        "lfcSE" : 0.246428406,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.0137931034482754,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2491408934707904,
        "stat" : 5.700619379,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8960760998810939,
        "Stress" : 920,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 3.4584066101104124E-4,
        "NumberOfUndirectedEdges" : 2,
        "name" : "glula",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.404794545,
        "NeighborhoodConnectivity" : 11.5
      },
      "position" : {
        "x" : -664.8771606125083,
        "y" : -592.0727657222596
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "511",
        "degree_layout" : 4,
        "padj" : 5.78E-6,
        "Eccentricity" : 10,
        "pvalue" : 2.29E-9,
        "shared_name" : "srsf5b",
        "TopologicalCoefficient" : 0.375,
        "baseMean" : 673.0371086,
        "SUID" : 511,
        "lfcSE" : 0.173052002,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.372413793103449,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.22870662460567823,
        "stat" : -5.975923653,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8837098692033294,
        "Stress" : 552,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.001028166831872612,
        "NumberOfUndirectedEdges" : 4,
        "name" : "srsf5b",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.034145551,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -702.9715183809021,
        "y" : -267.3479565430316
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "509",
        "degree_layout" : 7,
        "padj" : 0.008015162,
        "Eccentricity" : 8,
        "pvalue" : 4.4E-5,
        "shared_name" : "nphs1",
        "TopologicalCoefficient" : 0.38095238095238093,
        "baseMean" : 79.7830528,
        "SUID" : 509,
        "lfcSE" : 0.245686382,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4482758620689653,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.29000000000000004,
        "stat" : -4.085254908,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.915576694411415,
        "Stress" : 23724,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.012165923268831154,
        "NumberOfUndirectedEdges" : 7,
        "name" : "nphs1",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.0036915,
        "NeighborhoodConnectivity" : 20.428571428571427
      },
      "position" : {
        "x" : -398.19414049164334,
        "y" : -716.7140485192213
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "507",
        "degree_layout" : 7,
        "padj" : 0.017145013,
        "Eccentricity" : 8,
        "pvalue" : 1.45937E-4,
        "shared_name" : "smad3b",
        "TopologicalCoefficient" : 0.4198250728862974,
        "baseMean" : 162.4278385,
        "SUID" : 507,
        "lfcSE" : 0.2649747,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.475862068965517,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.28769841269841273,
        "stat" : 3.797883866,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9146254458977408,
        "Stress" : 22024,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.007537917659343023,
        "NumberOfUndirectedEdges" : 7,
        "name" : "smad3b",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.006343137,
        "NeighborhoodConnectivity" : 21.571428571428573
      },
      "position" : {
        "x" : -631.6085891124676,
        "y" : -394.924173088948
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "505",
        "degree_layout" : 1,
        "padj" : 0.038442563,
        "Eccentricity" : 10,
        "pvalue" : 5.609E-4,
        "shared_name" : "hnf1bb",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 180.9826723,
        "SUID" : 505,
        "lfcSE" : 0.655610648,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.910344827586207,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.20365168539325842,
        "stat" : 3.449848901,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8651605231866825,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "hnf1bb",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 2.261757672,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : -43.44660727265,
        "y" : -839.8607928743731
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "503",
        "degree_layout" : 12,
        "padj" : 6.53609E-4,
        "Eccentricity" : 8,
        "pvalue" : 1.46E-6,
        "shared_name" : "mllt1b",
        "TopologicalCoefficient" : 0.24166666666666667,
        "baseMean" : 93.26670058,
        "SUID" : 503,
        "lfcSE" : 0.242046201,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2551724137931033,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.3072033898305085,
        "stat" : -4.817242931,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9222354340071344,
        "Stress" : 41072,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.03239191358881107,
        "NumberOfUndirectedEdges" : 12,
        "name" : "mllt1b",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.165995351,
        "NeighborhoodConnectivity" : 15.5
      },
      "position" : {
        "x" : -566.6155799440688,
        "y" : -42.96378413225723
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "501",
        "degree_layout" : 8,
        "padj" : 0.029618886,
        "Eccentricity" : 8,
        "pvalue" : 3.53251E-4,
        "shared_name" : "iqgap2",
        "TopologicalCoefficient" : 0.35714285714285715,
        "baseMean" : 232.7250853,
        "SUID" : 501,
        "lfcSE" : 0.584119183,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.3655172413793104,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2971311475409836,
        "stat" : 3.572750402,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9184304399524376,
        "Stress" : 34224,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.011701586768659799,
        "NumberOfUndirectedEdges" : 8,
        "name" : "iqgap2",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 2.086912045,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : 68.7623981571669,
        "y" : 96.67152796317532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "499",
        "degree_layout" : 8,
        "padj" : 0.04807089,
        "Eccentricity" : 8,
        "pvalue" : 8.81592E-4,
        "shared_name" : "si:ch211-247j9.1",
        "TopologicalCoefficient" : 0.32407407407407407,
        "baseMean" : 20.27756079,
        "SUID" : 499,
        "lfcSE" : 0.763048251,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.393103448275862,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2947154471544715,
        "stat" : -3.325818711,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9174791914387633,
        "Stress" : 27002,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.016489433851458717,
        "NumberOfUndirectedEdges" : 8,
        "name" : "si:ch211-247j9.1",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -2.53776015,
        "NeighborhoodConnectivity" : 18.5
      },
      "position" : {
        "x" : -647.2545600684808,
        "y" : 4.73356381917683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "497",
        "degree_layout" : 6,
        "padj" : 0.002480568,
        "Eccentricity" : 8,
        "pvalue" : 8.22E-6,
        "shared_name" : "ptchd4",
        "TopologicalCoefficient" : 0.42592592592592593,
        "baseMean" : 57.57028788,
        "SUID" : 497,
        "lfcSE" : 0.312546625,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.420689655172414,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2923387096774193,
        "stat" : -4.459247846,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9165279429250892,
        "Stress" : 21852,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.007075281453607634,
        "NumberOfUndirectedEdges" : 6,
        "name" : "ptchd4",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.393722863,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : 284.02169134037104,
        "y" : -233.38587277922488
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "495",
        "degree_layout" : 2,
        "padj" : 0.020745719,
        "Eccentricity" : 8,
        "pvalue" : 1.88905E-4,
        "shared_name" : "marcksl1a",
        "TopologicalCoefficient" : 0.5357142857142857,
        "baseMean" : 91.13853129,
        "SUID" : 495,
        "lfcSE" : 0.337475676,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8344827586206898,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2607913669064748,
        "stat" : 3.733409028,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9022592152199762,
        "Stress" : 2366,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0017485129017104117,
        "NumberOfUndirectedEdges" : 2,
        "name" : "marcksl1a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.259934736,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : -728.0538700313191,
        "y" : -347.6361032119894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "493",
        "degree_layout" : 2,
        "padj" : 0.043561192,
        "Eccentricity" : 10,
        "pvalue" : 7.17589E-4,
        "shared_name" : "col14a1a",
        "TopologicalCoefficient" : 0.5535714285714286,
        "baseMean" : 89.93134791,
        "SUID" : 493,
        "lfcSE" : 0.390534893,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.482758620689655,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2230769230769231,
        "stat" : 3.382769214,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8799048751486326,
        "Stress" : 302,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 8.529851251143539E-4,
        "NumberOfUndirectedEdges" : 2,
        "name" : "col14a1a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.321089413,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : -777.76683479434,
        "y" : -227.30766704103735
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "491",
        "degree_layout" : 1,
        "padj" : 0.040586356,
        "Eccentricity" : 10,
        "pvalue" : 6.24945E-4,
        "shared_name" : "bzw2",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 208.2702919,
        "SUID" : 491,
        "lfcSE" : 0.393764798,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.468965517241379,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.22376543209876543,
        "stat" : -3.420550449,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8803804994054697,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "bzw2",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.346892356,
        "NeighborhoodConnectivity" : 29.0
      },
      "position" : {
        "x" : 253.72346089282655,
        "y" : -414.7532597021491
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "489",
        "degree_layout" : 3,
        "padj" : 0.043896436,
        "Eccentricity" : 10,
        "pvalue" : 7.36423E-4,
        "shared_name" : "creg2",
        "TopologicalCoefficient" : 0.4266666666666667,
        "baseMean" : 26.72642643,
        "SUID" : 489,
        "lfcSE" : 0.528293829,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.510344827586207,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.22171253822629972,
        "stat" : -3.375647289,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8789536266349585,
        "Stress" : 192,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 5.123694453212697E-4,
        "NumberOfUndirectedEdges" : 3,
        "name" : "creg2",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.783333632,
        "NeighborhoodConnectivity" : 11.666666666666666
      },
      "position" : {
        "x" : -738.196104936942,
        "y" : -135.17683440542896
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "487",
        "degree_layout" : 4,
        "padj" : 0.037299585,
        "Eccentricity" : 8,
        "pvalue" : 5.35304E-4,
        "shared_name" : "slc6a1b",
        "TopologicalCoefficient" : 0.3275862068965517,
        "baseMean" : 22.88036211,
        "SUID" : 487,
        "lfcSE" : 0.79790183,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.793103448275862,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2636363636363636,
        "stat" : -3.462438828,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9036860879904876,
        "Stress" : 4278,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.005242349918562748,
        "NumberOfUndirectedEdges" : 4,
        "name" : "slc6a1b",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -2.762686277,
        "NeighborhoodConnectivity" : 10.5
      },
      "position" : {
        "x" : -256.3707980362087,
        "y" : 250.35924282495398
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "degree_layout" : 2,
        "padj" : 0.025081318,
        "Eccentricity" : 10,
        "pvalue" : 2.61222E-4,
        "shared_name" : "nr4a2a",
        "TopologicalCoefficient" : 0.5454545454545454,
        "baseMean" : 55.55634583,
        "SUID" : 485,
        "lfcSE" : 0.296901385,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.56551724137931,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2190332326283988,
        "stat" : -3.650999075,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.87705112960761,
        "Stress" : 84,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 2.3057364261691783E-4,
        "NumberOfUndirectedEdges" : 2,
        "name" : "nr4a2a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.083986683,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 201.992294060532,
        "y" : -1.809295634564478
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "483",
        "degree_layout" : 1,
        "padj" : 1.55E-5,
        "Eccentricity" : 10,
        "pvalue" : 7.67E-9,
        "shared_name" : "zgc:64022",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 124.4578368,
        "SUID" : 483,
        "lfcSE" : 0.277623691,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.786206896551724,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.20893371757925072,
        "stat" : 5.77554521,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8694411414982164,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "zgc:64022",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.603428177,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -785.6626777382917,
        "y" : -37.73325829958776
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "481",
        "degree_layout" : 1,
        "padj" : 0.029018129,
        "Eccentricity" : 10,
        "pvalue" : 3.39321E-4,
        "shared_name" : "fkbp11",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 14.59621137,
        "SUID" : 481,
        "lfcSE" : 0.415372619,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.0344827586206895,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.1986301369863014,
        "stat" : -3.583268634,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8608799048751486,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "fkbp11",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.488391679,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 527.4488826551387,
        "y" : -249.60718009756238
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "479",
        "degree_layout" : 1,
        "padj" : 1.82E-7,
        "Eccentricity" : 10,
        "pvalue" : 3.6E-11,
        "shared_name" : "hsp70l",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 147.2158282,
        "SUID" : 479,
        "lfcSE" : 0.520421395,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.468965517241379,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.22376543209876543,
        "stat" : 6.619628784,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8803804994054697,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "hsp70l",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 3.444996443,
        "NeighborhoodConnectivity" : 29.0
      },
      "position" : {
        "x" : 129.25387575638888,
        "y" : 51.10738232455333
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "477",
        "degree_layout" : 1,
        "padj" : 0.027477713,
        "Eccentricity" : 10,
        "pvalue" : 3.1397E-4,
        "shared_name" : "arl16",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 21.99504669,
        "SUID" : 477,
        "lfcSE" : 0.391837631,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.468965517241379,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.22376543209876543,
        "stat" : 3.603492702,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8803804994054697,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "arl16",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.411984044,
        "NeighborhoodConnectivity" : 29.0
      },
      "position" : {
        "x" : 90.35248203588708,
        "y" : -658.5755407164252
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "475",
        "degree_layout" : 1,
        "padj" : 0.001795043,
        "Eccentricity" : 10,
        "pvalue" : 5.24E-6,
        "shared_name" : "hsp70.1",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 151.7999618,
        "SUID" : 475,
        "lfcSE" : 0.662268131,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.468965517241379,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.22376543209876543,
        "stat" : 4.554896812,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8803804994054697,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "hsp70.1",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 3.016562998,
        "NeighborhoodConnectivity" : 29.0
      },
      "position" : {
        "x" : 279.2979270817159,
        "y" : -293.0579442931339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "473",
        "degree_layout" : 2,
        "padj" : 0.020379307,
        "Eccentricity" : 8,
        "pvalue" : 1.82587E-4,
        "shared_name" : "dpydb",
        "TopologicalCoefficient" : 0.5645161290322581,
        "baseMean" : 293.01348,
        "SUID" : 473,
        "lfcSE" : 0.386108743,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.806896551724138,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.26268115942028986,
        "stat" : -3.741964247,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9032104637336504,
        "Stress" : 1364,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 4.536055961978653E-4,
        "NumberOfUndirectedEdges" : 2,
        "name" : "dpydb",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.444805113,
        "NeighborhoodConnectivity" : 18.5
      },
      "position" : {
        "x" : 310.4360238963418,
        "y" : -357.82046526337217
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "471",
        "degree_layout" : 3,
        "padj" : 0.03937105,
        "Eccentricity" : 8,
        "pvalue" : 5.86464E-4,
        "shared_name" : "lgals9l3",
        "TopologicalCoefficient" : 0.8275862068965517,
        "baseMean" : 34.88810095,
        "SUID" : 471,
        "lfcSE" : 0.494637138,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.806896551724138,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.26268115942028986,
        "stat" : 3.437798283,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9032104637336504,
        "Stress" : 94,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 8.885836546797905E-5,
        "NumberOfUndirectedEdges" : 3,
        "name" : "lgals9l3",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.700462705,
        "NeighborhoodConnectivity" : 25.0
      },
      "position" : {
        "x" : -120.32098873206996,
        "y" : -670.9147522242205
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "469",
        "degree_layout" : 2,
        "padj" : 0.027477713,
        "Eccentricity" : 8,
        "pvalue" : 3.12293E-4,
        "shared_name" : "unm_hu7912",
        "TopologicalCoefficient" : 0.5714285714285714,
        "baseMean" : 120.0042692,
        "SUID" : 469,
        "lfcSE" : 0.462161738,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8758620689655174,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2580071174377224,
        "stat" : 3.604883574,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9008323424494649,
        "Stress" : 1858,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 5.312255570363605E-4,
        "NumberOfUndirectedEdges" : 2,
        "name" : "unm_hu7912",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.666039258,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : -341.3834421670326,
        "y" : 219.01550745230634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "degree_layout" : 5,
        "padj" : 0.045323421,
        "Eccentricity" : 8,
        "pvalue" : 7.82058E-4,
        "shared_name" : "dusp7",
        "TopologicalCoefficient" : 0.51875,
        "baseMean" : 377.0828537,
        "SUID" : 467,
        "lfcSE" : 0.321989325,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7379310344827585,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.26752767527675275,
        "stat" : -3.359068189,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9055885850178359,
        "Stress" : 5368,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.003301904844425288,
        "NumberOfUndirectedEdges" : 5,
        "name" : "dusp7",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.081584099,
        "NeighborhoodConnectivity" : 17.6
      },
      "position" : {
        "x" : -671.6297761817987,
        "y" : -234.85143635103304
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "465",
        "degree_layout" : 3,
        "padj" : 0.040586356,
        "Eccentricity" : 8,
        "pvalue" : 6.20988E-4,
        "shared_name" : "LOC795051",
        "TopologicalCoefficient" : 0.4700854700854701,
        "baseMean" : 21.45732775,
        "SUID" : 465,
        "lfcSE" : 0.855019482,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.668965517241379,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2725563909774436,
        "stat" : -3.422277845,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9079667063020215,
        "Stress" : 4008,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0015160769130831257,
        "NumberOfUndirectedEdges" : 3,
        "name" : "LOC795051",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -2.92611423,
        "NeighborhoodConnectivity" : 19.333333333333332
      },
      "position" : {
        "x" : 21.036399587406777,
        "y" : -680.6981151339278
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "463",
        "degree_layout" : 2,
        "padj" : 0.006882277,
        "Eccentricity" : 10,
        "pvalue" : 3.58E-5,
        "shared_name" : "odad1",
        "TopologicalCoefficient" : 0.5862068965517241,
        "baseMean" : 28.58836525,
        "SUID" : 463,
        "lfcSE" : 0.511453331,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.441379310344828,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2251552795031056,
        "stat" : 4.133282833,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8813317479191438,
        "Stress" : 148,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 2.624649190171113E-4,
        "NumberOfUndirectedEdges" : 2,
        "name" : "odad1",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 2.113981274,
        "NeighborhoodConnectivity" : 18.0
      },
      "position" : {
        "x" : -547.7794027647375,
        "y" : 4.768245038158685
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "461",
        "degree_layout" : 2,
        "padj" : 5.13867E-4,
        "Eccentricity" : 10,
        "pvalue" : 1.02E-6,
        "shared_name" : "tspan18b",
        "TopologicalCoefficient" : 0.59375,
        "baseMean" : 94.76647734,
        "SUID" : 461,
        "lfcSE" : 0.373641069,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.620689655172414,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2164179104477612,
        "stat" : 4.888280277,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8751486325802617,
        "Stress" : 72,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 1.4571589413300438E-4,
        "NumberOfUndirectedEdges" : 2,
        "name" : "tspan18b",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.826462271,
        "NeighborhoodConnectivity" : 10.5
      },
      "position" : {
        "x" : 12.981273606521427,
        "y" : -566.8829820198589
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "459",
        "degree_layout" : 1,
        "padj" : 0.008690324,
        "Eccentricity" : 10,
        "pvalue" : 5.03E-5,
        "shared_name" : "cfap74",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 26.59513162,
        "SUID" : 459,
        "lfcSE" : 0.49602824,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.310344827586207,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.1883116883116883,
        "stat" : 4.054146813,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8513674197384067,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "cfap74",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 2.010971309,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : -789.5353125397087,
        "y" : -796.5604948528489
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "457",
        "degree_layout" : 1,
        "padj" : 1.74132E-4,
        "Eccentricity" : 10,
        "pvalue" : 2.15E-7,
        "shared_name" : "cyp2p8",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 32.25485578,
        "SUID" : 457,
        "lfcSE" : 0.605919208,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.8,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.20833333333333334,
        "stat" : 5.185501232,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8689655172413793,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "cyp2p8",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 3.141994801,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -301.32191735903325,
        "y" : -867.9193227283977
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "degree_layout" : 1,
        "padj" : 0.033631832,
        "Eccentricity" : 8,
        "pvalue" : 4.61029E-4,
        "shared_name" : "depdc7a",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 36.22377933,
        "SUID" : 455,
        "lfcSE" : 0.472525224,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8758620689655174,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2580071174377224,
        "stat" : 3.502433287,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9008323424494649,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "depdc7a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.654988072,
        "NeighborhoodConnectivity" : 27.0
      },
      "position" : {
        "x" : -195.3139354169689,
        "y" : -743.73191401246
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "453",
        "degree_layout" : 2,
        "padj" : 4.10479E-4,
        "Eccentricity" : 8,
        "pvalue" : 6.91E-7,
        "shared_name" : "cyp7a1",
        "TopologicalCoefficient" : 0.5925925925925926,
        "baseMean" : 33.48953111,
        "SUID" : 453,
        "lfcSE" : 0.559673166,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8758620689655174,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2580071174377224,
        "stat" : 4.963969869,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.9008323424494649,
        "Stress" : 2180,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 7.00601627667652E-4,
        "NumberOfUndirectedEdges" : 2,
        "name" : "cyp7a1",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 2.778200735,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 188.18512560985982,
        "y" : -120.85830305499258
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "451",
        "degree_layout" : 2,
        "padj" : 0.022179896,
        "Eccentricity" : 10,
        "pvalue" : 2.11843E-4,
        "shared_name" : "hsph1",
        "TopologicalCoefficient" : 0.9166666666666666,
        "baseMean" : 70.63141228,
        "SUID" : 451,
        "lfcSE" : 0.331160163,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.620689655172414,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2164179104477612,
        "stat" : 3.704457748,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8751486325802617,
        "Stress" : 10,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 1.647531249458227E-5,
        "NumberOfUndirectedEdges" : 2,
        "name" : "hsph1",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.226768833,
        "NeighborhoodConnectivity" : 17.5
      },
      "position" : {
        "x" : 151.53465120230976,
        "y" : -592.1243604420888
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "449",
        "degree_layout" : 2,
        "padj" : 0.006887062,
        "Eccentricity" : 10,
        "pvalue" : 3.61E-5,
        "shared_name" : "pcdh15a",
        "TopologicalCoefficient" : 0.5909090909090909,
        "baseMean" : 113.4759663,
        "SUID" : 449,
        "lfcSE" : 0.289467542,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.413793103448276,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2265625,
        "stat" : 4.130944948,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.882282996432818,
        "Stress" : 250,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 3.866732303308161E-4,
        "NumberOfUndirectedEdges" : 2,
        "name" : "pcdh15a",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.195774479,
        "NeighborhoodConnectivity" : 20.5
      },
      "position" : {
        "x" : -159.00831561809173,
        "y" : -706.0406044006813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "447",
        "degree_layout" : 1,
        "padj" : 2.64E-10,
        "Eccentricity" : 10,
        "pvalue" : 3.92E-14,
        "shared_name" : "ptprja",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 325.9941776,
        "SUID" : 447,
        "lfcSE" : 0.205812813,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.786206896551724,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.20893371757925072,
        "stat" : 7.563738905,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8694411414982164,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "gene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "ptprja",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.556714381,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -639.4548020359944,
        "y" : 143.91141998913372
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "445",
        "degree_layout" : 2,
        "padj" : 0.005576147,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-2441",
        "TopologicalCoefficient" : 0.6153846153846154,
        "SUID" : 445,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.682758620689655,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.17597087378640777,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 27.78,
        "significant" : true,
        "Radiality" : 0.838525564803805,
        "Stress" : 40572,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.006148361004682845,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-2441",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 1.863473041,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 487.56138058009674,
        "y" : 511.8673936934938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "degree_layout" : 6,
        "padj" : 0.0235680127672742,
        "Eccentricity" : 9,
        "pvalue" : 2.2173016500062E-4,
        "shared_name" : "Gypsy151-I_DR",
        "TopologicalCoefficient" : 0.5,
        "baseMean" : 16.1542606262826,
        "SUID" : 443,
        "lfcSE" : 0.482803760951495,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 6.468965517241379,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.15458422174840086,
        "stat" : -3.69287828128154,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8114149821640904,
        "Stress" : 81300,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.015172413793103447,
        "NumberOfUndirectedEdges" : 6,
        "name" : "Gypsy151-I_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.78293552293882,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 576.4356204147334,
        "y" : 541.580086713031
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "441",
        "degree_layout" : 19,
        "padj" : 0.0439130485103244,
        "Eccentricity" : 7,
        "pvalue" : 9.0944183305405E-4,
        "shared_name" : "Gypsy-169-I_DR",
        "TopologicalCoefficient" : 0.18461538461538463,
        "baseMean" : 218.869869686786,
        "SUID" : 441,
        "lfcSE" : 0.40162826184473,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.7172413793103445,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.21198830409356725,
        "stat" : -3.31713953846208,
        "Degree" : 19,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.871819262782402,
        "Stress" : 527658,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.18504203916560208,
        "NumberOfUndirectedEdges" : 19,
        "name" : "Gypsy-169-I_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.33225698712895,
        "NeighborhoodConnectivity" : 1.9230769230769231
      },
      "position" : {
        "x" : 467.21950737194857,
        "y" : 650.7782611942966
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "439",
        "degree_layout" : 3,
        "padj" : 0.005576147,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-10247",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 439,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 45.0,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "name" : "piR-dre-10247",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 3.009676923,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 251.3273816009605,
        "y" : 746.6160797768534
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "437",
        "degree_layout" : 33,
        "padj" : 0.0235680127672742,
        "Eccentricity" : 5,
        "pvalue" : 2.2334238674826E-4,
        "shared_name" : "DNA-3-1_DR",
        "TopologicalCoefficient" : 0.07352941176470588,
        "baseMean" : 1091.63999020956,
        "SUID" : 437,
        "lfcSE" : 0.328225659022546,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.296551724137931,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.303347280334728,
        "stat" : 3.69103615308878,
        "Degree" : 33,
        "PartnerOfMultiEdgedNodePairs" : 8,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.920808561236623,
        "Stress" : 728824,
        "target_original" : "acsl1a",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.47616272882077487,
        "NumberOfUndirectedEdges" : 33,
        "name" : "DNA-3-1_DR",
        "interaction" : "TE_gene",
        "IsSingleNode" : false,
        "log2FC" : 1.21149277382361,
        "NeighborhoodConnectivity" : 1.8823529411764706
      },
      "position" : {
        "x" : 305.9403925822262,
        "y" : 811.7855640658672
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "435",
        "degree_layout" : 3,
        "padj" : 0.028898576,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-13310",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 435,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.710344827586207,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.1751207729468599,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 36.84,
        "significant" : true,
        "Radiality" : 0.8375743162901309,
        "Stress" : 0,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "name" : "piR-dre-13310",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -3.039901637,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 513.0494569344737,
        "y" : 582.4060318220436
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "433",
        "degree_layout" : 2,
        "padj" : 0.014404125,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-15727",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 433,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 26.32,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-15727",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.279444484,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 226.45274710361264,
        "y" : 925.3939481395646
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "degree_layout" : 3,
        "padj" : 0.048263483,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-17612",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 431,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 36.84,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "name" : "piR-dre-17612",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -1.903081512,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 280.74121249049495,
        "y" : 909.2889923246112
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "429",
        "degree_layout" : 1,
        "padj" : 0.045839752,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-18163",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 429,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 21.05,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-18163",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -1.711458258,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 159.081005409098,
        "y" : 764.9851667976473
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "427",
        "degree_layout" : 2,
        "padj" : 0.005576147,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-19094",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 427,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 33.33,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-19094",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.111245694,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 365.09191658187774,
        "y" : 910.6535758537793
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "degree_layout" : 2,
        "padj" : 0.036490462,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-19951",
        "TopologicalCoefficient" : 0.56,
        "SUID" : 425,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.055172413793104,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2465986394557823,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 22.22,
        "significant" : true,
        "Radiality" : 0.8946492271105827,
        "Stress" : 136748,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.04427096636866745,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-19951",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.469290879,
        "NeighborhoodConnectivity" : 15.0
      },
      "position" : {
        "x" : 353.2314522194065,
        "y" : 670.0274766871444
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "423",
        "degree_layout" : 5,
        "padj" : 0.044397827,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-21062",
        "TopologicalCoefficient" : 0.56,
        "SUID" : 423,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.055172413793104,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2465986394557823,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "weight" : 33.33,
        "significant" : true,
        "Radiality" : 0.8946492271105827,
        "Stress" : 136748,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.04427096636866745,
        "NumberOfUndirectedEdges" : 5,
        "name" : "piR-dre-21062",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.310968788,
        "NeighborhoodConnectivity" : 15.0
      },
      "position" : {
        "x" : 400.0935239705577,
        "y" : 744.0590090134356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "421",
        "degree_layout" : 2,
        "padj" : 0.032715606,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-24037",
        "TopologicalCoefficient" : 0.56,
        "SUID" : 421,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.055172413793104,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2465986394557823,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 33.33,
        "significant" : true,
        "Radiality" : 0.8946492271105827,
        "Stress" : 136748,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.04427096636866745,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-24037",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.34523479,
        "NeighborhoodConnectivity" : 15.0
      },
      "position" : {
        "x" : 355.4827701670147,
        "y" : 724.3688465935993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "419",
        "degree_layout" : 5,
        "padj" : 0.028898576,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-27928",
        "TopologicalCoefficient" : 0.39215686274509803,
        "SUID" : 419,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.531034482758621,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.18079800498753118,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 29.41,
        "significant" : true,
        "Radiality" : 0.8437574316290131,
        "Stress" : 101774,
        "target_original" : "Gypsy151-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0328113026819924,
        "NumberOfUndirectedEdges" : 5,
        "name" : "piR-dre-27928",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.287810468,
        "NeighborhoodConnectivity" : 7.666666666666667
      },
      "position" : {
        "x" : 417.669441832084,
        "y" : 569.4557571349578
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "417",
        "degree_layout" : 5,
        "padj" : 0.0245399635509094,
        "Eccentricity" : 9,
        "pvalue" : 3.1461491731935E-4,
        "shared_name" : "BEL23-I_DR",
        "TopologicalCoefficient" : 0.26666666666666666,
        "baseMean" : 143.057872298067,
        "SUID" : 417,
        "lfcSE" : 0.281495245802944,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 6.3310344827586205,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.1579520697167756,
        "stat" : 3.60295920790438,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8161712247324613,
        "Stress" : 61344,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.0270971690080885,
        "NumberOfUndirectedEdges" : 5,
        "name" : "BEL23-I_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.01421588784702,
        "NeighborhoodConnectivity" : 2.6
      },
      "position" : {
        "x" : 211.76379869435914,
        "y" : 565.0978256361559
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "415",
        "degree_layout" : 1,
        "padj" : 0.045839752,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-31928",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 415,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 25.0,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-31928",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -3.916098015,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 428.32881984052074,
        "y" : 928.92778781589
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "degree_layout" : 4,
        "padj" : 0.04877372,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-34461",
        "TopologicalCoefficient" : 0.28125,
        "SUID" : 413,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.641379310344828,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.17726161369193152,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 21.05,
        "significant" : true,
        "Radiality" : 0.8399524375743163,
        "Stress" : 25646,
        "target_original" : "BEL30-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.03367390378884621,
        "NumberOfUndirectedEdges" : 4,
        "name" : "piR-dre-34461",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 4.915022987,
        "NeighborhoodConnectivity" : 3.25
      },
      "position" : {
        "x" : 66.87261340947589,
        "y" : 624.6918341538549
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "411",
        "degree_layout" : 6,
        "padj" : 0.0450926851915556,
        "Eccentricity" : 7,
        "pvalue" : 0.00100012128157242,
        "shared_name" : "Gypsy101-LTR_DR",
        "TopologicalCoefficient" : 0.19444444444444445,
        "baseMean" : 132.366733685692,
        "SUID" : 411,
        "lfcSE" : 0.332601431795446,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.855172413793103,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2059659090909091,
        "stat" : 3.29049261169023,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8670630202140309,
        "Stress" : 81660,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.09988452532992774,
        "NumberOfUndirectedEdges" : 6,
        "name" : "Gypsy101-LTR_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.09442255396051,
        "NeighborhoodConnectivity" : 2.1666666666666665
      },
      "position" : {
        "x" : 43.92384010035312,
        "y" : 748.0557205255463
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "409",
        "degree_layout" : 1,
        "padj" : 0.0235680127672742,
        "Eccentricity" : 9,
        "pvalue" : 4.08332001185602E-5,
        "shared_name" : "BEL-37-LTR_DR",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 13.1091872791206,
        "SUID" : 409,
        "lfcSE" : 0.415943351504171,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 6.63448275862069,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.1507276507276507,
        "stat" : -4.1027139305075,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8057074910820451,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "BEL-37-LTR_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.70649658251814,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -76.56799714633962,
        "y" : 648.0453925278998
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "407",
        "degree_layout" : 1,
        "padj" : 0.0368940255327715,
        "Eccentricity" : 9,
        "pvalue" : 5.5440823063336E-4,
        "shared_name" : "BEL30-I_DR",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 15.9918713276905,
        "SUID" : 407,
        "lfcSE" : 0.306808884911631,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 6.63448275862069,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.1507276507276507,
        "stat" : 3.4529906443372,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8057074910820451,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "BEL30-I_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.05940820919939,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -57.137203547288664,
        "y" : 558.3193842329056
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "degree_layout" : 3,
        "padj" : 0.045260357,
        "Eccentricity" : 10,
        "shared_name" : "piR-dre-34810",
        "TopologicalCoefficient" : 0.5714285714285714,
        "SUID" : 405,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 7.268965517241379,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.13757115749525617,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 26.32,
        "significant" : true,
        "Radiality" : 0.7838287752675386,
        "Stress" : 52,
        "target_original" : "BEL23-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 7.407407407407405E-4,
        "NumberOfUndirectedEdges" : 3,
        "name" : "piR-dre-34810",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -1.613153054,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 186.73335497669177,
        "y" : 445.6291128232551
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "403",
        "degree_layout" : 6,
        "padj" : 0.0235680127672742,
        "Eccentricity" : 9,
        "pvalue" : 2.3242616141296E-4,
        "shared_name" : "Gypsy160-I_DR",
        "TopologicalCoefficient" : 0.3333333333333333,
        "baseMean" : 12.8853061403759,
        "SUID" : 403,
        "lfcSE" : 0.34313376082853,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 6.386206896551724,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.15658747300215983,
        "stat" : -3.68088462900082,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.814268727705113,
        "Stress" : 91530,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.02451468710089409,
        "NumberOfUndirectedEdges" : 6,
        "name" : "Gypsy160-I_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.26303578592498,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 263.7384174332983,
        "y" : 530.1995215827919
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "degree_layout" : 2,
        "padj" : 0.005576147,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-35440",
        "TopologicalCoefficient" : 0.6153846153846154,
        "SUID" : 401,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.682758620689655,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.17597087378640777,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 31.58,
        "significant" : true,
        "Radiality" : 0.838525564803805,
        "Stress" : 40572,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.006148361004682845,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-35440",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 1.868688745,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 617.0953918012092,
        "y" : 640.1969016917137
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "399",
        "degree_layout" : 2,
        "padj" : 0.02094751,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-35441",
        "TopologicalCoefficient" : 0.6153846153846154,
        "SUID" : 399,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.682758620689655,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.17597087378640777,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 29.41,
        "significant" : true,
        "Radiality" : 0.838525564803805,
        "Stress" : 40572,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.006148361004682845,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-35441",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 1.73415873,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 568.9658894922613,
        "y" : 664.116976923644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "397",
        "degree_layout" : 2,
        "padj" : 0.011958865,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-35848",
        "TopologicalCoefficient" : 0.5333333333333333,
        "SUID" : 397,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.6,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.17857142857142858,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 27.78,
        "significant" : true,
        "Radiality" : 0.8413793103448275,
        "Stress" : 60908,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.014953703703703743,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-35848",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.442915933,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 386.2012754850148,
        "y" : 522.9925478760706
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "395",
        "degree_layout" : 2,
        "padj" : 0.045839752,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-35849",
        "TopologicalCoefficient" : 0.5333333333333333,
        "SUID" : 395,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.6,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.17857142857142858,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 23.53,
        "significant" : true,
        "Radiality" : 0.8413793103448275,
        "Stress" : 60908,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.014953703703703743,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-35849",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.573627471,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 347.41833321849117,
        "y" : 589.348596826414
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "393",
        "degree_layout" : 1,
        "padj" : 0.049745525,
        "Eccentricity" : 10,
        "shared_name" : "piR-dre-35850",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 393,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 7.379310344827586,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.13551401869158877,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 25.0,
        "significant" : true,
        "Radiality" : 0.7800237812128418,
        "Stress" : 0,
        "target_original" : "Gypsy160-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-35850",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.513152597,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 304.42159437145165,
        "y" : 406.0231607428286
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "391",
        "degree_layout" : 3,
        "padj" : 0.023059554,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-42667",
        "TopologicalCoefficient" : 0.3939393939393939,
        "SUID" : 391,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.613793103448276,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.17813267813267813,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 30.0,
        "significant" : true,
        "Radiality" : 0.8409036860879905,
        "Stress" : 30760,
        "target_original" : "Gypsy101-LTR_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.013210940825883366,
        "NumberOfUndirectedEdges" : 3,
        "name" : "piR-dre-42667",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.218471234,
        "NeighborhoodConnectivity" : 5.333333333333333
      },
      "position" : {
        "x" : 142.7749099135399,
        "y" : 642.8306811610091
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "degree_layout" : 1,
        "padj" : 0.044846016,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-48972",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 389,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 52.63,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-48972",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -1.750989964,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 329.8563106236252,
        "y" : 865.1390602354368
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "387",
        "degree_layout" : 2,
        "padj" : 0.036654587,
        "Eccentricity" : 10,
        "shared_name" : "piR-dre-51545",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 387,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 7.462068965517242,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.13401109057301294,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 36.84,
        "significant" : true,
        "Radiality" : 0.7771700356718193,
        "Stress" : 0,
        "target_original" : "Gypsy151-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-51545",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 3.886600774,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 676.5408804189356,
        "y" : 481.50691928481683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "385",
        "degree_layout" : 1,
        "padj" : 0.026370843,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-57020",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 385,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 27.78,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-57020",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.464855309,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 428.6740944394696,
        "y" : 861.4109146162373
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "383",
        "degree_layout" : 1,
        "padj" : 0.047222994,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-69525",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 383,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 23.53,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-69525",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.167176685,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 354.84985215755296,
        "y" : 975.417819495342
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "381",
        "degree_layout" : 1,
        "padj" : 0.032715606,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-71201",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 381,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.710344827586207,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.1751207729468599,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 29.41,
        "significant" : true,
        "Radiality" : 0.8375743162901309,
        "Stress" : 0,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-71201",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 5.319576757,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 581.5317094841303,
        "y" : 597.9904846131976
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "degree_layout" : 1,
        "padj" : 0.032715606,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-72927",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 379,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.848275862068966,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.17099056603773585,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 29.41,
        "significant" : true,
        "Radiality" : 0.8328180737217598,
        "Stress" : 0,
        "target_original" : "Gypsy101-LTR_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-72927",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -1.669684447,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : -63.73933451701305,
        "y" : 822.8414127582655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "degree_layout" : 2,
        "padj" : 0.044397827,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-80231",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 377,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 31.25,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-80231",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.93530641,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 210.6463686796924,
        "y" : 870.799103511119
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "degree_layout" : 1,
        "padj" : 0.045260357,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-83372",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 375,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.848275862068966,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.17099056603773585,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 31.25,
        "significant" : true,
        "Radiality" : 0.8328180737217598,
        "Stress" : 0,
        "target_original" : "Gypsy101-LTR_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-83372",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.533873895,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : -72.379343025852,
        "y" : 750.162903554854
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "373",
        "degree_layout" : 6,
        "padj" : 0.045839752,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-133212",
        "TopologicalCoefficient" : 0.3333333333333333,
        "SUID" : 373,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.096551724137931,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.24410774410774413,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 21.05,
        "significant" : true,
        "Radiality" : 0.8932223543400714,
        "Stress" : 91588,
        "target_original" : "Gypsy101-LTR_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.11701947637292485,
        "NumberOfUndirectedEdges" : 6,
        "name" : "piR-dre-133212",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -3.71813793,
        "NeighborhoodConnectivity" : 8.0
      },
      "position" : {
        "x" : 191.55860024080903,
        "y" : 819.8505135446176
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "degree_layout" : 1,
        "padj" : 0.0235680127672742,
        "Eccentricity" : 7,
        "pvalue" : 6.56256137314031E-5,
        "shared_name" : "Gypsy-21-I_DR",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 100.96439213047,
        "SUID" : 371,
        "lfcSE" : 0.265833008415293,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.089655172413793,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.1964769647696477,
        "stat" : 3.9916122456751,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8589774078478003,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Gypsy-21-I_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.06110229169513,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 104.11050452275958,
        "y" : 927.044979175349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "369",
        "degree_layout" : 1,
        "padj" : 0.047851863,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-426176",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 369,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.848275862068966,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.17099056603773585,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 29.41,
        "significant" : true,
        "Radiality" : 0.8328180737217598,
        "Stress" : 0,
        "target_original" : "Gypsy101-LTR_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-426176",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.770959885,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : -1.3937215018522693,
        "y" : 862.6682084631029
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "367",
        "degree_layout" : 1,
        "padj" : 0.047851863,
        "Eccentricity" : 10,
        "shared_name" : "piR-dre-492597",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 367,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 7.324137931034483,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.13653483992467044,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 21.05,
        "significant" : true,
        "Radiality" : 0.7819262782401902,
        "Stress" : 0,
        "target_original" : "BEL23-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-492597",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -3.056747389,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 92.66063390229829,
        "y" : 491.1408379988861
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "degree_layout" : 8,
        "padj" : 0.044397827,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-555119",
        "TopologicalCoefficient" : 0.37333333333333335,
        "SUID" : 365,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.041379310344827,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.24744027303754268,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 45.0,
        "significant" : true,
        "Radiality" : 0.8951248513674198,
        "Stress" : 141906,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.058064069816943446,
        "NumberOfUndirectedEdges" : 8,
        "name" : "piR-dre-555119",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -3.93768845,
        "NeighborhoodConnectivity" : 10.333333333333334
      },
      "position" : {
        "x" : 410.07664668270445,
        "y" : 794.1285525164858
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "degree_layout" : 1,
        "padj" : 0.0368940255327715,
        "Eccentricity" : 7,
        "pvalue" : 6.0139496076319E-4,
        "shared_name" : "Gypsy127-LTR_DR",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 24.5761231035443,
        "SUID" : 363,
        "lfcSE" : 0.363143804530866,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.0344827586206895,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.1986301369863014,
        "stat" : -3.43098450088222,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8608799048751486,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Gypsy127-LTR_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.2459407649368,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 499.616264781027,
        "y" : 819.5753417052911
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "degree_layout" : 1,
        "padj" : 0.044397827,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-809338",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 361,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.710344827586207,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.1751207729468599,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 20.0,
        "significant" : true,
        "Radiality" : 0.8375743162901309,
        "Stress" : 0,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-809338",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.756745586,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 600.6540452463669,
        "y" : 748.2978626323456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "degree_layout" : 2,
        "padj" : 0.044397827,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-1029262",
        "TopologicalCoefficient" : 0.5,
        "SUID" : 359,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.275862068965517,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2338709677419355,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 33.33,
        "significant" : true,
        "Radiality" : 0.8870392390011891,
        "Stress" : 5320,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.013793103448275862,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-1029262",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 4.622096848,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 280.49815921850677,
        "y" : 974.2274962782685
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "357",
        "degree_layout" : 1,
        "padj" : 0.0368940255327715,
        "Eccentricity" : 7,
        "pvalue" : 6.1853888960267E-4,
        "shared_name" : "Gypsy100-I_DR",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 222.70137450078,
        "SUID" : 357,
        "lfcSE" : 0.359133988857157,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.268965517241379,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.18979057591623036,
        "stat" : 3.42335215333662,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8527942925089179,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Gypsy100-I_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.22944211409052,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 284.8080837097659,
        "y" : 1101.5234014446323
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "1481",
        "source" : "647",
        "target" : "645",
        "EdgeBetweenness" : 90.617460439401,
        "shared_name" : "dre-miR-100-3p (miRNA_gene) myh14",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-100-3p (miRNA_gene) myh14",
        "interaction" : "miRNA_gene",
        "SUID" : 1481,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1479",
        "source" : "647",
        "target" : "615",
        "EdgeBetweenness" : 53.80250326770345,
        "shared_name" : "dre-miR-100-3p (miRNA_gene) rgma",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-100-3p (miRNA_gene) rgma",
        "interaction" : "miRNA_gene",
        "SUID" : 1479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1477",
        "source" : "647",
        "target" : "609",
        "EdgeBetweenness" : 85.0281834079474,
        "shared_name" : "dre-miR-100-3p (miRNA_gene) rin1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-100-3p (miRNA_gene) rin1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1477,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1475",
        "source" : "647",
        "target" : "587",
        "EdgeBetweenness" : 55.16750288217482,
        "shared_name" : "dre-miR-100-3p (miRNA_gene) aldob",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-100-3p (miRNA_gene) aldob",
        "interaction" : "miRNA_gene",
        "SUID" : 1475,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1473",
        "source" : "647",
        "target" : "557",
        "EdgeBetweenness" : 86.26778230133678,
        "shared_name" : "dre-miR-100-3p (miRNA_gene) cpe",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-100-3p (miRNA_gene) cpe",
        "interaction" : "miRNA_gene",
        "SUID" : 1473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1471",
        "source" : "647",
        "target" : "547",
        "EdgeBetweenness" : 51.00242073080154,
        "shared_name" : "dre-miR-100-3p (miRNA_gene) slc35d1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-100-3p (miRNA_gene) slc35d1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1471,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1469",
        "source" : "647",
        "target" : "503",
        "EdgeBetweenness" : 94.54717902988658,
        "shared_name" : "dre-miR-100-3p (miRNA_gene) mllt1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-100-3p (miRNA_gene) mllt1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1469,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1467",
        "source" : "647",
        "target" : "487",
        "EdgeBetweenness" : 75.88451465459757,
        "shared_name" : "dre-miR-100-3p (miRNA_gene) slc6a1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-100-3p (miRNA_gene) slc6a1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1465",
        "source" : "647",
        "target" : "461",
        "EdgeBetweenness" : 118.60442647951692,
        "shared_name" : "dre-miR-100-3p (miRNA_gene) tspan18b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-100-3p (miRNA_gene) tspan18b",
        "interaction" : "miRNA_gene",
        "SUID" : 1465,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1463",
        "source" : "643",
        "target" : "645",
        "EdgeBetweenness" : 113.39819546782255,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) myh14",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) myh14",
        "interaction" : "miRNA_gene",
        "SUID" : 1463,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1461",
        "source" : "643",
        "target" : "625",
        "EdgeBetweenness" : 99.49354047174893,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) dnajc11",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) dnajc11",
        "interaction" : "miRNA_gene",
        "SUID" : 1461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1459",
        "source" : "643",
        "target" : "609",
        "EdgeBetweenness" : 178.30692393447083,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) rin1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) rin1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1457",
        "source" : "643",
        "target" : "603",
        "EdgeBetweenness" : 158.64816038315848,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) vsnl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) vsnl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1457,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1455",
        "source" : "643",
        "target" : "589",
        "EdgeBetweenness" : 121.1767467565085,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) gspt1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) gspt1",
        "interaction" : "miRNA_gene",
        "SUID" : 1455,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1453",
        "source" : "643",
        "target" : "579",
        "EdgeBetweenness" : 219.1956051025113,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) frmpd3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) frmpd3",
        "interaction" : "miRNA_gene",
        "SUID" : 1453,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1451",
        "source" : "643",
        "target" : "571",
        "EdgeBetweenness" : 156.83370192683765,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) rbfox3a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) rbfox3a",
        "interaction" : "miRNA_gene",
        "SUID" : 1451,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1449",
        "source" : "643",
        "target" : "565",
        "EdgeBetweenness" : 154.27593209707118,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) pcdh2ab9",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) pcdh2ab9",
        "interaction" : "miRNA_gene",
        "SUID" : 1449,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1447",
        "source" : "643",
        "target" : "563",
        "EdgeBetweenness" : 230.62383284201,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) spry4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) spry4",
        "interaction" : "miRNA_gene",
        "SUID" : 1447,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1445",
        "source" : "643",
        "target" : "561",
        "EdgeBetweenness" : 1995.796738784157,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) acsl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) acsl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1443",
        "source" : "643",
        "target" : "559",
        "EdgeBetweenness" : 166.63050200529406,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) ptchd1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) ptchd1",
        "interaction" : "miRNA_gene",
        "SUID" : 1443,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1441",
        "source" : "643",
        "target" : "557",
        "EdgeBetweenness" : 147.61187767115987,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) cpe",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) cpe",
        "interaction" : "miRNA_gene",
        "SUID" : 1441,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1439",
        "source" : "643",
        "target" : "555",
        "EdgeBetweenness" : 314.29941609239813,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) acvr1c",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) acvr1c",
        "interaction" : "miRNA_gene",
        "SUID" : 1439,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1437",
        "source" : "643",
        "target" : "545",
        "EdgeBetweenness" : 220.59921640087805,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) pcnx2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) pcnx2",
        "interaction" : "miRNA_gene",
        "SUID" : 1437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1435",
        "source" : "643",
        "target" : "539",
        "EdgeBetweenness" : 114.74356374593526,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) plxnb1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) plxnb1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1435,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1433",
        "source" : "643",
        "target" : "537",
        "EdgeBetweenness" : 140.99056756220216,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) tgfb1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) tgfb1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1431",
        "source" : "643",
        "target" : "527",
        "EdgeBetweenness" : 209.5659421526036,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) camta1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) camta1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1431,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1429",
        "source" : "643",
        "target" : "525",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) hoxd9a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) hoxd9a",
        "interaction" : "miRNA_gene",
        "SUID" : 1429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1427",
        "source" : "643",
        "target" : "521",
        "EdgeBetweenness" : 171.65653693632578,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) atp2b3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) atp2b3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1427,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1425",
        "source" : "643",
        "target" : "509",
        "EdgeBetweenness" : 140.69304992720092,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) nphs1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) nphs1",
        "interaction" : "miRNA_gene",
        "SUID" : 1425,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1423",
        "source" : "643",
        "target" : "507",
        "EdgeBetweenness" : 114.98025839423583,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) smad3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) smad3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1421",
        "source" : "643",
        "target" : "501",
        "EdgeBetweenness" : 114.12473425257117,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) iqgap2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) iqgap2",
        "interaction" : "miRNA_gene",
        "SUID" : 1421,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1419",
        "source" : "643",
        "target" : "499",
        "EdgeBetweenness" : 153.77242883314463,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) si:ch211-247j9.1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) si:ch211-247j9.1",
        "interaction" : "miRNA_gene",
        "SUID" : 1419,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1417",
        "source" : "643",
        "target" : "497",
        "EdgeBetweenness" : 101.28439263297803,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) ptchd4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) ptchd4",
        "interaction" : "miRNA_gene",
        "SUID" : 1417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1415",
        "source" : "643",
        "target" : "471",
        "EdgeBetweenness" : 106.38338524693795,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) lgals9l3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) lgals9l3",
        "interaction" : "miRNA_gene",
        "SUID" : 1415,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1413",
        "source" : "643",
        "target" : "467",
        "EdgeBetweenness" : 122.21424932390987,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) dusp7",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) dusp7",
        "interaction" : "miRNA_gene",
        "SUID" : 1413,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1411",
        "source" : "643",
        "target" : "455",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-19a-3p (miRNA_gene) depdc7a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19a-3p (miRNA_gene) depdc7a",
        "interaction" : "miRNA_gene",
        "SUID" : 1411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1409",
        "source" : "641",
        "target" : "645",
        "EdgeBetweenness" : 90.59551184675324,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) myh14",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) myh14",
        "interaction" : "miRNA_gene",
        "SUID" : 1409,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1407",
        "source" : "641",
        "target" : "625",
        "EdgeBetweenness" : 75.46855307064465,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) dnajc11",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) dnajc11",
        "interaction" : "miRNA_gene",
        "SUID" : 1407,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1405",
        "source" : "641",
        "target" : "609",
        "EdgeBetweenness" : 147.2907866423213,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) rin1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) rin1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1403",
        "source" : "641",
        "target" : "603",
        "EdgeBetweenness" : 129.894989814018,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) vsnl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) vsnl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1403,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1401",
        "source" : "641",
        "target" : "589",
        "EdgeBetweenness" : 101.03922804768659,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) gspt1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) gspt1",
        "interaction" : "miRNA_gene",
        "SUID" : 1401,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1399",
        "source" : "641",
        "target" : "579",
        "EdgeBetweenness" : 175.67185833976296,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) frmpd3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) frmpd3",
        "interaction" : "miRNA_gene",
        "SUID" : 1399,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1397",
        "source" : "641",
        "target" : "571",
        "EdgeBetweenness" : 129.66558926285387,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) rbfox3a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) rbfox3a",
        "interaction" : "miRNA_gene",
        "SUID" : 1397,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1395",
        "source" : "641",
        "target" : "561",
        "EdgeBetweenness" : 1561.7126082865254,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) acsl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) acsl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1395,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1393",
        "source" : "641",
        "target" : "559",
        "EdgeBetweenness" : 141.6438479445116,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) ptchd1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) ptchd1",
        "interaction" : "miRNA_gene",
        "SUID" : 1393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1391",
        "source" : "641",
        "target" : "557",
        "EdgeBetweenness" : 118.52915047973234,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) cpe",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) cpe",
        "interaction" : "miRNA_gene",
        "SUID" : 1391,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1389",
        "source" : "641",
        "target" : "553",
        "EdgeBetweenness" : 104.21596816219783,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) npdc1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) npdc1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1389,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1387",
        "source" : "641",
        "target" : "539",
        "EdgeBetweenness" : 95.50492517531653,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) plxnb1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) plxnb1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1387,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1385",
        "source" : "641",
        "target" : "537",
        "EdgeBetweenness" : 117.89339170996054,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) tgfb1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) tgfb1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1385,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1383",
        "source" : "641",
        "target" : "527",
        "EdgeBetweenness" : 165.78382868576702,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) camta1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) camta1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1383,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1381",
        "source" : "641",
        "target" : "521",
        "EdgeBetweenness" : 141.09437488221374,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) atp2b3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) atp2b3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1381,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1379",
        "source" : "641",
        "target" : "509",
        "EdgeBetweenness" : 119.76753190967783,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) nphs1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) nphs1",
        "interaction" : "miRNA_gene",
        "SUID" : 1379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1377",
        "source" : "641",
        "target" : "507",
        "EdgeBetweenness" : 98.17213608509303,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) smad3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) smad3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1377,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1375",
        "source" : "641",
        "target" : "503",
        "EdgeBetweenness" : 166.51791892889435,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) mllt1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) mllt1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1373",
        "source" : "641",
        "target" : "501",
        "EdgeBetweenness" : 93.5168454968483,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) iqgap2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) iqgap2",
        "interaction" : "miRNA_gene",
        "SUID" : 1373,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1371",
        "source" : "641",
        "target" : "499",
        "EdgeBetweenness" : 136.04635901175146,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) si:ch211-247j9.1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) si:ch211-247j9.1",
        "interaction" : "miRNA_gene",
        "SUID" : 1371,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1369",
        "source" : "641",
        "target" : "497",
        "EdgeBetweenness" : 80.97733305772903,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) ptchd4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) ptchd4",
        "interaction" : "miRNA_gene",
        "SUID" : 1369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1367",
        "source" : "641",
        "target" : "471",
        "EdgeBetweenness" : 93.66367004750207,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) lgals9l3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) lgals9l3",
        "interaction" : "miRNA_gene",
        "SUID" : 1367,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1365",
        "source" : "641",
        "target" : "467",
        "EdgeBetweenness" : 105.57536212447249,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) dusp7",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) dusp7",
        "interaction" : "miRNA_gene",
        "SUID" : 1365,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1363",
        "source" : "641",
        "target" : "587",
        "EdgeBetweenness" : 100.84372451023141,
        "shared_name" : "dre-miR-19b-3p (miRNA_gene) aldob",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19b-3p (miRNA_gene) aldob",
        "interaction" : "miRNA_gene",
        "SUID" : 1363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1361",
        "source" : "639",
        "target" : "645",
        "EdgeBetweenness" : 90.59551184675324,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) myh14",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) myh14",
        "interaction" : "miRNA_gene",
        "SUID" : 1361,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1359",
        "source" : "639",
        "target" : "625",
        "EdgeBetweenness" : 75.46855307064465,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) dnajc11",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) dnajc11",
        "interaction" : "miRNA_gene",
        "SUID" : 1359,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1357",
        "source" : "639",
        "target" : "609",
        "EdgeBetweenness" : 147.29078664232134,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) rin1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) rin1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1357,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1355",
        "source" : "639",
        "target" : "603",
        "EdgeBetweenness" : 129.894989814018,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) vsnl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) vsnl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1355,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1353",
        "source" : "639",
        "target" : "589",
        "EdgeBetweenness" : 101.03922804768659,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) gspt1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) gspt1",
        "interaction" : "miRNA_gene",
        "SUID" : 1353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1351",
        "source" : "639",
        "target" : "579",
        "EdgeBetweenness" : 175.67185833976296,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) frmpd3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) frmpd3",
        "interaction" : "miRNA_gene",
        "SUID" : 1351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1349",
        "source" : "639",
        "target" : "571",
        "EdgeBetweenness" : 129.66558926285387,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) rbfox3a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) rbfox3a",
        "interaction" : "miRNA_gene",
        "SUID" : 1349,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1347",
        "source" : "639",
        "target" : "561",
        "EdgeBetweenness" : 1561.7126082865254,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) acsl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) acsl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1347,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1345",
        "source" : "639",
        "target" : "559",
        "EdgeBetweenness" : 141.6438479445116,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) ptchd1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) ptchd1",
        "interaction" : "miRNA_gene",
        "SUID" : 1345,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1343",
        "source" : "639",
        "target" : "557",
        "EdgeBetweenness" : 118.52915047973234,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) cpe",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) cpe",
        "interaction" : "miRNA_gene",
        "SUID" : 1343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1341",
        "source" : "639",
        "target" : "553",
        "EdgeBetweenness" : 104.21596816219783,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) npdc1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) npdc1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1341,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1339",
        "source" : "639",
        "target" : "539",
        "EdgeBetweenness" : 95.50492517531653,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) plxnb1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) plxnb1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1339,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1337",
        "source" : "639",
        "target" : "537",
        "EdgeBetweenness" : 117.89339170996054,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) tgfb1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) tgfb1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1337,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1335",
        "source" : "639",
        "target" : "527",
        "EdgeBetweenness" : 165.78382868576702,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) camta1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) camta1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1335,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1333",
        "source" : "639",
        "target" : "521",
        "EdgeBetweenness" : 141.09437488221374,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) atp2b3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) atp2b3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1333,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1331",
        "source" : "639",
        "target" : "509",
        "EdgeBetweenness" : 119.76753190967783,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) nphs1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) nphs1",
        "interaction" : "miRNA_gene",
        "SUID" : 1331,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1329",
        "source" : "639",
        "target" : "507",
        "EdgeBetweenness" : 98.17213608509303,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) smad3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) smad3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1329,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1327",
        "source" : "639",
        "target" : "503",
        "EdgeBetweenness" : 166.51791892889435,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) mllt1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) mllt1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1327,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1325",
        "source" : "639",
        "target" : "501",
        "EdgeBetweenness" : 93.5168454968483,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) iqgap2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) iqgap2",
        "interaction" : "miRNA_gene",
        "SUID" : 1325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1323",
        "source" : "639",
        "target" : "499",
        "EdgeBetweenness" : 136.04635901175146,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) si:ch211-247j9.1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) si:ch211-247j9.1",
        "interaction" : "miRNA_gene",
        "SUID" : 1323,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1321",
        "source" : "639",
        "target" : "497",
        "EdgeBetweenness" : 80.97733305772903,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) ptchd4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) ptchd4",
        "interaction" : "miRNA_gene",
        "SUID" : 1321,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1319",
        "source" : "639",
        "target" : "471",
        "EdgeBetweenness" : 93.66367004750207,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) lgals9l3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) lgals9l3",
        "interaction" : "miRNA_gene",
        "SUID" : 1319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1317",
        "source" : "639",
        "target" : "467",
        "EdgeBetweenness" : 105.57536212447249,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) dusp7",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) dusp7",
        "interaction" : "miRNA_gene",
        "SUID" : 1317,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1315",
        "source" : "639",
        "target" : "587",
        "EdgeBetweenness" : 100.84372451023141,
        "shared_name" : "dre-miR-19c-3p (miRNA_gene) aldob",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-19c-3p (miRNA_gene) aldob",
        "interaction" : "miRNA_gene",
        "SUID" : 1315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1313",
        "source" : "637",
        "target" : "645",
        "EdgeBetweenness" : 88.5489159073747,
        "shared_name" : "dre-miR-101a (miRNA_gene) myh14",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101a (miRNA_gene) myh14",
        "interaction" : "miRNA_gene",
        "SUID" : 1313,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1311",
        "source" : "637",
        "target" : "625",
        "EdgeBetweenness" : 74.2123048841238,
        "shared_name" : "dre-miR-101a (miRNA_gene) dnajc11",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101a (miRNA_gene) dnajc11",
        "interaction" : "miRNA_gene",
        "SUID" : 1311,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1309",
        "source" : "637",
        "target" : "595",
        "EdgeBetweenness" : 169.30364478959768,
        "shared_name" : "dre-miR-101a (miRNA_gene) sv2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101a (miRNA_gene) sv2a",
        "interaction" : "miRNA_gene",
        "SUID" : 1309,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1307",
        "source" : "637",
        "target" : "579",
        "EdgeBetweenness" : 177.1568994008637,
        "shared_name" : "dre-miR-101a (miRNA_gene) frmpd3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101a (miRNA_gene) frmpd3",
        "interaction" : "miRNA_gene",
        "SUID" : 1307,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1305",
        "source" : "637",
        "target" : "571",
        "EdgeBetweenness" : 123.14095302087156,
        "shared_name" : "dre-miR-101a (miRNA_gene) rbfox3a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101a (miRNA_gene) rbfox3a",
        "interaction" : "miRNA_gene",
        "SUID" : 1305,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1303",
        "source" : "637",
        "target" : "565",
        "EdgeBetweenness" : 116.21710319768005,
        "shared_name" : "dre-miR-101a (miRNA_gene) pcdh2ab9",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101a (miRNA_gene) pcdh2ab9",
        "interaction" : "miRNA_gene",
        "SUID" : 1303,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1301",
        "source" : "637",
        "target" : "561",
        "EdgeBetweenness" : 889.2040965071405,
        "shared_name" : "dre-miR-101a (miRNA_gene) acsl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101a (miRNA_gene) acsl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1301,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1299",
        "source" : "637",
        "target" : "557",
        "EdgeBetweenness" : 114.12661864518977,
        "shared_name" : "dre-miR-101a (miRNA_gene) cpe",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101a (miRNA_gene) cpe",
        "interaction" : "miRNA_gene",
        "SUID" : 1299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1297",
        "source" : "637",
        "target" : "541",
        "EdgeBetweenness" : 108.6856549822166,
        "shared_name" : "dre-miR-101a (miRNA_gene) neurl1ab",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101a (miRNA_gene) neurl1ab",
        "interaction" : "miRNA_gene",
        "SUID" : 1297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1295",
        "source" : "637",
        "target" : "585",
        "EdgeBetweenness" : 84.54116073083239,
        "shared_name" : "dre-miR-101a (miRNA_gene) pcdh10a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101a (miRNA_gene) pcdh10a",
        "interaction" : "miRNA_gene",
        "SUID" : 1295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1293",
        "source" : "637",
        "target" : "531",
        "EdgeBetweenness" : 111.04760672342537,
        "shared_name" : "dre-miR-101a (miRNA_gene) fam171a2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101a (miRNA_gene) fam171a2a",
        "interaction" : "miRNA_gene",
        "SUID" : 1293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1291",
        "source" : "637",
        "target" : "589",
        "EdgeBetweenness" : 100.66869572469307,
        "shared_name" : "dre-miR-101a (miRNA_gene) gspt1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101a (miRNA_gene) gspt1",
        "interaction" : "miRNA_gene",
        "SUID" : 1291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1289",
        "source" : "637",
        "target" : "469",
        "EdgeBetweenness" : 184.16923403231067,
        "shared_name" : "dre-miR-101a (miRNA_gene) unm_hu7912",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101a (miRNA_gene) unm_hu7912",
        "interaction" : "miRNA_gene",
        "SUID" : 1289,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1287",
        "source" : "635",
        "target" : "645",
        "EdgeBetweenness" : 98.97343931391478,
        "shared_name" : "dre-miR-101b (miRNA_gene) myh14",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101b (miRNA_gene) myh14",
        "interaction" : "miRNA_gene",
        "SUID" : 1287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1285",
        "source" : "635",
        "target" : "625",
        "EdgeBetweenness" : 83.27473207309119,
        "shared_name" : "dre-miR-101b (miRNA_gene) dnajc11",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101b (miRNA_gene) dnajc11",
        "interaction" : "miRNA_gene",
        "SUID" : 1285,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1283",
        "source" : "635",
        "target" : "603",
        "EdgeBetweenness" : 115.88515478193806,
        "shared_name" : "dre-miR-101b (miRNA_gene) vsnl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101b (miRNA_gene) vsnl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1281",
        "source" : "635",
        "target" : "595",
        "EdgeBetweenness" : 177.61637371120878,
        "shared_name" : "dre-miR-101b (miRNA_gene) sv2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101b (miRNA_gene) sv2a",
        "interaction" : "miRNA_gene",
        "SUID" : 1281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1279",
        "source" : "635",
        "target" : "579",
        "EdgeBetweenness" : 194.94113473016645,
        "shared_name" : "dre-miR-101b (miRNA_gene) frmpd3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101b (miRNA_gene) frmpd3",
        "interaction" : "miRNA_gene",
        "SUID" : 1279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1277",
        "source" : "635",
        "target" : "573",
        "EdgeBetweenness" : 175.16354105398196,
        "shared_name" : "dre-miR-101b (miRNA_gene) xkr4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101b (miRNA_gene) xkr4",
        "interaction" : "miRNA_gene",
        "SUID" : 1277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1275",
        "source" : "635",
        "target" : "571",
        "EdgeBetweenness" : 143.8313373794634,
        "shared_name" : "dre-miR-101b (miRNA_gene) rbfox3a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101b (miRNA_gene) rbfox3a",
        "interaction" : "miRNA_gene",
        "SUID" : 1275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1273",
        "source" : "635",
        "target" : "561",
        "EdgeBetweenness" : 1087.289327336011,
        "shared_name" : "dre-miR-101b (miRNA_gene) acsl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101b (miRNA_gene) acsl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1273,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1271",
        "source" : "635",
        "target" : "545",
        "EdgeBetweenness" : 177.24753288800133,
        "shared_name" : "dre-miR-101b (miRNA_gene) pcnx2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101b (miRNA_gene) pcnx2",
        "interaction" : "miRNA_gene",
        "SUID" : 1271,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1269",
        "source" : "635",
        "target" : "541",
        "EdgeBetweenness" : 113.85474677339049,
        "shared_name" : "dre-miR-101b (miRNA_gene) neurl1ab",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101b (miRNA_gene) neurl1ab",
        "interaction" : "miRNA_gene",
        "SUID" : 1269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1267",
        "source" : "635",
        "target" : "585",
        "EdgeBetweenness" : 93.8203450873755,
        "shared_name" : "dre-miR-101b (miRNA_gene) pcdh10a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101b (miRNA_gene) pcdh10a",
        "interaction" : "miRNA_gene",
        "SUID" : 1267,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1265",
        "source" : "635",
        "target" : "531",
        "EdgeBetweenness" : 115.23611137330771,
        "shared_name" : "dre-miR-101b (miRNA_gene) fam171a2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101b (miRNA_gene) fam171a2a",
        "interaction" : "miRNA_gene",
        "SUID" : 1265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1263",
        "source" : "635",
        "target" : "513",
        "EdgeBetweenness" : 217.17267019754058,
        "shared_name" : "dre-miR-101b (miRNA_gene) glula",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101b (miRNA_gene) glula",
        "interaction" : "miRNA_gene",
        "SUID" : 1263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1261",
        "source" : "635",
        "target" : "453",
        "EdgeBetweenness" : 189.33250254835178,
        "shared_name" : "dre-miR-101b (miRNA_gene) cyp7a1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-101b (miRNA_gene) cyp7a1",
        "interaction" : "miRNA_gene",
        "SUID" : 1261,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1259",
        "source" : "633",
        "target" : "645",
        "EdgeBetweenness" : 127.29356431839291,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) myh14",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) myh14",
        "interaction" : "miRNA_gene",
        "SUID" : 1259,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1257",
        "source" : "633",
        "target" : "615",
        "EdgeBetweenness" : 109.17134106045225,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) rgma",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) rgma",
        "interaction" : "miRNA_gene",
        "SUID" : 1257,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1255",
        "source" : "633",
        "target" : "595",
        "EdgeBetweenness" : 184.90935958675243,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) sv2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) sv2a",
        "interaction" : "miRNA_gene",
        "SUID" : 1255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1253",
        "source" : "633",
        "target" : "579",
        "EdgeBetweenness" : 195.55535924866481,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) frmpd3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) frmpd3",
        "interaction" : "miRNA_gene",
        "SUID" : 1253,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1251",
        "source" : "633",
        "target" : "575",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) dock9b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) dock9b",
        "interaction" : "miRNA_gene",
        "SUID" : 1251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1249",
        "source" : "633",
        "target" : "573",
        "EdgeBetweenness" : 82.36273964632639,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) xkr4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) xkr4",
        "interaction" : "miRNA_gene",
        "SUID" : 1249,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1247",
        "source" : "633",
        "target" : "565",
        "EdgeBetweenness" : 91.53099879360188,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) pcdh2ab9",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) pcdh2ab9",
        "interaction" : "miRNA_gene",
        "SUID" : 1247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1245",
        "source" : "633",
        "target" : "559",
        "EdgeBetweenness" : 127.9004290761365,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) ptchd1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) ptchd1",
        "interaction" : "miRNA_gene",
        "SUID" : 1245,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1243",
        "source" : "633",
        "target" : "545",
        "EdgeBetweenness" : 141.59368103636388,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) pcnx2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) pcnx2",
        "interaction" : "miRNA_gene",
        "SUID" : 1243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1241",
        "source" : "633",
        "target" : "537",
        "EdgeBetweenness" : 125.50101800915652,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) tgfb1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) tgfb1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1241,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1239",
        "source" : "633",
        "target" : "523",
        "EdgeBetweenness" : 128.49419692459932,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) micu3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) micu3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1239,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1237",
        "source" : "633",
        "target" : "509",
        "EdgeBetweenness" : 113.98299011630696,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) nphs1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) nphs1",
        "interaction" : "miRNA_gene",
        "SUID" : 1237,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1235",
        "source" : "633",
        "target" : "507",
        "EdgeBetweenness" : 102.38435679248528,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) smad3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) smad3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1233",
        "source" : "633",
        "target" : "501",
        "EdgeBetweenness" : 121.06629779351773,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) iqgap2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) iqgap2",
        "interaction" : "miRNA_gene",
        "SUID" : 1233,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1231",
        "source" : "633",
        "target" : "499",
        "EdgeBetweenness" : 122.29940066254493,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) si:ch211-247j9.1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) si:ch211-247j9.1",
        "interaction" : "miRNA_gene",
        "SUID" : 1231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1229",
        "source" : "633",
        "target" : "493",
        "EdgeBetweenness" : 207.5927181064574,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) col14a1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) col14a1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1227",
        "source" : "633",
        "target" : "489",
        "EdgeBetweenness" : 160.4893330958445,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) creg2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) creg2",
        "interaction" : "miRNA_gene",
        "SUID" : 1227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1225",
        "source" : "633",
        "target" : "485",
        "EdgeBetweenness" : 209.86688012740626,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) nr4a2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) nr4a2a",
        "interaction" : "miRNA_gene",
        "SUID" : 1225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1223",
        "source" : "633",
        "target" : "453",
        "EdgeBetweenness" : 129.92462142304905,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) cyp7a1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) cyp7a1",
        "interaction" : "miRNA_gene",
        "SUID" : 1223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1221",
        "source" : "633",
        "target" : "449",
        "EdgeBetweenness" : 149.78366355959082,
        "shared_name" : "dre-miR-142b-5p (miRNA_gene) pcdh15a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142b-5p (miRNA_gene) pcdh15a",
        "interaction" : "miRNA_gene",
        "SUID" : 1221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1219",
        "source" : "631",
        "target" : "645",
        "EdgeBetweenness" : 72.09816022919583,
        "shared_name" : "dre-miR-301a (miRNA_gene) myh14",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) myh14",
        "interaction" : "miRNA_gene",
        "SUID" : 1219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1217",
        "source" : "631",
        "target" : "625",
        "EdgeBetweenness" : 70.38429116436154,
        "shared_name" : "dre-miR-301a (miRNA_gene) dnajc11",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) dnajc11",
        "interaction" : "miRNA_gene",
        "SUID" : 1217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1215",
        "source" : "631",
        "target" : "609",
        "EdgeBetweenness" : 73.09064190610925,
        "shared_name" : "dre-miR-301a (miRNA_gene) rin1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) rin1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1213",
        "source" : "631",
        "target" : "583",
        "EdgeBetweenness" : 144.88757027640858,
        "shared_name" : "dre-miR-301a (miRNA_gene) en1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) en1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1213,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1211",
        "source" : "631",
        "target" : "573",
        "EdgeBetweenness" : 52.886599816351094,
        "shared_name" : "dre-miR-301a (miRNA_gene) xkr4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) xkr4",
        "interaction" : "miRNA_gene",
        "SUID" : 1211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1209",
        "source" : "631",
        "target" : "571",
        "EdgeBetweenness" : 92.1785903180931,
        "shared_name" : "dre-miR-301a (miRNA_gene) rbfox3a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) rbfox3a",
        "interaction" : "miRNA_gene",
        "SUID" : 1209,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1207",
        "source" : "631",
        "target" : "547",
        "EdgeBetweenness" : 66.20807696014134,
        "shared_name" : "dre-miR-301a (miRNA_gene) slc35d1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) slc35d1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1207,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1205",
        "source" : "631",
        "target" : "539",
        "EdgeBetweenness" : 47.12845095938763,
        "shared_name" : "dre-miR-301a (miRNA_gene) plxnb1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) plxnb1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1203",
        "source" : "631",
        "target" : "537",
        "EdgeBetweenness" : 57.9578769309048,
        "shared_name" : "dre-miR-301a (miRNA_gene) tgfb1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) tgfb1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1203,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1201",
        "source" : "631",
        "target" : "533",
        "EdgeBetweenness" : 54.73792123170734,
        "shared_name" : "dre-miR-301a (miRNA_gene) kctd1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) kctd1",
        "interaction" : "miRNA_gene",
        "SUID" : 1201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1199",
        "source" : "631",
        "target" : "527",
        "EdgeBetweenness" : 95.87797707265266,
        "shared_name" : "dre-miR-301a (miRNA_gene) camta1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) camta1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1197",
        "source" : "631",
        "target" : "521",
        "EdgeBetweenness" : 67.20763781136644,
        "shared_name" : "dre-miR-301a (miRNA_gene) atp2b3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) atp2b3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1197,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1195",
        "source" : "631",
        "target" : "509",
        "EdgeBetweenness" : 62.022359575180424,
        "shared_name" : "dre-miR-301a (miRNA_gene) nphs1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) nphs1",
        "interaction" : "miRNA_gene",
        "SUID" : 1195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1193",
        "source" : "631",
        "target" : "507",
        "EdgeBetweenness" : 49.206015022435345,
        "shared_name" : "dre-miR-301a (miRNA_gene) smad3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) smad3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1191",
        "source" : "631",
        "target" : "503",
        "EdgeBetweenness" : 86.3096304536582,
        "shared_name" : "dre-miR-301a (miRNA_gene) mllt1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) mllt1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1191,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1189",
        "source" : "631",
        "target" : "501",
        "EdgeBetweenness" : 55.284137634263196,
        "shared_name" : "dre-miR-301a (miRNA_gene) iqgap2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) iqgap2",
        "interaction" : "miRNA_gene",
        "SUID" : 1189,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1187",
        "source" : "631",
        "target" : "451",
        "EdgeBetweenness" : 144.88757027640858,
        "shared_name" : "dre-miR-301a (miRNA_gene) hsph1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301a (miRNA_gene) hsph1",
        "interaction" : "miRNA_gene",
        "SUID" : 1187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1185",
        "source" : "629",
        "target" : "645",
        "EdgeBetweenness" : 69.27722067060225,
        "shared_name" : "dre-miR-196b (miRNA_gene) myh14",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196b (miRNA_gene) myh14",
        "interaction" : "miRNA_gene",
        "SUID" : 1185,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1183",
        "source" : "629",
        "target" : "603",
        "EdgeBetweenness" : 60.32483535539027,
        "shared_name" : "dre-miR-196b (miRNA_gene) vsnl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196b (miRNA_gene) vsnl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1181",
        "source" : "629",
        "target" : "579",
        "EdgeBetweenness" : 115.36397335434604,
        "shared_name" : "dre-miR-196b (miRNA_gene) frmpd3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196b (miRNA_gene) frmpd3",
        "interaction" : "miRNA_gene",
        "SUID" : 1181,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1179",
        "source" : "629",
        "target" : "521",
        "EdgeBetweenness" : 78.11495872340903,
        "shared_name" : "dre-miR-196b (miRNA_gene) atp2b3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196b (miRNA_gene) atp2b3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1179,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1177",
        "source" : "629",
        "target" : "503",
        "EdgeBetweenness" : 80.7165948649121,
        "shared_name" : "dre-miR-196b (miRNA_gene) mllt1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196b (miRNA_gene) mllt1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1175",
        "source" : "629",
        "target" : "485",
        "EdgeBetweenness" : 89.76187518827619,
        "shared_name" : "dre-miR-196b (miRNA_gene) nr4a2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196b (miRNA_gene) nr4a2a",
        "interaction" : "miRNA_gene",
        "SUID" : 1175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1173",
        "source" : "627",
        "target" : "625",
        "EdgeBetweenness" : 63.60950470379816,
        "shared_name" : "dre-miR-142a-3p (miRNA_gene) dnajc11",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142a-3p (miRNA_gene) dnajc11",
        "interaction" : "miRNA_gene",
        "SUID" : 1173,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1171",
        "source" : "627",
        "target" : "609",
        "EdgeBetweenness" : 61.05676004886263,
        "shared_name" : "dre-miR-142a-3p (miRNA_gene) rin1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142a-3p (miRNA_gene) rin1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1169",
        "source" : "627",
        "target" : "595",
        "EdgeBetweenness" : 73.28367165125476,
        "shared_name" : "dre-miR-142a-3p (miRNA_gene) sv2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142a-3p (miRNA_gene) sv2a",
        "interaction" : "miRNA_gene",
        "SUID" : 1169,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1167",
        "source" : "627",
        "target" : "571",
        "EdgeBetweenness" : 79.7261357346233,
        "shared_name" : "dre-miR-142a-3p (miRNA_gene) rbfox3a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142a-3p (miRNA_gene) rbfox3a",
        "interaction" : "miRNA_gene",
        "SUID" : 1167,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1165",
        "source" : "627",
        "target" : "563",
        "EdgeBetweenness" : 48.86413784730235,
        "shared_name" : "dre-miR-142a-3p (miRNA_gene) spry4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142a-3p (miRNA_gene) spry4",
        "interaction" : "miRNA_gene",
        "SUID" : 1165,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1163",
        "source" : "627",
        "target" : "557",
        "EdgeBetweenness" : 65.73453513490644,
        "shared_name" : "dre-miR-142a-3p (miRNA_gene) cpe",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142a-3p (miRNA_gene) cpe",
        "interaction" : "miRNA_gene",
        "SUID" : 1163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1161",
        "source" : "627",
        "target" : "545",
        "EdgeBetweenness" : 63.266826514632456,
        "shared_name" : "dre-miR-142a-3p (miRNA_gene) pcnx2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142a-3p (miRNA_gene) pcnx2",
        "interaction" : "miRNA_gene",
        "SUID" : 1161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1159",
        "source" : "627",
        "target" : "511",
        "EdgeBetweenness" : 78.30427070667255,
        "shared_name" : "dre-miR-142a-3p (miRNA_gene) srsf5b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142a-3p (miRNA_gene) srsf5b",
        "interaction" : "miRNA_gene",
        "SUID" : 1159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1157",
        "source" : "627",
        "target" : "499",
        "EdgeBetweenness" : 51.0614145602533,
        "shared_name" : "dre-miR-142a-3p (miRNA_gene) si:ch211-247j9.1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142a-3p (miRNA_gene) si:ch211-247j9.1",
        "interaction" : "miRNA_gene",
        "SUID" : 1157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1155",
        "source" : "627",
        "target" : "465",
        "EdgeBetweenness" : 46.63201485647638,
        "shared_name" : "dre-miR-142a-3p (miRNA_gene) LOC795051",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-142a-3p (miRNA_gene) LOC795051",
        "interaction" : "miRNA_gene",
        "SUID" : 1155,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1153",
        "source" : "623",
        "target" : "625",
        "EdgeBetweenness" : 103.43313102216055,
        "shared_name" : "dre-miR-190a (miRNA_gene) dnajc11",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) dnajc11",
        "interaction" : "miRNA_gene",
        "SUID" : 1153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1151",
        "source" : "623",
        "target" : "615",
        "EdgeBetweenness" : 144.5283021453215,
        "shared_name" : "dre-miR-190a (miRNA_gene) rgma",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) rgma",
        "interaction" : "miRNA_gene",
        "SUID" : 1151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1149",
        "source" : "623",
        "target" : "595",
        "EdgeBetweenness" : 231.4226315591351,
        "shared_name" : "dre-miR-190a (miRNA_gene) sv2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) sv2a",
        "interaction" : "miRNA_gene",
        "SUID" : 1149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1147",
        "source" : "623",
        "target" : "587",
        "EdgeBetweenness" : 103.09889916675652,
        "shared_name" : "dre-miR-190a (miRNA_gene) aldob",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) aldob",
        "interaction" : "miRNA_gene",
        "SUID" : 1147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1145",
        "source" : "623",
        "target" : "585",
        "EdgeBetweenness" : 109.2899563012792,
        "shared_name" : "dre-miR-190a (miRNA_gene) pcdh10a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) pcdh10a",
        "interaction" : "miRNA_gene",
        "SUID" : 1145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1143",
        "source" : "623",
        "target" : "579",
        "EdgeBetweenness" : 230.0366463583797,
        "shared_name" : "dre-miR-190a (miRNA_gene) frmpd3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) frmpd3",
        "interaction" : "miRNA_gene",
        "SUID" : 1143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1141",
        "source" : "623",
        "target" : "571",
        "EdgeBetweenness" : 157.52856210710775,
        "shared_name" : "dre-miR-190a (miRNA_gene) rbfox3a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) rbfox3a",
        "interaction" : "miRNA_gene",
        "SUID" : 1141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1139",
        "source" : "623",
        "target" : "561",
        "EdgeBetweenness" : 1480.9919872538205,
        "shared_name" : "dre-miR-190a (miRNA_gene) acsl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) acsl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1137",
        "source" : "623",
        "target" : "557",
        "EdgeBetweenness" : 138.50938812566488,
        "shared_name" : "dre-miR-190a (miRNA_gene) cpe",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) cpe",
        "interaction" : "miRNA_gene",
        "SUID" : 1137,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1135",
        "source" : "623",
        "target" : "553",
        "EdgeBetweenness" : 94.08637602435816,
        "shared_name" : "dre-miR-190a (miRNA_gene) npdc1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) npdc1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1135,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1133",
        "source" : "623",
        "target" : "549",
        "EdgeBetweenness" : 219.49819397079582,
        "shared_name" : "dre-miR-190a (miRNA_gene) nkx6.2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) nkx6.2",
        "interaction" : "miRNA_gene",
        "SUID" : 1133,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1131",
        "source" : "623",
        "target" : "527",
        "EdgeBetweenness" : 193.6469225447186,
        "shared_name" : "dre-miR-190a (miRNA_gene) camta1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) camta1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1129",
        "source" : "623",
        "target" : "519",
        "EdgeBetweenness" : 202.03816806357756,
        "shared_name" : "dre-miR-190a (miRNA_gene) evx2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) evx2",
        "interaction" : "miRNA_gene",
        "SUID" : 1129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1127",
        "source" : "623",
        "target" : "497",
        "EdgeBetweenness" : 101.32625358567431,
        "shared_name" : "dre-miR-190a (miRNA_gene) ptchd4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) ptchd4",
        "interaction" : "miRNA_gene",
        "SUID" : 1127,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1125",
        "source" : "623",
        "target" : "503",
        "EdgeBetweenness" : 204.52518970253985,
        "shared_name" : "dre-miR-190a (miRNA_gene) mllt1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) mllt1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1123",
        "source" : "623",
        "target" : "495",
        "EdgeBetweenness" : 256.90398675513774,
        "shared_name" : "dre-miR-190a (miRNA_gene) marcksl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) marcksl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1121",
        "source" : "623",
        "target" : "487",
        "EdgeBetweenness" : 188.64402742980215,
        "shared_name" : "dre-miR-190a (miRNA_gene) slc6a1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) slc6a1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1119",
        "source" : "623",
        "target" : "473",
        "EdgeBetweenness" : 201.50242915553716,
        "shared_name" : "dre-miR-190a (miRNA_gene) dpydb",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) dpydb",
        "interaction" : "miRNA_gene",
        "SUID" : 1119,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1117",
        "source" : "623",
        "target" : "465",
        "EdgeBetweenness" : 181.94483149372599,
        "shared_name" : "dre-miR-190a (miRNA_gene) LOC795051",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-190a (miRNA_gene) LOC795051",
        "interaction" : "miRNA_gene",
        "SUID" : 1117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1115",
        "source" : "621",
        "target" : "625",
        "EdgeBetweenness" : 76.25289459947479,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) dnajc11",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) dnajc11",
        "interaction" : "miRNA_gene",
        "SUID" : 1115,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1113",
        "source" : "621",
        "target" : "609",
        "EdgeBetweenness" : 82.64695246983875,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) rin1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) rin1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1111",
        "source" : "621",
        "target" : "583",
        "EdgeBetweenness" : 145.8004387733652,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) en1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) en1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1109",
        "source" : "621",
        "target" : "573",
        "EdgeBetweenness" : 59.013872892826676,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) xkr4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) xkr4",
        "interaction" : "miRNA_gene",
        "SUID" : 1109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1107",
        "source" : "621",
        "target" : "571",
        "EdgeBetweenness" : 101.42288089943408,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) rbfox3a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) rbfox3a",
        "interaction" : "miRNA_gene",
        "SUID" : 1107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1105",
        "source" : "621",
        "target" : "547",
        "EdgeBetweenness" : 73.19009002549728,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) slc35d1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) slc35d1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1103",
        "source" : "621",
        "target" : "539",
        "EdgeBetweenness" : 55.547063792239044,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) plxnb1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) plxnb1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1101",
        "source" : "621",
        "target" : "537",
        "EdgeBetweenness" : 70.02027915651682,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) tgfb1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) tgfb1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1099",
        "source" : "621",
        "target" : "533",
        "EdgeBetweenness" : 57.743521989860824,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) kctd1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) kctd1",
        "interaction" : "miRNA_gene",
        "SUID" : 1099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1097",
        "source" : "621",
        "target" : "531",
        "EdgeBetweenness" : 98.68437676138709,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) fam171a2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) fam171a2a",
        "interaction" : "miRNA_gene",
        "SUID" : 1097,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1095",
        "source" : "621",
        "target" : "527",
        "EdgeBetweenness" : 104.8916090180599,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) camta1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) camta1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1093",
        "source" : "621",
        "target" : "521",
        "EdgeBetweenness" : 81.36591283714506,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) atp2b3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) atp2b3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1093,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1091",
        "source" : "621",
        "target" : "509",
        "EdgeBetweenness" : 68.78038256313336,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) nphs1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) nphs1",
        "interaction" : "miRNA_gene",
        "SUID" : 1091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1089",
        "source" : "621",
        "target" : "507",
        "EdgeBetweenness" : 58.49080210215474,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) smad3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) smad3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1089,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1087",
        "source" : "621",
        "target" : "503",
        "EdgeBetweenness" : 99.84416691865275,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) mllt1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) mllt1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1087,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1085",
        "source" : "621",
        "target" : "501",
        "EdgeBetweenness" : 63.83251847961006,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) iqgap2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) iqgap2",
        "interaction" : "miRNA_gene",
        "SUID" : 1085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1083",
        "source" : "621",
        "target" : "473",
        "EdgeBetweenness" : 107.44014054168541,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) dpydb",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) dpydb",
        "interaction" : "miRNA_gene",
        "SUID" : 1083,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1081",
        "source" : "621",
        "target" : "451",
        "EdgeBetweenness" : 145.8004387733652,
        "shared_name" : "dre-miR-301c-3p (miRNA_gene) hsph1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-301c-3p (miRNA_gene) hsph1",
        "interaction" : "miRNA_gene",
        "SUID" : 1081,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1079",
        "source" : "619",
        "target" : "625",
        "EdgeBetweenness" : 85.14819054500586,
        "shared_name" : "dre-miR-196c (miRNA_gene) dnajc11",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196c (miRNA_gene) dnajc11",
        "interaction" : "miRNA_gene",
        "SUID" : 1079,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1077",
        "source" : "619",
        "target" : "603",
        "EdgeBetweenness" : 65.24200417993066,
        "shared_name" : "dre-miR-196c (miRNA_gene) vsnl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196c (miRNA_gene) vsnl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1077,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1075",
        "source" : "619",
        "target" : "595",
        "EdgeBetweenness" : 88.84433013884495,
        "shared_name" : "dre-miR-196c (miRNA_gene) sv2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196c (miRNA_gene) sv2a",
        "interaction" : "miRNA_gene",
        "SUID" : 1075,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1073",
        "source" : "619",
        "target" : "579",
        "EdgeBetweenness" : 125.60881788382964,
        "shared_name" : "dre-miR-196c (miRNA_gene) frmpd3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196c (miRNA_gene) frmpd3",
        "interaction" : "miRNA_gene",
        "SUID" : 1073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1071",
        "source" : "619",
        "target" : "533",
        "EdgeBetweenness" : 51.824643647471405,
        "shared_name" : "dre-miR-196c (miRNA_gene) kctd1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196c (miRNA_gene) kctd1",
        "interaction" : "miRNA_gene",
        "SUID" : 1071,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1069",
        "source" : "619",
        "target" : "523",
        "EdgeBetweenness" : 72.647030291675,
        "shared_name" : "dre-miR-196c (miRNA_gene) micu3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196c (miRNA_gene) micu3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1069,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1067",
        "source" : "619",
        "target" : "521",
        "EdgeBetweenness" : 83.04920311353077,
        "shared_name" : "dre-miR-196c (miRNA_gene) atp2b3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196c (miRNA_gene) atp2b3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1065",
        "source" : "619",
        "target" : "513",
        "EdgeBetweenness" : 87.26963580628072,
        "shared_name" : "dre-miR-196c (miRNA_gene) glula",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196c (miRNA_gene) glula",
        "interaction" : "miRNA_gene",
        "SUID" : 1065,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1063",
        "source" : "619",
        "target" : "489",
        "EdgeBetweenness" : 84.46087772693144,
        "shared_name" : "dre-miR-196c (miRNA_gene) creg2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196c (miRNA_gene) creg2",
        "interaction" : "miRNA_gene",
        "SUID" : 1063,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1061",
        "source" : "617",
        "target" : "615",
        "EdgeBetweenness" : 116.61658275293567,
        "shared_name" : "dre-miR-107a-5p (miRNA_gene) rgma",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-107a-5p (miRNA_gene) rgma",
        "interaction" : "miRNA_gene",
        "SUID" : 1061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1059",
        "source" : "617",
        "target" : "595",
        "EdgeBetweenness" : 170.48447811284734,
        "shared_name" : "dre-miR-107a-5p (miRNA_gene) sv2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-107a-5p (miRNA_gene) sv2a",
        "interaction" : "miRNA_gene",
        "SUID" : 1059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1057",
        "source" : "617",
        "target" : "561",
        "EdgeBetweenness" : 764.3851652897982,
        "shared_name" : "dre-miR-107a-5p (miRNA_gene) acsl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-107a-5p (miRNA_gene) acsl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1057,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1055",
        "source" : "617",
        "target" : "545",
        "EdgeBetweenness" : 168.51796870478265,
        "shared_name" : "dre-miR-107a-5p (miRNA_gene) pcnx2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-107a-5p (miRNA_gene) pcnx2",
        "interaction" : "miRNA_gene",
        "SUID" : 1055,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1053",
        "source" : "617",
        "target" : "533",
        "EdgeBetweenness" : 156.33073925385847,
        "shared_name" : "dre-miR-107a-5p (miRNA_gene) kctd1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-107a-5p (miRNA_gene) kctd1",
        "interaction" : "miRNA_gene",
        "SUID" : 1053,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1051",
        "source" : "617",
        "target" : "531",
        "EdgeBetweenness" : 101.65737144501406,
        "shared_name" : "dre-miR-107a-5p (miRNA_gene) fam171a2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-107a-5p (miRNA_gene) fam171a2a",
        "interaction" : "miRNA_gene",
        "SUID" : 1051,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1049",
        "source" : "617",
        "target" : "527",
        "EdgeBetweenness" : 150.55762890641245,
        "shared_name" : "dre-miR-107a-5p (miRNA_gene) camta1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-107a-5p (miRNA_gene) camta1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1047",
        "source" : "617",
        "target" : "501",
        "EdgeBetweenness" : 97.54624879610971,
        "shared_name" : "dre-miR-107a-5p (miRNA_gene) iqgap2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-107a-5p (miRNA_gene) iqgap2",
        "interaction" : "miRNA_gene",
        "SUID" : 1047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1045",
        "source" : "617",
        "target" : "487",
        "EdgeBetweenness" : 139.50977773772797,
        "shared_name" : "dre-miR-107a-5p (miRNA_gene) slc6a1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-107a-5p (miRNA_gene) slc6a1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1045,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1043",
        "source" : "613",
        "target" : "615",
        "EdgeBetweenness" : 97.11041469857759,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) rgma",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) rgma",
        "interaction" : "miRNA_gene",
        "SUID" : 1043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1041",
        "source" : "613",
        "target" : "609",
        "EdgeBetweenness" : 115.10915350409053,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) rin1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) rin1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1041,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1039",
        "source" : "613",
        "target" : "589",
        "EdgeBetweenness" : 107.01430947521486,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) gspt1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) gspt1",
        "interaction" : "miRNA_gene",
        "SUID" : 1039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1037",
        "source" : "613",
        "target" : "581",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) zgc:174895",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) zgc:174895",
        "interaction" : "miRNA_gene",
        "SUID" : 1037,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1035",
        "source" : "613",
        "target" : "573",
        "EdgeBetweenness" : 83.49218329214646,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) xkr4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) xkr4",
        "interaction" : "miRNA_gene",
        "SUID" : 1035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1033",
        "source" : "613",
        "target" : "571",
        "EdgeBetweenness" : 146.22316011380386,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) rbfox3a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) rbfox3a",
        "interaction" : "miRNA_gene",
        "SUID" : 1033,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1031",
        "source" : "613",
        "target" : "565",
        "EdgeBetweenness" : 82.3856322733135,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) pcdh2ab9",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) pcdh2ab9",
        "interaction" : "miRNA_gene",
        "SUID" : 1031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1029",
        "source" : "613",
        "target" : "563",
        "EdgeBetweenness" : 86.97754997340338,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) spry4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) spry4",
        "interaction" : "miRNA_gene",
        "SUID" : 1029,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1027",
        "source" : "613",
        "target" : "559",
        "EdgeBetweenness" : 103.97822936246925,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) ptchd1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) ptchd1",
        "interaction" : "miRNA_gene",
        "SUID" : 1027,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1025",
        "source" : "613",
        "target" : "557",
        "EdgeBetweenness" : 124.15116131871906,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) cpe",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) cpe",
        "interaction" : "miRNA_gene",
        "SUID" : 1025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1023",
        "source" : "613",
        "target" : "551",
        "EdgeBetweenness" : 209.90992847425636,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) per1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) per1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1021",
        "source" : "613",
        "target" : "547",
        "EdgeBetweenness" : 87.4226924932798,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) slc35d1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) slc35d1a",
        "interaction" : "miRNA_gene",
        "SUID" : 1021,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1019",
        "source" : "613",
        "target" : "539",
        "EdgeBetweenness" : 85.8792708646404,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) plxnb1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) plxnb1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1017",
        "source" : "613",
        "target" : "523",
        "EdgeBetweenness" : 117.3183768926605,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) micu3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) micu3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1015",
        "source" : "613",
        "target" : "521",
        "EdgeBetweenness" : 126.43713163713525,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) atp2b3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) atp2b3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1015,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1013",
        "source" : "613",
        "target" : "519",
        "EdgeBetweenness" : 117.02688873242924,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) evx2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) evx2",
        "interaction" : "miRNA_gene",
        "SUID" : 1013,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1011",
        "source" : "613",
        "target" : "507",
        "EdgeBetweenness" : 83.37773697266759,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) smad3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) smad3b",
        "interaction" : "miRNA_gene",
        "SUID" : 1011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1009",
        "source" : "613",
        "target" : "497",
        "EdgeBetweenness" : 91.82192282366648,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) ptchd4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) ptchd4",
        "interaction" : "miRNA_gene",
        "SUID" : 1009,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1007",
        "source" : "613",
        "target" : "503",
        "EdgeBetweenness" : 130.11739148323804,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) mllt1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) mllt1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1007,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1005",
        "source" : "613",
        "target" : "469",
        "EdgeBetweenness" : 128.01474522952776,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) unm_hu7912",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) unm_hu7912",
        "interaction" : "miRNA_gene",
        "SUID" : 1005,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1003",
        "source" : "613",
        "target" : "449",
        "EdgeBetweenness" : 156.36381053902392,
        "shared_name" : "dre-miR-430a-3p (miRNA_gene) pcdh15a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-430a-3p (miRNA_gene) pcdh15a",
        "interaction" : "miRNA_gene",
        "SUID" : 1003,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1001",
        "source" : "611",
        "target" : "609",
        "EdgeBetweenness" : 106.76298314409904,
        "shared_name" : "dre-miR-338-3p (miRNA_gene) rin1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-338-3p (miRNA_gene) rin1b",
        "interaction" : "miRNA_gene",
        "SUID" : 1001,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "999",
        "source" : "611",
        "target" : "595",
        "EdgeBetweenness" : 156.2926338828253,
        "shared_name" : "dre-miR-338-3p (miRNA_gene) sv2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-338-3p (miRNA_gene) sv2a",
        "interaction" : "miRNA_gene",
        "SUID" : 999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "997",
        "source" : "611",
        "target" : "579",
        "EdgeBetweenness" : 164.23113666691813,
        "shared_name" : "dre-miR-338-3p (miRNA_gene) frmpd3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-338-3p (miRNA_gene) frmpd3",
        "interaction" : "miRNA_gene",
        "SUID" : 997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "995",
        "source" : "611",
        "target" : "567",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-338-3p (miRNA_gene) rbp4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-338-3p (miRNA_gene) rbp4",
        "interaction" : "miRNA_gene",
        "SUID" : 995,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "993",
        "source" : "611",
        "target" : "565",
        "EdgeBetweenness" : 72.71060726871232,
        "shared_name" : "dre-miR-338-3p (miRNA_gene) pcdh2ab9",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-338-3p (miRNA_gene) pcdh2ab9",
        "interaction" : "miRNA_gene",
        "SUID" : 993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "991",
        "source" : "611",
        "target" : "559",
        "EdgeBetweenness" : 97.35084524530046,
        "shared_name" : "dre-miR-338-3p (miRNA_gene) ptchd1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-338-3p (miRNA_gene) ptchd1",
        "interaction" : "miRNA_gene",
        "SUID" : 991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "989",
        "source" : "611",
        "target" : "557",
        "EdgeBetweenness" : 108.94790216540326,
        "shared_name" : "dre-miR-338-3p (miRNA_gene) cpe",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-338-3p (miRNA_gene) cpe",
        "interaction" : "miRNA_gene",
        "SUID" : 989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "987",
        "source" : "611",
        "target" : "549",
        "EdgeBetweenness" : 97.39224628321469,
        "shared_name" : "dre-miR-338-3p (miRNA_gene) nkx6.2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-338-3p (miRNA_gene) nkx6.2",
        "interaction" : "miRNA_gene",
        "SUID" : 987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "985",
        "source" : "611",
        "target" : "547",
        "EdgeBetweenness" : 72.58294093824918,
        "shared_name" : "dre-miR-338-3p (miRNA_gene) slc35d1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-338-3p (miRNA_gene) slc35d1a",
        "interaction" : "miRNA_gene",
        "SUID" : 985,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "983",
        "source" : "611",
        "target" : "527",
        "EdgeBetweenness" : 137.9782338454766,
        "shared_name" : "dre-miR-338-3p (miRNA_gene) camta1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-338-3p (miRNA_gene) camta1b",
        "interaction" : "miRNA_gene",
        "SUID" : 983,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "981",
        "source" : "611",
        "target" : "499",
        "EdgeBetweenness" : 93.82245534448242,
        "shared_name" : "dre-miR-338-3p (miRNA_gene) si:ch211-247j9.1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-338-3p (miRNA_gene) si:ch211-247j9.1",
        "interaction" : "miRNA_gene",
        "SUID" : 981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "979",
        "source" : "611",
        "target" : "461",
        "EdgeBetweenness" : 177.48066925947757,
        "shared_name" : "dre-miR-338-3p (miRNA_gene) tspan18b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-338-3p (miRNA_gene) tspan18b",
        "interaction" : "miRNA_gene",
        "SUID" : 979,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "977",
        "source" : "607",
        "target" : "609",
        "EdgeBetweenness" : 161.3824539159716,
        "shared_name" : "dre-miR-722 (miRNA_gene) rin1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) rin1b",
        "interaction" : "miRNA_gene",
        "SUID" : 977,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "975",
        "source" : "607",
        "target" : "595",
        "EdgeBetweenness" : 209.23763973729197,
        "shared_name" : "dre-miR-722 (miRNA_gene) sv2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) sv2a",
        "interaction" : "miRNA_gene",
        "SUID" : 975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "973",
        "source" : "607",
        "target" : "589",
        "EdgeBetweenness" : 134.6624997892169,
        "shared_name" : "dre-miR-722 (miRNA_gene) gspt1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) gspt1",
        "interaction" : "miRNA_gene",
        "SUID" : 973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "971",
        "source" : "607",
        "target" : "587",
        "EdgeBetweenness" : 123.47435658169269,
        "shared_name" : "dre-miR-722 (miRNA_gene) aldob",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) aldob",
        "interaction" : "miRNA_gene",
        "SUID" : 971,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "969",
        "source" : "607",
        "target" : "585",
        "EdgeBetweenness" : 143.64419243103035,
        "shared_name" : "dre-miR-722 (miRNA_gene) pcdh10a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) pcdh10a",
        "interaction" : "miRNA_gene",
        "SUID" : 969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "967",
        "source" : "607",
        "target" : "579",
        "EdgeBetweenness" : 242.3333310146974,
        "shared_name" : "dre-miR-722 (miRNA_gene) frmpd3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) frmpd3",
        "interaction" : "miRNA_gene",
        "SUID" : 967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "965",
        "source" : "607",
        "target" : "563",
        "EdgeBetweenness" : 118.46580548123592,
        "shared_name" : "dre-miR-722 (miRNA_gene) spry4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) spry4",
        "interaction" : "miRNA_gene",
        "SUID" : 965,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "963",
        "source" : "607",
        "target" : "559",
        "EdgeBetweenness" : 151.0933174616779,
        "shared_name" : "dre-miR-722 (miRNA_gene) ptchd1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) ptchd1",
        "interaction" : "miRNA_gene",
        "SUID" : 963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "961",
        "source" : "607",
        "target" : "547",
        "EdgeBetweenness" : 127.82341494760944,
        "shared_name" : "dre-miR-722 (miRNA_gene) slc35d1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) slc35d1a",
        "interaction" : "miRNA_gene",
        "SUID" : 961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "959",
        "source" : "607",
        "target" : "545",
        "EdgeBetweenness" : 188.37932906569634,
        "shared_name" : "dre-miR-722 (miRNA_gene) pcnx2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) pcnx2",
        "interaction" : "miRNA_gene",
        "SUID" : 959,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "957",
        "source" : "607",
        "target" : "541",
        "EdgeBetweenness" : 147.37031340851703,
        "shared_name" : "dre-miR-722 (miRNA_gene) neurl1ab",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) neurl1ab",
        "interaction" : "miRNA_gene",
        "SUID" : 957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "955",
        "source" : "607",
        "target" : "539",
        "EdgeBetweenness" : 121.44367944053103,
        "shared_name" : "dre-miR-722 (miRNA_gene) plxnb1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) plxnb1b",
        "interaction" : "miRNA_gene",
        "SUID" : 955,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "953",
        "source" : "607",
        "target" : "537",
        "EdgeBetweenness" : 131.02037082850805,
        "shared_name" : "dre-miR-722 (miRNA_gene) tgfb1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) tgfb1a",
        "interaction" : "miRNA_gene",
        "SUID" : 953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "951",
        "source" : "607",
        "target" : "533",
        "EdgeBetweenness" : 117.22023985384891,
        "shared_name" : "dre-miR-722 (miRNA_gene) kctd1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) kctd1",
        "interaction" : "miRNA_gene",
        "SUID" : 951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "949",
        "source" : "607",
        "target" : "527",
        "EdgeBetweenness" : 233.25032415644094,
        "shared_name" : "dre-miR-722 (miRNA_gene) camta1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) camta1b",
        "interaction" : "miRNA_gene",
        "SUID" : 949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "947",
        "source" : "607",
        "target" : "523",
        "EdgeBetweenness" : 188.2493845149945,
        "shared_name" : "dre-miR-722 (miRNA_gene) micu3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) micu3b",
        "interaction" : "miRNA_gene",
        "SUID" : 947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "945",
        "source" : "607",
        "target" : "521",
        "EdgeBetweenness" : 152.69123331791903,
        "shared_name" : "dre-miR-722 (miRNA_gene) atp2b3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) atp2b3b",
        "interaction" : "miRNA_gene",
        "SUID" : 945,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "943",
        "source" : "607",
        "target" : "517",
        "EdgeBetweenness" : 241.39913506082567,
        "shared_name" : "dre-miR-722 (miRNA_gene) matn4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) matn4",
        "interaction" : "miRNA_gene",
        "SUID" : 943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "941",
        "source" : "607",
        "target" : "511",
        "EdgeBetweenness" : 174.8259757786319,
        "shared_name" : "dre-miR-722 (miRNA_gene) srsf5b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) srsf5b",
        "interaction" : "miRNA_gene",
        "SUID" : 941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "939",
        "source" : "607",
        "target" : "501",
        "EdgeBetweenness" : 139.7706355094642,
        "shared_name" : "dre-miR-722 (miRNA_gene) iqgap2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) iqgap2",
        "interaction" : "miRNA_gene",
        "SUID" : 939,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "937",
        "source" : "607",
        "target" : "499",
        "EdgeBetweenness" : 142.32930640968382,
        "shared_name" : "dre-miR-722 (miRNA_gene) si:ch211-247j9.1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) si:ch211-247j9.1",
        "interaction" : "miRNA_gene",
        "SUID" : 937,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "935",
        "source" : "607",
        "target" : "497",
        "EdgeBetweenness" : 129.07651834487785,
        "shared_name" : "dre-miR-722 (miRNA_gene) ptchd4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) ptchd4",
        "interaction" : "miRNA_gene",
        "SUID" : 935,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "933",
        "source" : "607",
        "target" : "503",
        "EdgeBetweenness" : 174.87681915244997,
        "shared_name" : "dre-miR-722 (miRNA_gene) mllt1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) mllt1b",
        "interaction" : "miRNA_gene",
        "SUID" : 933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "931",
        "source" : "607",
        "target" : "491",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-722 (miRNA_gene) bzw2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) bzw2",
        "interaction" : "miRNA_gene",
        "SUID" : 931,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "929",
        "source" : "607",
        "target" : "479",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-722 (miRNA_gene) hsp70l",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) hsp70l",
        "interaction" : "miRNA_gene",
        "SUID" : 929,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "927",
        "source" : "607",
        "target" : "477",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-722 (miRNA_gene) arl16",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) arl16",
        "interaction" : "miRNA_gene",
        "SUID" : 927,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "925",
        "source" : "607",
        "target" : "475",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-722 (miRNA_gene) hsp70.1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) hsp70.1",
        "interaction" : "miRNA_gene",
        "SUID" : 925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "923",
        "source" : "607",
        "target" : "465",
        "EdgeBetweenness" : 124.73452554014891,
        "shared_name" : "dre-miR-722 (miRNA_gene) LOC795051",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) LOC795051",
        "interaction" : "miRNA_gene",
        "SUID" : 923,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "921",
        "source" : "607",
        "target" : "463",
        "EdgeBetweenness" : 243.98137179837042,
        "shared_name" : "dre-miR-722 (miRNA_gene) odad1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-722 (miRNA_gene) odad1",
        "interaction" : "miRNA_gene",
        "SUID" : 921,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "919",
        "source" : "605",
        "target" : "609",
        "EdgeBetweenness" : 234.71653604144822,
        "shared_name" : "dre-miR-499-5p (miRNA_gene) rin1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-499-5p (miRNA_gene) rin1b",
        "interaction" : "miRNA_gene",
        "SUID" : 919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "917",
        "source" : "605",
        "target" : "579",
        "EdgeBetweenness" : 354.38540887713964,
        "shared_name" : "dre-miR-499-5p (miRNA_gene) frmpd3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-499-5p (miRNA_gene) frmpd3",
        "interaction" : "miRNA_gene",
        "SUID" : 917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "915",
        "source" : "605",
        "target" : "557",
        "EdgeBetweenness" : 241.77867095158743,
        "shared_name" : "dre-miR-499-5p (miRNA_gene) cpe",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-499-5p (miRNA_gene) cpe",
        "interaction" : "miRNA_gene",
        "SUID" : 915,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "913",
        "source" : "605",
        "target" : "551",
        "EdgeBetweenness" : 117.90449016301562,
        "shared_name" : "dre-miR-499-5p (miRNA_gene) per1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-499-5p (miRNA_gene) per1a",
        "interaction" : "miRNA_gene",
        "SUID" : 913,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "911",
        "source" : "605",
        "target" : "545",
        "EdgeBetweenness" : 224.35581683472168,
        "shared_name" : "dre-miR-499-5p (miRNA_gene) pcnx2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-499-5p (miRNA_gene) pcnx2",
        "interaction" : "miRNA_gene",
        "SUID" : 911,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "909",
        "source" : "605",
        "target" : "535",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-499-5p (miRNA_gene) hsp70.3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-499-5p (miRNA_gene) hsp70.3",
        "interaction" : "miRNA_gene",
        "SUID" : 909,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "907",
        "source" : "605",
        "target" : "531",
        "EdgeBetweenness" : 142.42866255067,
        "shared_name" : "dre-miR-499-5p (miRNA_gene) fam171a2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-499-5p (miRNA_gene) fam171a2a",
        "interaction" : "miRNA_gene",
        "SUID" : 907,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "905",
        "source" : "605",
        "target" : "517",
        "EdgeBetweenness" : 105.69476777286413,
        "shared_name" : "dre-miR-499-5p (miRNA_gene) matn4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-499-5p (miRNA_gene) matn4",
        "interaction" : "miRNA_gene",
        "SUID" : 905,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "903",
        "source" : "605",
        "target" : "509",
        "EdgeBetweenness" : 173.03510970521117,
        "shared_name" : "dre-miR-499-5p (miRNA_gene) nphs1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-499-5p (miRNA_gene) nphs1",
        "interaction" : "miRNA_gene",
        "SUID" : 903,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "901",
        "source" : "605",
        "target" : "495",
        "EdgeBetweenness" : 106.11391202028886,
        "shared_name" : "dre-miR-499-5p (miRNA_gene) marcksl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-499-5p (miRNA_gene) marcksl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 901,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "899",
        "source" : "605",
        "target" : "493",
        "EdgeBetweenness" : 118.02794071831782,
        "shared_name" : "dre-miR-499-5p (miRNA_gene) col14a1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-499-5p (miRNA_gene) col14a1a",
        "interaction" : "miRNA_gene",
        "SUID" : 899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "897",
        "source" : "605",
        "target" : "483",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-499-5p (miRNA_gene) zgc:64022",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-499-5p (miRNA_gene) zgc:64022",
        "interaction" : "miRNA_gene",
        "SUID" : 897,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "895",
        "source" : "605",
        "target" : "447",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-499-5p (miRNA_gene) ptprja",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-499-5p (miRNA_gene) ptprja",
        "interaction" : "miRNA_gene",
        "SUID" : 895,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "893",
        "source" : "601",
        "target" : "603",
        "EdgeBetweenness" : 120.3475110105673,
        "shared_name" : "dre-miR-125c-3p (miRNA_gene) vsnl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-125c-3p (miRNA_gene) vsnl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "891",
        "source" : "601",
        "target" : "595",
        "EdgeBetweenness" : 173.74912022274492,
        "shared_name" : "dre-miR-125c-3p (miRNA_gene) sv2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-125c-3p (miRNA_gene) sv2a",
        "interaction" : "miRNA_gene",
        "SUID" : 891,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "889",
        "source" : "599",
        "target" : "603",
        "EdgeBetweenness" : 57.337268625367884,
        "shared_name" : "dre-miR-196a-5p (miRNA_gene) vsnl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196a-5p (miRNA_gene) vsnl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 889,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "887",
        "source" : "599",
        "target" : "595",
        "EdgeBetweenness" : 78.85207503757373,
        "shared_name" : "dre-miR-196a-5p (miRNA_gene) sv2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196a-5p (miRNA_gene) sv2a",
        "interaction" : "miRNA_gene",
        "SUID" : 887,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "885",
        "source" : "599",
        "target" : "579",
        "EdgeBetweenness" : 100.6528293144093,
        "shared_name" : "dre-miR-196a-5p (miRNA_gene) frmpd3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196a-5p (miRNA_gene) frmpd3",
        "interaction" : "miRNA_gene",
        "SUID" : 885,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "883",
        "source" : "599",
        "target" : "545",
        "EdgeBetweenness" : 67.73582822546047,
        "shared_name" : "dre-miR-196a-5p (miRNA_gene) pcnx2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196a-5p (miRNA_gene) pcnx2",
        "interaction" : "miRNA_gene",
        "SUID" : 883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "881",
        "source" : "599",
        "target" : "503",
        "EdgeBetweenness" : 87.16802452695048,
        "shared_name" : "dre-miR-196a-5p (miRNA_gene) mllt1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196a-5p (miRNA_gene) mllt1b",
        "interaction" : "miRNA_gene",
        "SUID" : 881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "879",
        "source" : "599",
        "target" : "489",
        "EdgeBetweenness" : 66.44633721384032,
        "shared_name" : "dre-miR-196a-5p (miRNA_gene) creg2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196a-5p (miRNA_gene) creg2",
        "interaction" : "miRNA_gene",
        "SUID" : 879,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "877",
        "source" : "597",
        "target" : "603",
        "EdgeBetweenness" : 78.1306967131894,
        "shared_name" : "dre-miR-196d (miRNA_gene) vsnl1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196d (miRNA_gene) vsnl1a",
        "interaction" : "miRNA_gene",
        "SUID" : 877,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "875",
        "source" : "597",
        "target" : "595",
        "EdgeBetweenness" : 119.53009504253414,
        "shared_name" : "dre-miR-196d (miRNA_gene) sv2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196d (miRNA_gene) sv2a",
        "interaction" : "miRNA_gene",
        "SUID" : 875,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "873",
        "source" : "597",
        "target" : "571",
        "EdgeBetweenness" : 131.3310492949188,
        "shared_name" : "dre-miR-196d (miRNA_gene) rbfox3a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196d (miRNA_gene) rbfox3a",
        "interaction" : "miRNA_gene",
        "SUID" : 873,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "871",
        "source" : "597",
        "target" : "545",
        "EdgeBetweenness" : 109.89567595936295,
        "shared_name" : "dre-miR-196d (miRNA_gene) pcnx2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196d (miRNA_gene) pcnx2",
        "interaction" : "miRNA_gene",
        "SUID" : 871,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "869",
        "source" : "597",
        "target" : "521",
        "EdgeBetweenness" : 97.7240864713329,
        "shared_name" : "dre-miR-196d (miRNA_gene) atp2b3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196d (miRNA_gene) atp2b3b",
        "interaction" : "miRNA_gene",
        "SUID" : 869,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "867",
        "source" : "597",
        "target" : "503",
        "EdgeBetweenness" : 113.33078775361369,
        "shared_name" : "dre-miR-196d (miRNA_gene) mllt1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196d (miRNA_gene) mllt1b",
        "interaction" : "miRNA_gene",
        "SUID" : 867,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "865",
        "source" : "597",
        "target" : "457",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-196d (miRNA_gene) cyp2p8",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-196d (miRNA_gene) cyp2p8",
        "interaction" : "miRNA_gene",
        "SUID" : 865,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "863",
        "source" : "593",
        "target" : "595",
        "EdgeBetweenness" : 100.89764612534057,
        "shared_name" : "dre-miR-10b-5p (miRNA_gene) sv2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10b-5p (miRNA_gene) sv2a",
        "interaction" : "miRNA_gene",
        "SUID" : 863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "861",
        "source" : "593",
        "target" : "537",
        "EdgeBetweenness" : 63.053902893569116,
        "shared_name" : "dre-miR-10b-5p (miRNA_gene) tgfb1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10b-5p (miRNA_gene) tgfb1a",
        "interaction" : "miRNA_gene",
        "SUID" : 861,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "859",
        "source" : "593",
        "target" : "521",
        "EdgeBetweenness" : 73.10234240541455,
        "shared_name" : "dre-miR-10b-5p (miRNA_gene) atp2b3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10b-5p (miRNA_gene) atp2b3b",
        "interaction" : "miRNA_gene",
        "SUID" : 859,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "857",
        "source" : "593",
        "target" : "511",
        "EdgeBetweenness" : 39.69613256934239,
        "shared_name" : "dre-miR-10b-5p (miRNA_gene) srsf5b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10b-5p (miRNA_gene) srsf5b",
        "interaction" : "miRNA_gene",
        "SUID" : 857,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "855",
        "source" : "593",
        "target" : "589",
        "EdgeBetweenness" : 62.807823425653304,
        "shared_name" : "dre-miR-10b-5p (miRNA_gene) gspt1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10b-5p (miRNA_gene) gspt1",
        "interaction" : "miRNA_gene",
        "SUID" : 855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "853",
        "source" : "593",
        "target" : "467",
        "EdgeBetweenness" : 43.77432105703981,
        "shared_name" : "dre-miR-10b-5p (miRNA_gene) dusp7",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10b-5p (miRNA_gene) dusp7",
        "interaction" : "miRNA_gene",
        "SUID" : 853,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "851",
        "source" : "591",
        "target" : "595",
        "EdgeBetweenness" : 113.18047414932468,
        "shared_name" : "dre-miR-10a-5p (miRNA_gene) sv2a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10a-5p (miRNA_gene) sv2a",
        "interaction" : "miRNA_gene",
        "SUID" : 851,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "849",
        "source" : "591",
        "target" : "537",
        "EdgeBetweenness" : 70.05817918380527,
        "shared_name" : "dre-miR-10a-5p (miRNA_gene) tgfb1a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10a-5p (miRNA_gene) tgfb1a",
        "interaction" : "miRNA_gene",
        "SUID" : 849,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "847",
        "source" : "591",
        "target" : "521",
        "EdgeBetweenness" : 81.73048237982027,
        "shared_name" : "dre-miR-10a-5p (miRNA_gene) atp2b3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10a-5p (miRNA_gene) atp2b3b",
        "interaction" : "miRNA_gene",
        "SUID" : 847,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "845",
        "source" : "591",
        "target" : "511",
        "EdgeBetweenness" : 40.109867844353374,
        "shared_name" : "dre-miR-10a-5p (miRNA_gene) srsf5b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10a-5p (miRNA_gene) srsf5b",
        "interaction" : "miRNA_gene",
        "SUID" : 845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "843",
        "source" : "591",
        "target" : "589",
        "EdgeBetweenness" : 70.17640863320104,
        "shared_name" : "dre-miR-10a-5p (miRNA_gene) gspt1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10a-5p (miRNA_gene) gspt1",
        "interaction" : "miRNA_gene",
        "SUID" : 843,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "841",
        "source" : "591",
        "target" : "467",
        "EdgeBetweenness" : 50.748251673304914,
        "shared_name" : "dre-miR-10a-5p (miRNA_gene) dusp7",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10a-5p (miRNA_gene) dusp7",
        "interaction" : "miRNA_gene",
        "SUID" : 841,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "839",
        "source" : "591",
        "target" : "463",
        "EdgeBetweenness" : 56.97916321978386,
        "shared_name" : "dre-miR-10a-5p (miRNA_gene) odad1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10a-5p (miRNA_gene) odad1",
        "interaction" : "miRNA_gene",
        "SUID" : 839,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "837",
        "source" : "577",
        "target" : "579",
        "EdgeBetweenness" : 350.05702014494074,
        "shared_name" : "dre-miR-202-3p (miRNA_gene) frmpd3",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-202-3p (miRNA_gene) frmpd3",
        "interaction" : "miRNA_gene",
        "SUID" : 837,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "835",
        "source" : "577",
        "target" : "563",
        "EdgeBetweenness" : 102.68992026568118,
        "shared_name" : "dre-miR-202-3p (miRNA_gene) spry4",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-202-3p (miRNA_gene) spry4",
        "interaction" : "miRNA_gene",
        "SUID" : 835,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "833",
        "source" : "577",
        "target" : "559",
        "EdgeBetweenness" : 188.64934050595508,
        "shared_name" : "dre-miR-202-3p (miRNA_gene) ptchd1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-202-3p (miRNA_gene) ptchd1",
        "interaction" : "miRNA_gene",
        "SUID" : 833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "831",
        "source" : "577",
        "target" : "515",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-202-3p (miRNA_gene) tent5ba",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-202-3p (miRNA_gene) tent5ba",
        "interaction" : "miRNA_gene",
        "SUID" : 831,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "829",
        "source" : "577",
        "target" : "505",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-202-3p (miRNA_gene) hnf1bb",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-202-3p (miRNA_gene) hnf1bb",
        "interaction" : "miRNA_gene",
        "SUID" : 829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "827",
        "source" : "577",
        "target" : "503",
        "EdgeBetweenness" : 238.21468972505903,
        "shared_name" : "dre-miR-202-3p (miRNA_gene) mllt1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-202-3p (miRNA_gene) mllt1b",
        "interaction" : "miRNA_gene",
        "SUID" : 827,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "825",
        "source" : "569",
        "target" : "571",
        "EdgeBetweenness" : 342.82683158757175,
        "shared_name" : "dre-let-7b (miRNA_gene) rbfox3a",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-let-7b (miRNA_gene) rbfox3a",
        "interaction" : "miRNA_gene",
        "SUID" : 825,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "823",
        "source" : "569",
        "target" : "555",
        "EdgeBetweenness" : 66.07839095394685,
        "shared_name" : "dre-let-7b (miRNA_gene) acvr1c",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-let-7b (miRNA_gene) acvr1c",
        "interaction" : "miRNA_gene",
        "SUID" : 823,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "821",
        "source" : "569",
        "target" : "523",
        "EdgeBetweenness" : 136.58728869740898,
        "shared_name" : "dre-let-7b (miRNA_gene) micu3b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-let-7b (miRNA_gene) micu3b",
        "interaction" : "miRNA_gene",
        "SUID" : 821,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "819",
        "source" : "569",
        "target" : "487",
        "EdgeBetweenness" : 104.88221277705274,
        "shared_name" : "dre-let-7b (miRNA_gene) slc6a1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-let-7b (miRNA_gene) slc6a1b",
        "interaction" : "miRNA_gene",
        "SUID" : 819,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "817",
        "source" : "569",
        "target" : "481",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-let-7b (miRNA_gene) fkbp11",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-let-7b (miRNA_gene) fkbp11",
        "interaction" : "miRNA_gene",
        "SUID" : 817,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "815",
        "source" : "543",
        "target" : "545",
        "EdgeBetweenness" : 149.75065359108382,
        "shared_name" : "dre-miR-34c-3p (miRNA_gene) pcnx2",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-34c-3p (miRNA_gene) pcnx2",
        "interaction" : "miRNA_gene",
        "SUID" : 815,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "813",
        "source" : "543",
        "target" : "499",
        "EdgeBetweenness" : 143.2210338033033,
        "shared_name" : "dre-miR-34c-3p (miRNA_gene) si:ch211-247j9.1",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-34c-3p (miRNA_gene) si:ch211-247j9.1",
        "interaction" : "miRNA_gene",
        "SUID" : 813,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "811",
        "source" : "529",
        "target" : "527",
        "EdgeBetweenness" : 576.0,
        "shared_name" : "dre-miR-10b-3p (miRNA_gene) camta1b",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10b-3p (miRNA_gene) camta1b",
        "interaction" : "miRNA_gene",
        "SUID" : 811,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "809",
        "source" : "529",
        "target" : "459",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "dre-miR-10b-3p (miRNA_gene) cfap74",
        "shared_interaction" : "miRNA_gene",
        "name" : "dre-miR-10b-3p (miRNA_gene) cfap74",
        "interaction" : "miRNA_gene",
        "SUID" : 809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "807",
        "source" : "445",
        "target" : "443",
        "EdgeBetweenness" : 142.97777777777776,
        "shared_name" : "piR-dre-2441 (piRNA_TE) Gypsy151-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-2441 (piRNA_TE) Gypsy151-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 27.78,
        "SUID" : 807,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "805",
        "source" : "445",
        "target" : "441",
        "EdgeBetweenness" : 403.77777777777777,
        "shared_name" : "piR-dre-2441 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-2441 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 27.78,
        "SUID" : 805,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "803",
        "source" : "439",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-10247 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-10247 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 30.0,
        "SUID" : 803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "801",
        "source" : "439",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-10247 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-10247 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 40.0,
        "SUID" : 801,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "799",
        "source" : "439",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-10247 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-10247 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 45.0,
        "SUID" : 799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "797",
        "source" : "437",
        "target" : "561",
        "EdgeBetweenness" : 9090.0,
        "shared_name" : "DNA-3-1_DR (TE_gene) acsl1a",
        "shared_interaction" : "TE_gene",
        "name" : "DNA-3-1_DR (TE_gene) acsl1a",
        "interaction" : "TE_gene",
        "SUID" : 797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "795",
        "source" : "435",
        "target" : "441",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-13310 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-13310 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 42.11,
        "SUID" : 795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "793",
        "source" : "435",
        "target" : "441",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-13310 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-13310 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.58,
        "SUID" : 793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "791",
        "source" : "435",
        "target" : "441",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-13310 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-13310 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 36.84,
        "SUID" : 791,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "789",
        "source" : "433",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-15727 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-15727 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "787",
        "source" : "433",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-15727 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-15727 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 26.32,
        "SUID" : 787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "785",
        "source" : "431",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-17612 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-17612 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.58,
        "SUID" : 785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "783",
        "source" : "431",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-17612 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-17612 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 783,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "781",
        "source" : "431",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-17612 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-17612 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 36.84,
        "SUID" : 781,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "779",
        "source" : "429",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-18163 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-18163 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "777",
        "source" : "427",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-19094 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-19094 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 22.22,
        "SUID" : 777,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "775",
        "source" : "427",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-19094 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-19094 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 33.33,
        "SUID" : 775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "773",
        "source" : "425",
        "target" : "441",
        "EdgeBetweenness" : 966.8777777777763,
        "shared_name" : "piR-dre-19951 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-19951 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 27.78,
        "SUID" : 773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "771",
        "source" : "425",
        "target" : "437",
        "EdgeBetweenness" : 1171.8777777777782,
        "shared_name" : "piR-dre-19951 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-19951 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 22.22,
        "SUID" : 771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "769",
        "source" : "423",
        "target" : "441",
        "EdgeBetweenness" : 966.8777777777763,
        "shared_name" : "piR-dre-21062 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-21062 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 22.22,
        "SUID" : 769,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "source" : "423",
        "target" : "437",
        "EdgeBetweenness" : 1171.8777777777782,
        "shared_name" : "piR-dre-21062 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-21062 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 38.89,
        "SUID" : 767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "765",
        "source" : "423",
        "target" : "441",
        "EdgeBetweenness" : 966.8777777777763,
        "shared_name" : "piR-dre-21062 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-21062 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 33.33,
        "SUID" : 765,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "763",
        "source" : "423",
        "target" : "441",
        "EdgeBetweenness" : 966.8777777777763,
        "shared_name" : "piR-dre-21062 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-21062 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 27.78,
        "SUID" : 763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "761",
        "source" : "423",
        "target" : "437",
        "EdgeBetweenness" : 1171.8777777777782,
        "shared_name" : "piR-dre-21062 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-21062 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 33.33,
        "SUID" : 761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "759",
        "source" : "421",
        "target" : "437",
        "EdgeBetweenness" : 1171.8777777777775,
        "shared_name" : "piR-dre-24037 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-24037 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 44.44,
        "SUID" : 759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "757",
        "source" : "421",
        "target" : "441",
        "EdgeBetweenness" : 966.8777777777763,
        "shared_name" : "piR-dre-24037 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-24037 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 33.33,
        "SUID" : 757,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "755",
        "source" : "419",
        "target" : "441",
        "EdgeBetweenness" : 873.4777777777794,
        "shared_name" : "piR-dre-27928 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-27928 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 35.29,
        "SUID" : 755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "753",
        "source" : "419",
        "target" : "417",
        "EdgeBetweenness" : 582.0555555555563,
        "shared_name" : "piR-dre-27928 (piRNA_TE) BEL23-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-27928 (piRNA_TE) BEL23-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 23.53,
        "SUID" : 753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "751",
        "source" : "419",
        "target" : "441",
        "EdgeBetweenness" : 873.4777777777794,
        "shared_name" : "piR-dre-27928 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-27928 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 41.18,
        "SUID" : 751,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "749",
        "source" : "419",
        "target" : "441",
        "EdgeBetweenness" : 873.4777777777794,
        "shared_name" : "piR-dre-27928 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-27928 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 23.53,
        "SUID" : 749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "747",
        "source" : "419",
        "target" : "443",
        "EdgeBetweenness" : 204.66666666666663,
        "shared_name" : "piR-dre-27928 (piRNA_TE) Gypsy151-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-27928 (piRNA_TE) Gypsy151-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 29.41,
        "SUID" : 747,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "745",
        "source" : "415",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-31928 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-31928 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 25.0,
        "SUID" : 745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "743",
        "source" : "413",
        "target" : "411",
        "EdgeBetweenness" : 874.1111111111086,
        "shared_name" : "piR-dre-34461 (piRNA_TE) Gypsy101-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-34461 (piRNA_TE) Gypsy101-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.58,
        "SUID" : 743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "741",
        "source" : "413",
        "target" : "409",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-34461 (piRNA_TE) BEL-37-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-34461 (piRNA_TE) BEL-37-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 741,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "739",
        "source" : "413",
        "target" : "417",
        "EdgeBetweenness" : 242.1111111111117,
        "shared_name" : "piR-dre-34461 (piRNA_TE) BEL23-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-34461 (piRNA_TE) BEL23-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.58,
        "SUID" : 739,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "737",
        "source" : "413",
        "target" : "407",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-34461 (piRNA_TE) BEL30-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-34461 (piRNA_TE) BEL30-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 737,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "735",
        "source" : "405",
        "target" : "403",
        "EdgeBetweenness" : 180.26666666666605,
        "shared_name" : "piR-dre-34810 (piRNA_TE) Gypsy160-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-34810 (piRNA_TE) Gypsy160-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "733",
        "source" : "405",
        "target" : "403",
        "EdgeBetweenness" : 180.26666666666605,
        "shared_name" : "piR-dre-34810 (piRNA_TE) Gypsy160-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-34810 (piRNA_TE) Gypsy160-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 26.32,
        "SUID" : 733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "731",
        "source" : "405",
        "target" : "417",
        "EdgeBetweenness" : 140.66666666666723,
        "shared_name" : "piR-dre-34810 (piRNA_TE) BEL23-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-34810 (piRNA_TE) BEL23-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 26.32,
        "SUID" : 731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "729",
        "source" : "401",
        "target" : "443",
        "EdgeBetweenness" : 142.9777777777778,
        "shared_name" : "piR-dre-35440 (piRNA_TE) Gypsy151-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35440 (piRNA_TE) Gypsy151-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.58,
        "SUID" : 729,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "727",
        "source" : "401",
        "target" : "441",
        "EdgeBetweenness" : 403.77777777777777,
        "shared_name" : "piR-dre-35440 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35440 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.58,
        "SUID" : 727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "725",
        "source" : "399",
        "target" : "443",
        "EdgeBetweenness" : 142.9777777777778,
        "shared_name" : "piR-dre-35441 (piRNA_TE) Gypsy151-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35441 (piRNA_TE) Gypsy151-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 29.41,
        "SUID" : 725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "723",
        "source" : "399",
        "target" : "441",
        "EdgeBetweenness" : 403.77777777777777,
        "shared_name" : "piR-dre-35441 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35441 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 29.41,
        "SUID" : 723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "721",
        "source" : "397",
        "target" : "403",
        "EdgeBetweenness" : 337.2000000000009,
        "shared_name" : "piR-dre-35848 (piRNA_TE) Gypsy160-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35848 (piRNA_TE) Gypsy160-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 27.78,
        "SUID" : 721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "719",
        "source" : "397",
        "target" : "441",
        "EdgeBetweenness" : 577.2666666666678,
        "shared_name" : "piR-dre-35848 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35848 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 27.78,
        "SUID" : 719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "717",
        "source" : "395",
        "target" : "403",
        "EdgeBetweenness" : 337.2000000000009,
        "shared_name" : "piR-dre-35849 (piRNA_TE) Gypsy160-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35849 (piRNA_TE) Gypsy160-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 29.41,
        "SUID" : 717,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "715",
        "source" : "395",
        "target" : "441",
        "EdgeBetweenness" : 577.2666666666678,
        "shared_name" : "piR-dre-35849 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35849 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 23.53,
        "SUID" : 715,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "713",
        "source" : "393",
        "target" : "403",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-35850 (piRNA_TE) Gypsy160-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35850 (piRNA_TE) Gypsy160-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 25.0,
        "SUID" : 713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "711",
        "source" : "391",
        "target" : "403",
        "EdgeBetweenness" : 169.06666666666683,
        "shared_name" : "piR-dre-42667 (piRNA_TE) Gypsy160-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-42667 (piRNA_TE) Gypsy160-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 25.0,
        "SUID" : 711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "709",
        "source" : "391",
        "target" : "417",
        "EdgeBetweenness" : 166.74444444444475,
        "shared_name" : "piR-dre-42667 (piRNA_TE) BEL23-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-42667 (piRNA_TE) BEL23-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 25.0,
        "SUID" : 709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "707",
        "source" : "391",
        "target" : "411",
        "EdgeBetweenness" : 505.8777777777761,
        "shared_name" : "piR-dre-42667 (piRNA_TE) Gypsy101-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-42667 (piRNA_TE) Gypsy101-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 30.0,
        "SUID" : 707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "705",
        "source" : "389",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-48972 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-48972 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 52.63,
        "SUID" : 705,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "703",
        "source" : "387",
        "target" : "443",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-51545 (piRNA_TE) Gypsy151-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-51545 (piRNA_TE) Gypsy151-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 703,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "701",
        "source" : "387",
        "target" : "443",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-51545 (piRNA_TE) Gypsy151-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-51545 (piRNA_TE) Gypsy151-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 36.84,
        "SUID" : 701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "699",
        "source" : "385",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-57020 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-57020 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 27.78,
        "SUID" : 699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "697",
        "source" : "383",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-69525 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-69525 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 23.53,
        "SUID" : 697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "695",
        "source" : "381",
        "target" : "441",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-71201 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-71201 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 29.41,
        "SUID" : 695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "693",
        "source" : "379",
        "target" : "411",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-72927 (piRNA_TE) Gypsy101-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-72927 (piRNA_TE) Gypsy101-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 29.41,
        "SUID" : 693,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "691",
        "source" : "377",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-80231 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-80231 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 25.0,
        "SUID" : 691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "source" : "377",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-80231 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-80231 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.25,
        "SUID" : 689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "687",
        "source" : "375",
        "target" : "411",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-83372 (piRNA_TE) Gypsy101-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-83372 (piRNA_TE) Gypsy101-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.25,
        "SUID" : 687,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "685",
        "source" : "373",
        "target" : "437",
        "EdgeBetweenness" : 2675.5444444444493,
        "shared_name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "683",
        "source" : "373",
        "target" : "437",
        "EdgeBetweenness" : 2675.5444444444493,
        "shared_name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 26.32,
        "SUID" : 683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "681",
        "source" : "373",
        "target" : "371",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-133212 (piRNA_TE) Gypsy-21-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-133212 (piRNA_TE) Gypsy-21-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 26.32,
        "SUID" : 681,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "679",
        "source" : "373",
        "target" : "437",
        "EdgeBetweenness" : 2675.5444444444493,
        "shared_name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 36.84,
        "SUID" : 679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "677",
        "source" : "373",
        "target" : "437",
        "EdgeBetweenness" : 2675.5444444444493,
        "shared_name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 42.11,
        "SUID" : 677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "675",
        "source" : "373",
        "target" : "411",
        "EdgeBetweenness" : 2211.1888888888925,
        "shared_name" : "piR-dre-133212 (piRNA_TE) Gypsy101-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-133212 (piRNA_TE) Gypsy101-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "673",
        "source" : "369",
        "target" : "411",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-426176 (piRNA_TE) Gypsy101-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-426176 (piRNA_TE) Gypsy101-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 29.41,
        "SUID" : 673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "671",
        "source" : "367",
        "target" : "417",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-492597 (piRNA_TE) BEL23-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-492597 (piRNA_TE) BEL23-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "669",
        "source" : "365",
        "target" : "441",
        "EdgeBetweenness" : 1007.3777777777761,
        "shared_name" : "piR-dre-555119 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 25.0,
        "SUID" : 669,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "667",
        "source" : "365",
        "target" : "437",
        "EdgeBetweenness" : 1417.3777777777802,
        "shared_name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 35.0,
        "SUID" : 667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "665",
        "source" : "365",
        "target" : "437",
        "EdgeBetweenness" : 1417.3777777777802,
        "shared_name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 30.0,
        "SUID" : 665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "663",
        "source" : "365",
        "target" : "437",
        "EdgeBetweenness" : 1417.3777777777802,
        "shared_name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 20.0,
        "SUID" : 663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "661",
        "source" : "365",
        "target" : "437",
        "EdgeBetweenness" : 1417.3777777777802,
        "shared_name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 25.0,
        "SUID" : 661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "659",
        "source" : "365",
        "target" : "363",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-555119 (piRNA_TE) Gypsy127-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) Gypsy127-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 60.0,
        "SUID" : 659,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "657",
        "source" : "365",
        "target" : "437",
        "EdgeBetweenness" : 1417.3777777777802,
        "shared_name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 40.0,
        "SUID" : 657,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "655",
        "source" : "365",
        "target" : "437",
        "EdgeBetweenness" : 1417.3777777777802,
        "shared_name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 45.0,
        "SUID" : 655,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "653",
        "source" : "361",
        "target" : "441",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-809338 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-809338 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 20.0,
        "SUID" : 653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "651",
        "source" : "359",
        "target" : "357",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-1029262 (piRNA_TE) Gypsy100-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-1029262 (piRNA_TE) Gypsy100-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 28.57,
        "SUID" : 651,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "649",
        "source" : "359",
        "target" : "437",
        "EdgeBetweenness" : 576.0,
        "shared_name" : "piR-dre-1029262 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-1029262 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 33.33,
        "SUID" : 649,
        "selected" : false
      },
      "selected" : false
    } ]
  }
},"female_FINAL_edges.csv(1)": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "female_FINAL_edges.csv(1)",
    "EnrichmentTable_Gene_ID_Column" : "name",
    "EnrichmentTable_organism" : "hsapiens",
    "EnrichmentTable_User_Threshold" : 0.05,
    "__Annotations" : [ "" ],
    "name" : "female_FINAL_edges.csv(1)",
    "SUID" : 1483,
    "EnrichmentTable_No_IEA" : false,
    "EnrichmentTable_Significance_Threshold_Method" : "g_SCS",
    "selected" : false
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "395",
        "degree_layout" : 2,
        "padj" : 0.045839752,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-35849",
        "TopologicalCoefficient" : 0.5333333333333333,
        "SUID" : 395,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.6,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.17857142857142858,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 23.53,
        "significant" : true,
        "Radiality" : 0.8413793103448275,
        "Stress" : 60908,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.014953703703703743,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-35849",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.573627471,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 476.2266463514877,
        "y" : 611.5606024363269
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "degree_layout" : 1,
        "padj" : 0.045260357,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-83372",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 375,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.848275862068966,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.17099056603773585,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 31.25,
        "significant" : true,
        "Radiality" : 0.8328180737217598,
        "Stress" : 0,
        "target_original" : "Gypsy101-LTR_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-83372",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.533873895,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 26.29863731828459,
        "y" : 783.9171087839832
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "429",
        "degree_layout" : 1,
        "padj" : 0.045839752,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-18163",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 429,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 21.05,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-18163",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -1.711458258,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 274.37169640031584,
        "y" : 799.8032171824207
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "415",
        "degree_layout" : 1,
        "padj" : 0.045839752,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-31928",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 415,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 25.0,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-31928",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -3.916098015,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 635.829734320433,
        "y" : 974.0548602570261
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "degree_layout" : 1,
        "padj" : 0.044397827,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-809338",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 361,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.710344827586207,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.1751207729468599,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 20.0,
        "significant" : true,
        "Radiality" : 0.8375743162901309,
        "Stress" : 0,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-809338",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.756745586,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 747.6379622694565,
        "y" : 781.9182074167957
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "373",
        "degree_layout" : 6,
        "padj" : 0.045839752,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-133212",
        "TopologicalCoefficient" : 0.3333333333333333,
        "SUID" : 373,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.096551724137931,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.24410774410774413,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 21.05,
        "significant" : true,
        "Radiality" : 0.8932223543400714,
        "Stress" : 91588,
        "target_original" : "Gypsy101-LTR_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.11701947637292485,
        "NumberOfUndirectedEdges" : 6,
        "name" : "piR-dre-133212",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -3.71813793,
        "NeighborhoodConnectivity" : 8.0
      },
      "position" : {
        "x" : 309.18032066789397,
        "y" : 858.6064398386707
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "427",
        "degree_layout" : 2,
        "padj" : 0.005576147,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-19094",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 427,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 33.33,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-19094",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.111245694,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 518.492044169519,
        "y" : 970.5038274519909
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "degree_layout" : 4,
        "padj" : 0.04877372,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-34461",
        "TopologicalCoefficient" : 0.28125,
        "SUID" : 413,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.641379310344828,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.17726161369193152,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 21.05,
        "significant" : true,
        "Radiality" : 0.8399524375743163,
        "Stress" : 25646,
        "target_original" : "BEL30-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.03367390378884621,
        "NumberOfUndirectedEdges" : 4,
        "name" : "piR-dre-34461",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 4.915022987,
        "NeighborhoodConnectivity" : 3.25
      },
      "position" : {
        "x" : 175.54518883195647,
        "y" : 649.4405462839832
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "degree_layout" : 2,
        "padj" : 0.044397827,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-1029262",
        "TopologicalCoefficient" : 0.5,
        "SUID" : 359,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.275862068965517,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2338709677419355,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 33.33,
        "significant" : true,
        "Radiality" : 0.8870392390011891,
        "Stress" : 5320,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.013793103448275862,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-1029262",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 4.622096848,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 404.5033797499252,
        "y" : 1047.3869133402957
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "393",
        "degree_layout" : 1,
        "padj" : 0.049745525,
        "Eccentricity" : 10,
        "shared_name" : "piR-dre-35850",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 393,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 7.379310344827586,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.13551401869158877,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 25.0,
        "significant" : true,
        "Radiality" : 0.7800237812128418,
        "Stress" : 0,
        "target_original" : "Gypsy160-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-35850",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.513152597,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 430.1438826796127,
        "y" : 415.07726503398317
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "411",
        "degree_layout" : 6,
        "padj" : 0.0450926851915556,
        "Eccentricity" : 7,
        "pvalue" : 0.00100012128157242,
        "shared_name" : "Gypsy101-LTR_DR",
        "TopologicalCoefficient" : 0.19444444444444445,
        "baseMean" : 132.366733685692,
        "SUID" : 411,
        "lfcSE" : 0.332601431795446,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.855172413793103,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2059659090909091,
        "stat" : 3.29049261169023,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8670630202140309,
        "Stress" : 81660,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.09988452532992774,
        "NumberOfUndirectedEdges" : 6,
        "name" : "Gypsy101-LTR_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.09442255396051,
        "NeighborhoodConnectivity" : 2.1666666666666665
      },
      "position" : {
        "x" : 150.94930260148772,
        "y" : 781.6586859324207
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "357",
        "degree_layout" : 1,
        "padj" : 0.0368940255327715,
        "Eccentricity" : 7,
        "pvalue" : 6.1853888960267E-4,
        "shared_name" : "Gypsy100-I_DR",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 222.70137450078,
        "SUID" : 357,
        "lfcSE" : 0.359133988857157,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.268965517241379,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.18979057591623036,
        "stat" : 3.42335215333662,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8527942925089179,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Gypsy100-I_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.22944211409052,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 409.1226424452377,
        "y" : 1160.4959662058582
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "445",
        "degree_layout" : 2,
        "padj" : 0.005576147,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-2441",
        "TopologicalCoefficient" : 0.6153846153846154,
        "SUID" : 445,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.682758620689655,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.17597087378640777,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 27.78,
        "significant" : true,
        "Radiality" : 0.838525564803805,
        "Stress" : 40572,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.006148361004682845,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-2441",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 1.863473041,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 626.4282454725815,
        "y" : 528.5183050730457
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "degree_layout" : 6,
        "padj" : 0.0235680127672742,
        "Eccentricity" : 9,
        "pvalue" : 2.2173016500062E-4,
        "shared_name" : "Gypsy151-I_DR",
        "TopologicalCoefficient" : 0.5,
        "baseMean" : 16.1542606262826,
        "SUID" : 443,
        "lfcSE" : 0.482803760951495,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 6.468965517241379,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.15458422174840086,
        "stat" : -3.69287828128154,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8114149821640904,
        "Stress" : 81300,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.015172413793103447,
        "NumberOfUndirectedEdges" : 6,
        "name" : "Gypsy151-I_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.78293552293882,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 721.681297230394,
        "y" : 560.3635809519519
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "391",
        "degree_layout" : 3,
        "padj" : 0.023059554,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-42667",
        "TopologicalCoefficient" : 0.3939393939393939,
        "SUID" : 391,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.613793103448276,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.17813267813267813,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 30.0,
        "significant" : true,
        "Radiality" : 0.8409036860879905,
        "Stress" : 30760,
        "target_original" : "Gypsy101-LTR_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.013210940825883366,
        "NumberOfUndirectedEdges" : 3,
        "name" : "piR-dre-42667",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.218471234,
        "NeighborhoodConnectivity" : 5.333333333333333
      },
      "position" : {
        "x" : 256.89525597062834,
        "y" : 668.8812811472644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "degree_layout" : 1,
        "padj" : 0.0235680127672742,
        "Eccentricity" : 7,
        "pvalue" : 6.56256137314031E-5,
        "shared_name" : "Gypsy-21-I_DR",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 100.96439213047,
        "SUID" : 371,
        "lfcSE" : 0.265833008415293,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.089655172413793,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.1964769647696477,
        "stat" : 3.9916122456751,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8589774078478003,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Gypsy-21-I_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.06110229169513,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 215.45577232805022,
        "y" : 973.4946234324207
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "409",
        "degree_layout" : 1,
        "padj" : 0.0235680127672742,
        "Eccentricity" : 9,
        "pvalue" : 4.08332001185602E-5,
        "shared_name" : "BEL-37-LTR_DR",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 13.1091872791206,
        "SUID" : 409,
        "lfcSE" : 0.415943351504171,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 6.63448275862069,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.1507276507276507,
        "stat" : -4.1027139305075,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8057074910820451,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "BEL-37-LTR_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.70649658251814,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 21.809348988206466,
        "y" : 674.4702704050769
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "degree_layout" : 2,
        "padj" : 0.036490462,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-19951",
        "TopologicalCoefficient" : 0.56,
        "SUID" : 425,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.055172413793104,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2465986394557823,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 22.22,
        "significant" : true,
        "Radiality" : 0.8946492271105827,
        "Stress" : 136748,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.04427096636866745,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-19951",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.469290879,
        "NeighborhoodConnectivity" : 15.0
      },
      "position" : {
        "x" : 482.4569930311752,
        "y" : 698.0300848582019
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "441",
        "degree_layout" : 19,
        "padj" : 0.0439130485103244,
        "Eccentricity" : 7,
        "pvalue" : 9.0944183305405E-4,
        "shared_name" : "Gypsy-169-I_DR",
        "TopologicalCoefficient" : 0.18461538461538463,
        "baseMean" : 218.869869686786,
        "SUID" : 441,
        "lfcSE" : 0.40162826184473,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.7172413793103445,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.21198830409356725,
        "stat" : -3.31713953846208,
        "Degree" : 19,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.871819262782402,
        "Stress" : 527658,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.18504203916560208,
        "NumberOfUndirectedEdges" : 19,
        "name" : "Gypsy-169-I_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.33225698712895,
        "NeighborhoodConnectivity" : 1.9230769230769231
      },
      "position" : {
        "x" : 604.626365589769,
        "y" : 677.3992865183582
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "407",
        "degree_layout" : 1,
        "padj" : 0.0368940255327715,
        "Eccentricity" : 9,
        "pvalue" : 5.5440823063336E-4,
        "shared_name" : "BEL30-I_DR",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 15.9918713276905,
        "SUID" : 407,
        "lfcSE" : 0.306808884911631,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 6.63448275862069,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.1507276507276507,
        "stat" : 3.4529906443372,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8057074910820451,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "BEL30-I_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.05940820919939,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 42.63475792375334,
        "y" : 578.3043158152332
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "439",
        "degree_layout" : 3,
        "padj" : 0.005576147,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-10247",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 439,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 45.0,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "name" : "piR-dre-10247",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 3.009676923,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 373.23891441789397,
        "y" : 780.1157171824207
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "423",
        "degree_layout" : 5,
        "padj" : 0.044397827,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-21062",
        "TopologicalCoefficient" : 0.56,
        "SUID" : 423,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.055172413793104,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.2465986394557823,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "weight" : 33.33,
        "significant" : true,
        "Radiality" : 0.8946492271105827,
        "Stress" : 136748,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.04427096636866745,
        "NumberOfUndirectedEdges" : 5,
        "name" : "piR-dre-21062",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.310968788,
        "NeighborhoodConnectivity" : 15.0
      },
      "position" : {
        "x" : 557.7546611997483,
        "y" : 761.1519650712759
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "437",
        "degree_layout" : 33,
        "padj" : 0.0235680127672742,
        "Eccentricity" : 5,
        "pvalue" : 2.2334238674826E-4,
        "shared_name" : "DNA-3-1_DR",
        "TopologicalCoefficient" : 0.07352941176470588,
        "baseMean" : 1091.63999020956,
        "SUID" : 437,
        "lfcSE" : 0.328225659022546,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.296551724137931,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.303347280334728,
        "stat" : 3.69103615308878,
        "Degree" : 33,
        "PartnerOfMultiEdgedNodePairs" : 8,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.920808561236623,
        "Stress" : 728824,
        "target_original" : "acsl1a",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.47616272882077487,
        "NumberOfUndirectedEdges" : 33,
        "name" : "DNA-3-1_DR",
        "interaction" : "TE_gene",
        "IsSingleNode" : false,
        "log2FC" : 1.21149277382361,
        "NeighborhoodConnectivity" : 1.8823529411764706
      },
      "position" : {
        "x" : 431.7716902968002,
        "y" : 849.9626410105457
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "degree_layout" : 1,
        "padj" : 0.044846016,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-48972",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 389,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 52.63,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-48972",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -1.750989964,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 457.4041365858627,
        "y" : 907.1455023386707
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "degree_layout" : 3,
        "padj" : 0.045260357,
        "Eccentricity" : 10,
        "shared_name" : "piR-dre-34810",
        "TopologicalCoefficient" : 0.5714285714285714,
        "SUID" : 405,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 7.268965517241379,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.13757115749525617,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 26.32,
        "significant" : true,
        "Radiality" : 0.7838287752675386,
        "Stress" : 52,
        "target_original" : "BEL23-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 7.407407407407405E-4,
        "NumberOfUndirectedEdges" : 3,
        "name" : "piR-dre-34810",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -1.613153054,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 304.0087508436752,
        "y" : 457.52587343242067
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "369",
        "degree_layout" : 1,
        "padj" : 0.047851863,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-426176",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 369,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.848275862068966,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.17099056603773585,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 29.41,
        "significant" : true,
        "Radiality" : 0.8328180737217598,
        "Stress" : 0,
        "target_original" : "Gypsy101-LTR_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-426176",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.770959885,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 102.37914268937834,
        "y" : 904.4973089792957
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "403",
        "degree_layout" : 6,
        "padj" : 0.0235680127672742,
        "Eccentricity" : 9,
        "pvalue" : 2.3242616141296E-4,
        "shared_name" : "Gypsy160-I_DR",
        "TopologicalCoefficient" : 0.3333333333333333,
        "baseMean" : 12.8853061403759,
        "SUID" : 403,
        "lfcSE" : 0.34313376082853,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 6.386206896551724,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.15658747300215983,
        "stat" : -3.68088462900082,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.814268727705113,
        "Stress" : 91530,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.02451468710089409,
        "NumberOfUndirectedEdges" : 6,
        "name" : "Gypsy160-I_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.26303578592498,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 386.5407332655502,
        "y" : 548.1661932566394
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "387",
        "degree_layout" : 2,
        "padj" : 0.036654587,
        "Eccentricity" : 10,
        "shared_name" : "piR-dre-51545",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 387,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 7.462068965517242,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.13401109057301294,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 36.84,
        "significant" : true,
        "Radiality" : 0.7771700356718193,
        "Stress" : 0,
        "target_original" : "Gypsy151-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-51545",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 3.886600774,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 828.9714583632065,
        "y" : 495.97875429179567
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "367",
        "degree_layout" : 1,
        "padj" : 0.047851863,
        "Eccentricity" : 10,
        "shared_name" : "piR-dre-492597",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 367,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 7.324137931034483,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.13653483992467044,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 21.05,
        "significant" : true,
        "Radiality" : 0.7819262782401902,
        "Stress" : 0,
        "target_original" : "BEL23-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-492597",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -3.056747389,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 203.18410484758147,
        "y" : 506.3041327097644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "435",
        "degree_layout" : 3,
        "padj" : 0.028898576,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-13310",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 435,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.710344827586207,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.1751207729468599,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 36.84,
        "significant" : true,
        "Radiality" : 0.8375743162901309,
        "Stress" : 0,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "name" : "piR-dre-13310",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -3.039901637,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 653.7456893202377,
        "y" : 604.1197455027332
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "385",
        "degree_layout" : 1,
        "padj" : 0.026370843,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-57020",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 385,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 27.78,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-57020",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.464855309,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 563.3144149061752,
        "y" : 903.1497747996082
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "degree_layout" : 8,
        "padj" : 0.044397827,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-555119",
        "TopologicalCoefficient" : 0.37333333333333335,
        "SUID" : 365,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.041379310344827,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.24744027303754268,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 45.0,
        "significant" : true,
        "Radiality" : 0.8951248513674198,
        "Stress" : 141906,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.058064069816943446,
        "NumberOfUndirectedEdges" : 8,
        "name" : "piR-dre-555119",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -3.93768845,
        "NeighborhoodConnectivity" : 10.333333333333334
      },
      "position" : {
        "x" : 543.3821639296127,
        "y" : 831.0383246042957
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "421",
        "degree_layout" : 2,
        "padj" : 0.032715606,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-24037",
        "TopologicalCoefficient" : 0.56,
        "SUID" : 421,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.055172413793104,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.2465986394557823,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 33.33,
        "significant" : true,
        "Radiality" : 0.8946492271105827,
        "Stress" : 136748,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.04427096636866745,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-24037",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.34523479,
        "NeighborhoodConnectivity" : 15.0
      },
      "position" : {
        "x" : 484.86989586320647,
        "y" : 756.2717230417957
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "degree_layout" : 2,
        "padj" : 0.005576147,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-35440",
        "TopologicalCoefficient" : 0.6153846153846154,
        "SUID" : 401,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.682758620689655,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.17597087378640777,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 31.58,
        "significant" : true,
        "Radiality" : 0.838525564803805,
        "Stress" : 40572,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.006148361004682845,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-35440",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 1.868688745,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 791.8063364183041,
        "y" : 666.0584662058582
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "383",
        "degree_layout" : 1,
        "padj" : 0.047222994,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-69525",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 383,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 23.53,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-69525",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.167176685,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 517.7188238972808,
        "y" : 1037.001010085577
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "433",
        "degree_layout" : 2,
        "padj" : 0.014404125,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-15727",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 433,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 26.32,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-15727",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.279444484,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 314.509376024058,
        "y" : 987.7598748070731
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "419",
        "degree_layout" : 5,
        "padj" : 0.028898576,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-27928",
        "TopologicalCoefficient" : 0.39215686274509803,
        "SUID" : 419,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.531034482758621,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.18079800498753118,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 29.41,
        "significant" : true,
        "Radiality" : 0.8437574316290131,
        "Stress" : 101774,
        "target_original" : "Gypsy151-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0328113026819924,
        "NumberOfUndirectedEdges" : 5,
        "name" : "piR-dre-27928",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.287810468,
        "NeighborhoodConnectivity" : 7.666666666666667
      },
      "position" : {
        "x" : 551.519920277269,
        "y" : 590.2399847605457
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "381",
        "degree_layout" : 1,
        "padj" : 0.032715606,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-71201",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 381,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.710344827586207,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.1751207729468599,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 29.41,
        "significant" : true,
        "Radiality" : 0.8375743162901309,
        "Stress" : 0,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-71201",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 5.319576757,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 727.1431502577377,
        "y" : 620.8227484324207
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "399",
        "degree_layout" : 2,
        "padj" : 0.02094751,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-35441",
        "TopologicalCoefficient" : 0.6153846153846154,
        "SUID" : 399,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.682758620689655,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.17597087378640777,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 29.41,
        "significant" : true,
        "Radiality" : 0.838525564803805,
        "Stress" : 40572,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.006148361004682845,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-35441",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 1.73415873,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 713.675437855394,
        "y" : 691.6953680613269
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "417",
        "degree_layout" : 5,
        "padj" : 0.0245399635509094,
        "Eccentricity" : 9,
        "pvalue" : 3.1461491731935E-4,
        "shared_name" : "BEL23-I_DR",
        "TopologicalCoefficient" : 0.26666666666666666,
        "baseMean" : 143.057872298067,
        "SUID" : 417,
        "lfcSE" : 0.281495245802944,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 6.3310344827586205,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.1579520697167756,
        "stat" : 3.60295920790438,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8161712247324613,
        "Stress" : 61344,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.0270971690080885,
        "NumberOfUndirectedEdges" : 5,
        "name" : "BEL23-I_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : 1.01421588784702,
        "NeighborhoodConnectivity" : 2.6
      },
      "position" : {
        "x" : 330.83571617570647,
        "y" : 585.5692694285144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "degree_layout" : 1,
        "padj" : 0.032715606,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-72927",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 379,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.848275862068966,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.17099056603773585,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 29.41,
        "significant" : true,
        "Radiality" : 0.8328180737217598,
        "Stress" : 0,
        "target_original" : "Gypsy101-LTR_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "piR-dre-72927",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -1.669684447,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 35.55876915422209,
        "y" : 861.8120062449207
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "degree_layout" : 3,
        "padj" : 0.048263483,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-17612",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 431,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 36.84,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "name" : "piR-dre-17612",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -1.903081512,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 404.7638777968002,
        "y" : 954.4642279246082
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "degree_layout" : 1,
        "padj" : 0.0368940255327715,
        "Eccentricity" : 7,
        "pvalue" : 6.0139496076319E-4,
        "shared_name" : "Gypsy127-LTR_DR",
        "TopologicalCoefficient" : 0.0,
        "baseMean" : 24.5761231035443,
        "SUID" : 363,
        "lfcSE" : 0.363143804530866,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.0344827586206895,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.1986301369863014,
        "stat" : -3.43098450088222,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "significant" : true,
        "Radiality" : 0.8608799048751486,
        "Stress" : 0,
        "target_original" : "",
        "feature_type" : "TE",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Gypsy127-LTR_DR",
        "interaction" : "",
        "IsSingleNode" : false,
        "log2FC" : -1.2459407649368,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 639.3483504530502,
        "y" : 858.3115179636707
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "397",
        "degree_layout" : 2,
        "padj" : 0.011958865,
        "Eccentricity" : 8,
        "shared_name" : "piR-dre-35848",
        "TopologicalCoefficient" : 0.5333333333333333,
        "SUID" : 397,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.6,
        "selected" : false,
        "direction" : "down",
        "ClosenessCentrality" : 0.17857142857142858,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "weight" : 27.78,
        "significant" : true,
        "Radiality" : 0.8413793103448275,
        "Stress" : 60908,
        "target_original" : "Gypsy-169-I_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.014953703703703743,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-35848",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : -2.442915933,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 517.7931746718002,
        "y" : 540.4419500925769
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "degree_layout" : 2,
        "padj" : 0.044397827,
        "Eccentricity" : 6,
        "shared_name" : "piR-dre-80231",
        "TopologicalCoefficient" : 0.0,
        "SUID" : 377,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.289655172413793,
        "selected" : false,
        "direction" : "up",
        "ClosenessCentrality" : 0.23311897106109325,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "weight" : 31.25,
        "significant" : true,
        "Radiality" : 0.8865636147443519,
        "Stress" : 0,
        "target_original" : "DNA-3-1_DR",
        "feature_type" : "piRNA",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "piR-dre-80231",
        "interaction" : "piRNA_TE",
        "IsSingleNode" : false,
        "log2FC" : 2.93530641,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 329.63808433976897,
        "y" : 913.2117865183582
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "715",
        "source" : "395",
        "target" : "441",
        "EdgeBetweenness" : 577.2666666666678,
        "shared_name" : "piR-dre-35849 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35849 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 23.53,
        "SUID" : 715,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "717",
        "source" : "395",
        "target" : "403",
        "EdgeBetweenness" : 337.2000000000009,
        "shared_name" : "piR-dre-35849 (piRNA_TE) Gypsy160-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35849 (piRNA_TE) Gypsy160-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 29.41,
        "SUID" : 717,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "687",
        "source" : "375",
        "target" : "411",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-83372 (piRNA_TE) Gypsy101-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-83372 (piRNA_TE) Gypsy101-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.25,
        "SUID" : 687,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "779",
        "source" : "429",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-18163 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-18163 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "745",
        "source" : "415",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-31928 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-31928 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 25.0,
        "SUID" : 745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "653",
        "source" : "361",
        "target" : "441",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-809338 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-809338 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 20.0,
        "SUID" : 653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "681",
        "source" : "373",
        "target" : "371",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-133212 (piRNA_TE) Gypsy-21-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-133212 (piRNA_TE) Gypsy-21-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 26.32,
        "SUID" : 681,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "683",
        "source" : "373",
        "target" : "437",
        "EdgeBetweenness" : 2675.5444444444493,
        "shared_name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 26.32,
        "SUID" : 683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "685",
        "source" : "373",
        "target" : "437",
        "EdgeBetweenness" : 2675.5444444444493,
        "shared_name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "675",
        "source" : "373",
        "target" : "411",
        "EdgeBetweenness" : 2211.1888888888925,
        "shared_name" : "piR-dre-133212 (piRNA_TE) Gypsy101-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-133212 (piRNA_TE) Gypsy101-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "677",
        "source" : "373",
        "target" : "437",
        "EdgeBetweenness" : 2675.5444444444493,
        "shared_name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 42.11,
        "SUID" : 677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "679",
        "source" : "373",
        "target" : "437",
        "EdgeBetweenness" : 2675.5444444444493,
        "shared_name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-133212 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 36.84,
        "SUID" : 679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "775",
        "source" : "427",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-19094 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-19094 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 33.33,
        "SUID" : 775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "777",
        "source" : "427",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-19094 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-19094 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 22.22,
        "SUID" : 777,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "741",
        "source" : "413",
        "target" : "409",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-34461 (piRNA_TE) BEL-37-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-34461 (piRNA_TE) BEL-37-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 741,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "743",
        "source" : "413",
        "target" : "411",
        "EdgeBetweenness" : 874.1111111111086,
        "shared_name" : "piR-dre-34461 (piRNA_TE) Gypsy101-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-34461 (piRNA_TE) Gypsy101-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.58,
        "SUID" : 743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "737",
        "source" : "413",
        "target" : "407",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-34461 (piRNA_TE) BEL30-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-34461 (piRNA_TE) BEL30-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 737,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "739",
        "source" : "413",
        "target" : "417",
        "EdgeBetweenness" : 242.1111111111117,
        "shared_name" : "piR-dre-34461 (piRNA_TE) BEL23-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-34461 (piRNA_TE) BEL23-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.58,
        "SUID" : 739,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "649",
        "source" : "359",
        "target" : "437",
        "EdgeBetweenness" : 576.0,
        "shared_name" : "piR-dre-1029262 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-1029262 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 33.33,
        "SUID" : 649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "651",
        "source" : "359",
        "target" : "357",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-1029262 (piRNA_TE) Gypsy100-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-1029262 (piRNA_TE) Gypsy100-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 28.57,
        "SUID" : 651,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "713",
        "source" : "393",
        "target" : "403",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-35850 (piRNA_TE) Gypsy160-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35850 (piRNA_TE) Gypsy160-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 25.0,
        "SUID" : 713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "807",
        "source" : "445",
        "target" : "443",
        "EdgeBetweenness" : 142.97777777777776,
        "shared_name" : "piR-dre-2441 (piRNA_TE) Gypsy151-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-2441 (piRNA_TE) Gypsy151-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 27.78,
        "SUID" : 807,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "805",
        "source" : "445",
        "target" : "441",
        "EdgeBetweenness" : 403.77777777777777,
        "shared_name" : "piR-dre-2441 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-2441 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 27.78,
        "SUID" : 805,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "707",
        "source" : "391",
        "target" : "411",
        "EdgeBetweenness" : 505.8777777777761,
        "shared_name" : "piR-dre-42667 (piRNA_TE) Gypsy101-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-42667 (piRNA_TE) Gypsy101-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 30.0,
        "SUID" : 707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "709",
        "source" : "391",
        "target" : "417",
        "EdgeBetweenness" : 166.74444444444475,
        "shared_name" : "piR-dre-42667 (piRNA_TE) BEL23-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-42667 (piRNA_TE) BEL23-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 25.0,
        "SUID" : 709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "711",
        "source" : "391",
        "target" : "403",
        "EdgeBetweenness" : 169.06666666666683,
        "shared_name" : "piR-dre-42667 (piRNA_TE) Gypsy160-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-42667 (piRNA_TE) Gypsy160-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 25.0,
        "SUID" : 711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "771",
        "source" : "425",
        "target" : "437",
        "EdgeBetweenness" : 1171.8777777777782,
        "shared_name" : "piR-dre-19951 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-19951 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 22.22,
        "SUID" : 771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "773",
        "source" : "425",
        "target" : "441",
        "EdgeBetweenness" : 966.8777777777763,
        "shared_name" : "piR-dre-19951 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-19951 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 27.78,
        "SUID" : 773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "799",
        "source" : "439",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-10247 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-10247 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 45.0,
        "SUID" : 799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "801",
        "source" : "439",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-10247 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-10247 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 40.0,
        "SUID" : 801,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "803",
        "source" : "439",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-10247 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-10247 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 30.0,
        "SUID" : 803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "761",
        "source" : "423",
        "target" : "437",
        "EdgeBetweenness" : 1171.8777777777782,
        "shared_name" : "piR-dre-21062 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-21062 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 33.33,
        "SUID" : 761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "763",
        "source" : "423",
        "target" : "441",
        "EdgeBetweenness" : 966.8777777777763,
        "shared_name" : "piR-dre-21062 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-21062 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 27.78,
        "SUID" : 763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "765",
        "source" : "423",
        "target" : "441",
        "EdgeBetweenness" : 966.8777777777763,
        "shared_name" : "piR-dre-21062 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-21062 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 33.33,
        "SUID" : 765,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "source" : "423",
        "target" : "437",
        "EdgeBetweenness" : 1171.8777777777782,
        "shared_name" : "piR-dre-21062 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-21062 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 38.89,
        "SUID" : 767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "769",
        "source" : "423",
        "target" : "441",
        "EdgeBetweenness" : 966.8777777777763,
        "shared_name" : "piR-dre-21062 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-21062 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 22.22,
        "SUID" : 769,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "705",
        "source" : "389",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-48972 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-48972 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 52.63,
        "SUID" : 705,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "731",
        "source" : "405",
        "target" : "417",
        "EdgeBetweenness" : 140.66666666666723,
        "shared_name" : "piR-dre-34810 (piRNA_TE) BEL23-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-34810 (piRNA_TE) BEL23-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 26.32,
        "SUID" : 731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "733",
        "source" : "405",
        "target" : "403",
        "EdgeBetweenness" : 180.26666666666605,
        "shared_name" : "piR-dre-34810 (piRNA_TE) Gypsy160-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-34810 (piRNA_TE) Gypsy160-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 26.32,
        "SUID" : 733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "735",
        "source" : "405",
        "target" : "403",
        "EdgeBetweenness" : 180.26666666666605,
        "shared_name" : "piR-dre-34810 (piRNA_TE) Gypsy160-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-34810 (piRNA_TE) Gypsy160-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "673",
        "source" : "369",
        "target" : "411",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-426176 (piRNA_TE) Gypsy101-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-426176 (piRNA_TE) Gypsy101-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 29.41,
        "SUID" : 673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "701",
        "source" : "387",
        "target" : "443",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-51545 (piRNA_TE) Gypsy151-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-51545 (piRNA_TE) Gypsy151-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 36.84,
        "SUID" : 701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "703",
        "source" : "387",
        "target" : "443",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-51545 (piRNA_TE) Gypsy151-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-51545 (piRNA_TE) Gypsy151-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 703,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "671",
        "source" : "367",
        "target" : "417",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-492597 (piRNA_TE) BEL23-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-492597 (piRNA_TE) BEL23-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "791",
        "source" : "435",
        "target" : "441",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-13310 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-13310 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 36.84,
        "SUID" : 791,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "793",
        "source" : "435",
        "target" : "441",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-13310 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-13310 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.58,
        "SUID" : 793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "795",
        "source" : "435",
        "target" : "441",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-13310 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-13310 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 42.11,
        "SUID" : 795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "699",
        "source" : "385",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-57020 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-57020 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 27.78,
        "SUID" : 699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "655",
        "source" : "365",
        "target" : "437",
        "EdgeBetweenness" : 1417.3777777777802,
        "shared_name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 45.0,
        "SUID" : 655,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "657",
        "source" : "365",
        "target" : "437",
        "EdgeBetweenness" : 1417.3777777777802,
        "shared_name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 40.0,
        "SUID" : 657,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "659",
        "source" : "365",
        "target" : "363",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-555119 (piRNA_TE) Gypsy127-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) Gypsy127-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 60.0,
        "SUID" : 659,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "661",
        "source" : "365",
        "target" : "437",
        "EdgeBetweenness" : 1417.3777777777802,
        "shared_name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 25.0,
        "SUID" : 661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "663",
        "source" : "365",
        "target" : "437",
        "EdgeBetweenness" : 1417.3777777777802,
        "shared_name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 20.0,
        "SUID" : 663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "665",
        "source" : "365",
        "target" : "437",
        "EdgeBetweenness" : 1417.3777777777802,
        "shared_name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 30.0,
        "SUID" : 665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "667",
        "source" : "365",
        "target" : "437",
        "EdgeBetweenness" : 1417.3777777777802,
        "shared_name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 35.0,
        "SUID" : 667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "669",
        "source" : "365",
        "target" : "441",
        "EdgeBetweenness" : 1007.3777777777761,
        "shared_name" : "piR-dre-555119 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-555119 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 25.0,
        "SUID" : 669,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "757",
        "source" : "421",
        "target" : "441",
        "EdgeBetweenness" : 966.8777777777763,
        "shared_name" : "piR-dre-24037 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-24037 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 33.33,
        "SUID" : 757,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "759",
        "source" : "421",
        "target" : "437",
        "EdgeBetweenness" : 1171.8777777777775,
        "shared_name" : "piR-dre-24037 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-24037 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 44.44,
        "SUID" : 759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "727",
        "source" : "401",
        "target" : "441",
        "EdgeBetweenness" : 403.77777777777777,
        "shared_name" : "piR-dre-35440 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35440 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.58,
        "SUID" : 727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "729",
        "source" : "401",
        "target" : "443",
        "EdgeBetweenness" : 142.9777777777778,
        "shared_name" : "piR-dre-35440 (piRNA_TE) Gypsy151-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35440 (piRNA_TE) Gypsy151-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.58,
        "SUID" : 729,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "697",
        "source" : "383",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-69525 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-69525 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 23.53,
        "SUID" : 697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "787",
        "source" : "433",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-15727 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-15727 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 26.32,
        "SUID" : 787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "789",
        "source" : "433",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-15727 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-15727 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "747",
        "source" : "419",
        "target" : "443",
        "EdgeBetweenness" : 204.66666666666663,
        "shared_name" : "piR-dre-27928 (piRNA_TE) Gypsy151-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-27928 (piRNA_TE) Gypsy151-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 29.41,
        "SUID" : 747,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "749",
        "source" : "419",
        "target" : "441",
        "EdgeBetweenness" : 873.4777777777794,
        "shared_name" : "piR-dre-27928 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-27928 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 23.53,
        "SUID" : 749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "751",
        "source" : "419",
        "target" : "441",
        "EdgeBetweenness" : 873.4777777777794,
        "shared_name" : "piR-dre-27928 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-27928 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 41.18,
        "SUID" : 751,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "753",
        "source" : "419",
        "target" : "417",
        "EdgeBetweenness" : 582.0555555555563,
        "shared_name" : "piR-dre-27928 (piRNA_TE) BEL23-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-27928 (piRNA_TE) BEL23-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 23.53,
        "SUID" : 753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "755",
        "source" : "419",
        "target" : "441",
        "EdgeBetweenness" : 873.4777777777794,
        "shared_name" : "piR-dre-27928 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-27928 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 35.29,
        "SUID" : 755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "695",
        "source" : "381",
        "target" : "441",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-71201 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-71201 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 29.41,
        "SUID" : 695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "723",
        "source" : "399",
        "target" : "441",
        "EdgeBetweenness" : 403.77777777777777,
        "shared_name" : "piR-dre-35441 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35441 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 29.41,
        "SUID" : 723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "725",
        "source" : "399",
        "target" : "443",
        "EdgeBetweenness" : 142.9777777777778,
        "shared_name" : "piR-dre-35441 (piRNA_TE) Gypsy151-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35441 (piRNA_TE) Gypsy151-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 29.41,
        "SUID" : 725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "693",
        "source" : "379",
        "target" : "411",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-72927 (piRNA_TE) Gypsy101-LTR_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-72927 (piRNA_TE) Gypsy101-LTR_DR",
        "interaction" : "piRNA_TE",
        "weight" : 29.41,
        "SUID" : 693,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "781",
        "source" : "431",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-17612 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-17612 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 36.84,
        "SUID" : 781,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "783",
        "source" : "431",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-17612 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-17612 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 21.05,
        "SUID" : 783,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "785",
        "source" : "431",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-17612 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-17612 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.58,
        "SUID" : 785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "719",
        "source" : "397",
        "target" : "441",
        "EdgeBetweenness" : 577.2666666666678,
        "shared_name" : "piR-dre-35848 (piRNA_TE) Gypsy-169-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35848 (piRNA_TE) Gypsy-169-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 27.78,
        "SUID" : 719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "721",
        "source" : "397",
        "target" : "403",
        "EdgeBetweenness" : 337.2000000000009,
        "shared_name" : "piR-dre-35848 (piRNA_TE) Gypsy160-I_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-35848 (piRNA_TE) Gypsy160-I_DR",
        "interaction" : "piRNA_TE",
        "weight" : 27.78,
        "SUID" : 721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "source" : "377",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-80231 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-80231 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 31.25,
        "SUID" : 689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "691",
        "source" : "377",
        "target" : "437",
        "EdgeBetweenness" : 290.0,
        "shared_name" : "piR-dre-80231 (piRNA_TE) DNA-3-1_DR",
        "shared_interaction" : "piRNA_TE",
        "name" : "piR-dre-80231 (piRNA_TE) DNA-3-1_DR",
        "interaction" : "piRNA_TE",
        "weight" : 25.0,
        "SUID" : 691,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}